(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Newrelic;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/partup_newrelic/newrelic.js                              //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
// jscs:disable
/**
 * Enables new-relic stat emitting
 *
 * @module newrelic
 */
// jscs:enable
if (process.env.NODE_ENV !== 'development') {
    Newrelic = Npm.require('newrelic');
}

///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['partup:newrelic'] = {}, {
  Newrelic: Newrelic
});

})();

//# sourceMappingURL=partup_newrelic.js.map
