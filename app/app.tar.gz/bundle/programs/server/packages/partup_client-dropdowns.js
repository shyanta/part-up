(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var SubsManager = Package['meteorhacks:subs-manager'].SubsManager;

/* Package-scope variables */
var ClientDropdowns;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['partup:client-dropdowns'] = {};

})();
