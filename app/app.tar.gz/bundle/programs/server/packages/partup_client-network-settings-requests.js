(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Version = Package['partup:lib'].Version;
var Partup = Package['partup:lib'].Partup;
var Activities = Package['partup:lib'].Activities;
var Invites = Package['partup:lib'].Invites;
var Contributions = Package['partup:lib'].Contributions;
var Images = Package['partup:lib'].Images;
var Temp = Package['partup:lib'].Temp;
var Networks = Package['partup:lib'].Networks;
var Notifications = Package['partup:lib'].Notifications;
var Partups = Package['partup:lib'].Partups;
var Ratings = Package['partup:lib'].Ratings;
var Tags = Package['partup:lib'].Tags;
var Updates = Package['partup:lib'].Updates;
var Update = Package['partup:lib'].Update;
var User = Package['partup:lib'].User;
var Places = Package['partup:lib'].Places;
var PlacesAutocompletes = Package['partup:lib'].PlacesAutocompletes;
var Uploads = Package['partup:lib'].Uploads;
var Languages = Package['partup:lib'].Languages;
var Tiles = Package['partup:lib'].Tiles;
var Swarms = Package['partup:lib'].Swarms;
var ContentBlocks = Package['partup:lib'].ContentBlocks;
var Chats = Package['partup:lib'].Chats;
var ChatMessages = Package['partup:lib'].ChatMessages;
var get = Package['partup:lib'].get;
var set = Package['partup:lib'].set;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['partup:client-network-settings-requests'] = {};

})();
