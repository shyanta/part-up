(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var Accounts = Package['accounts-base'].Accounts;
var lodash = Package['stevezhu:lodash'].lodash;
var _ = Package['stevezhu:lodash']._;
var Email = Package.email.Email;
var EmailInternals = Package.email.EmailInternals;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Version = Package['partup:lib'].Version;
var Partup = Package['partup:lib'].Partup;
var Activities = Package['partup:lib'].Activities;
var Invites = Package['partup:lib'].Invites;
var Contributions = Package['partup:lib'].Contributions;
var Images = Package['partup:lib'].Images;
var Temp = Package['partup:lib'].Temp;
var Networks = Package['partup:lib'].Networks;
var Notifications = Package['partup:lib'].Notifications;
var Partups = Package['partup:lib'].Partups;
var Ratings = Package['partup:lib'].Ratings;
var Tags = Package['partup:lib'].Tags;
var Updates = Package['partup:lib'].Updates;
var Update = Package['partup:lib'].Update;
var User = Package['partup:lib'].User;
var Places = Package['partup:lib'].Places;
var PlacesAutocompletes = Package['partup:lib'].PlacesAutocompletes;
var Uploads = Package['partup:lib'].Uploads;
var Languages = Package['partup:lib'].Languages;
var Tiles = Package['partup:lib'].Tiles;
var Swarms = Package['partup:lib'].Swarms;
var ContentBlocks = Package['partup:lib'].ContentBlocks;
var Chats = Package['partup:lib'].Chats;
var ChatMessages = Package['partup:lib'].ChatMessages;
var get = Package['partup:lib'].get;
var set = Package['partup:lib'].set;
var SyncedCron = Package['percolate:synced-cron'].SyncedCron;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var AccountsMeld = Package['splendido:accounts-meld'].AccountsMeld;
var MeldActions = Package['splendido:accounts-meld'].MeldActions;
var Migrations = Package['percolate:migrations'].Migrations;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;
var mout = Package['lifely:mout'].mout;
var Picker = Package['meteorhacks:picker'].Picker;
var Template = Package['meteorhacks:ssr'].Template;
var SSR = Package['meteorhacks:ssr'].SSR;
var CSV = Package['dsyko:meteor-node-csv'].CSV;
var Random = Package.random.Random;
var AWS = Package['peerlibrary:aws-sdk'].AWS;
var JsonRoutes = Package['simple:json-routes'].JsonRoutes;
var Iron = Package['iron:core'].Iron;

/* Package-scope variables */
var Log, Debug, Event, featured, flickr, image, __;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/logger.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var winston = Npm.require('winston');

var transports = [];

if (process.env.NODE_ENV.match(/development|staging|acceptance/)) {
    transports.push(new (winston.transports.Console)({level: 'debug', prettyPrint: true, colorize: true, debugStdout: true}));
}

if (process.env.NODE_ENV === 'production') {
    transports.push(new (winston.transports.Console)({level: 'warn'}));
}

Log = new (winston.Logger)({transports: transports});

Debug = function(namespace) {
    var debug = Npm.require('debug')('partup:' + namespace);
    debug.log = console.info.bind(console);
    debug.useColors = true;
    return debug;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/namespace.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * This component contains all server specific code
 *
 * @module server
 */
Partup = Partup || {};

/**
 @namespace server
 @name partup.server
 */
Partup.server = {};

/**
 @namespace server.constants
 @name partup.server.constants
 */
Partup.constants = {};

/**
 @namespace server.services
 @name partup.server.services
 */
Partup.server.services = {};

/**
 @namespace server.factories
 @name partup.server.factories
 */
Partup.server.factories = {};

/**
 @namespace server.publications
 @name partup.server.publications
 */
// Publications are globally available
// Partup.server.publications = {};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/constants.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @name Partup.constants
 @memberof Partup.factories
 */
Partup.constants.EMAIL_FROM = process.env.PARTUP_EMAIL_FROM || 'Part-up <team@part-up.com>';
Partup.constants.CRON_DIGEST = process.env.PARTUP_CRON_DIGEST || 'at 09:00am every weekday';
Partup.constants.CRON_ENDDATE_REMINDER = process.env.PARTUP_CRON_ENDDATE_REMINDER || 'every 1 hour on the 10th minute';
Partup.constants.CRON_PROGRESS = process.env.PARTUP_CRON_PROGRESS || 'every 1 hour on the 15th minute';
Partup.constants.CRON_PARTICIPATION = process.env.PARTUP_CRON_PARTICIPATION || 'every 1 hour on the 30th minute';
Partup.constants.CRON_RESET_CLICKS = process.env.PARTUP_CRON_RESET_CLICKS || 'every 1 hour on the 45th minute';
Partup.constants.CRON_SHARED_COUNTS = process.env.PARTUP_CRON_SHARED_COUNTS || 'every 13 minutes';
Partup.constants.CRON_POPULARITY = process.env.PARTUP_CRON_POPULARITY || 'every 1 hour on the 20th minute';
Partup.constants.CRON_UPDATE_SWARM_NETWORK_STATS = process.env.PARTUP_CRON_UPDATE_SWARM_NETWORK_STATS || 'every 2 hours on the 17th minute';
Partup.constants.CRON_SWARM_SHARED_COUNTS = process.env.PARTUP_CRON_SWARM_SHARED_COUNTS || 'every 10 hours on the 38th minute';
Partup.constants.CRON_CALCULATE_ACTIVE_NETWORK_UPPERS_PARTUPS = process.env.PARTUP_CRON_CALCULATE_ACTIVE_NETWORK_UPPERS_PARTUPS || 'every 4 hours on the 19th minute';
Partup.constants.CRON_GET_COMMON_NETWORK_TAGS = process.env.PARTUP_CRON_GET_COMMON_NETWORK_TAGS || 'every 6 hours on the 25th minute';
Partup.constants.PUSH_APPLE_APN_CLEANUP_INTERVAL = process.env.PARTUP_PUSH_APPLE_APN_CLEANUP_INTERVAL || 300;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/bootstrap.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Load the colors on the String prototype now, so we can use
// things like 'this is a string'.gray in the console.
var colors = Npm.require('colors');

ServiceConfiguration.configurations.upsert({
    service: 'facebook'
}, {
    $set: {
        appId: process.env['FACEBOOK_APP_ID'],
        loginStyle: 'popup',
        secret: process.env['FACEBOOK_APP_SECRET']
    }
});

ServiceConfiguration.configurations.upsert({
    service: 'linkedin'
}, {
    $set: {
        clientId: process.env['LINKEDIN_API_KEY'],
        loginStyle: 'popup',
        secret: process.env['LINKEDIN_SECRET_KEY']
    }
});

Router.route('/ping', function() {
    this.response.end('partupok');
}, {where: 'server'});

// Kick off the cronjobs
SyncedCron.start();

// Configure AWS
AWS.config.accessKeyId = process.env.AWS_ACCESS_KEY_ID;
AWS.config.secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
AWS.config.region = process.env.AWS_BUCKET_REGION;

// Browser Policy
Meteor.startup(function() {

    // Content allows
    BrowserPolicy.content.allowEval();
    BrowserPolicy.content.allowOriginForAll('*');

    // Disallow being framed by other sites
    BrowserPolicy.framing.disallow();

    // When in development mode, we need to be able to be framed by Velocity
    if (process.env.NODE_ENV.match(/development/)) {
        var VELOCITY_ORIGIN = 'http://localhost:49371';

        BrowserPolicy.framing.restrictToOrigin(VELOCITY_ORIGIN);
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/routes/composite.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.routeComposite = function(route, callback) {
    Router.route(route, {where: 'server'}).get(function() {
        var request = this.request;
        var response = this.response;
        var params = this.params;

        var userId = request.user ? request.user._id : null;
        delete params.query.token;

        var composition = callback(request, _.extend({}, params));
        var result = compositionToResult(userId, composition.find.bind({userId: userId}), composition.children);

        // We are going to respond in JSON format
        response.setHeader('Content-Type', 'application/json');
        response.setHeader('Access-Control-Allow-Origin', '*');

        return response.end(JSON.stringify(result));
    });
};

var compositionToResult = function(userId, find, children) {
    var result = {};

    var cursor = find();
    if (! cursor) return;

    var documents = cursor.fetch();
    var collectionName = cursor._cursorDescription.collectionName;

    documents.forEach(function(document) {
        result[collectionName] = result[collectionName] || [];
        result[collectionName].push(document);

        if (children) {
            children.forEach(function(childComposition) {
                var r = compositionToResult(
                    userId,
                    childComposition.find.bind({userId: userId}, document),
                    childComposition.children
                );

                if (r) {
                    Object.keys(r).forEach(function(collectionName) {
                        result[collectionName] = result[collectionName] || [];

                        var documents = r[collectionName];

                        documents.forEach(function(document) {
                            result[collectionName].push(document);
                        });
                    });
                }
            });
        }
    });

    return result;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/compile_email_templates.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var locales = ['en', 'nl'];
var templates = [
    'dailydigest',
    'invite_upper_to_network',
    'invite_email_address_to_network',
    'invite_upper_to_partup_activity',
    'invite_email_address_to_partup_activity',
    'invite_upper_to_partup',
    'invite_email_address_to_partup',
    'upper_mentioned_in_partup',
    'partup_created_in_network',
    'partups_networks_new_pending_upper',
    'partups_networks_accepted',
    'partups_new_comment_in_involved_conversation',
    'partups_networks_new_upper',
    'partups_networks_upper_left',
    'custom',
    'verify_account',
    'reset_password'
];

/**
 * Pre-compile all template combinations so it only happens once
 */
templates.forEach(function(type) {
    locales.forEach(function(locale) {
        SSR.compileTemplate('email-' + type + '-' + locale, [
            Assets.getText('private/emails/header.' + locale + '.html'),
            Assets.getText('private/emails/' + type + '.' + locale + '.html'),
            Assets.getText('private/emails/footer.' + locale + '.html')
        ].join(''));
    });
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/accounts.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('accounts');

Accounts.validateLoginAttempt(function(attempt) {
    var user = attempt.user;
    if (user && !User(user).isActive()) {
        throw new Meteor.Error(403, 'User is deactivated');
    }
    return true;
});

Accounts.onLogin(function(data) {
    Meteor.defer(function() {
        var user = data.user;
        var logins = user.logins || [];

        d('User [' + user._id + '] has logged in');

        var now = new Date;
        var todayFormatted = now.toISOString().slice(0, 10);
        var daysLoggedInFormatted = logins.map(function(login) {
            return login.toISOString().slice(0, 10);
        });

        var userAlreadyLoggedInToday = daysLoggedInFormatted.indexOf(todayFormatted) > -1;

        if (!userAlreadyLoggedInToday) {
            // We are using the extended $push syntax, $slice with a negative
            // number means we save the latest x amount of items.
            Meteor.users.update({_id: user._id}, {$push: {logins: {$each: [now], $slice: -25}}});
            d('User [' + user._id + '] first login today, saving');
        } else {
            d('User [' + user._id + '] already logged in earlier today, not saving');
        }
    });
});

var defaultEmailObject = {
    dailydigest: true,
    upper_mentioned_in_partup: true,
    invite_upper_to_partup_activity: true,
    invite_upper_to_network: true,
    partup_created_in_network: true,
    partups_networks_new_pending_upper: true,
    partups_networks_accepted: true,
    invite_upper_to_partup: true,
    partups_new_comment_in_involved_conversation: true,
    partups_networks_new_upper: true,
    partups_networks_upper_left: true
};

Accounts.onCreateUser(function(options, user) {
    var imageUrl;

    var sanitizedName = options.profile.name;
    var profile = {
        name: sanitizedName,
        normalized_name: sanitizedName ? Partup.helpers.normalize(sanitizedName) : '',
        settings: {
            locale: mout.object.get(options, 'profile.settings.locale') || 'en',
            optionalDetailsCompleted: false,
            email: defaultEmailObject,
            unsubscribe_email_token: Random.secret()
        }
    };

    var liData = mout.object.get(user, 'services.linkedin');
    var fbData = mout.object.get(user, 'services.facebook');

    user.emails = user.emails || [];

    d('User registration detected, creating a new user');

    if (liData) {
        d('User used LinkedIn to register');

        var location = {};

        if (liData.location && liData.location.name) {
            var locationParts = liData.location.name.split(',');

            if (locationParts.length === 2) {
                location.city = locationParts[0].trim().replace(' Area', '');
                location.country = locationParts[1].trim();
            }
        }

        var sanitizedName = liData.firstName + ' ' + liData.lastName;

        profile = {
            firstname: liData.firstName,
            lastname: liData.lastName,
            location: location,
            linkedin_url: 'https://linkedin.com/profile/view?id=' + liData.id,
            name: sanitizedName,
            normalized_name: Partup.helpers.normalize(sanitizedName),
            settings: {
                locale: 'en',
                optionalDetailsCompleted: false,
                email: defaultEmailObject,
                unsubscribe_email_token: Random.secret()
            }
        };

        imageUrl = liData.pictureUrl;
        user.emails.push({address: liData.emailAddress, verified: true});
    }

    if (fbData) {
        d('User used Facebook to register');

        profile = {
            firstname: fbData.first_name,
            gender: fbData.gender,
            lastname: fbData.last_name,
            facebook_url: 'https://facebook.com/' + fbData.id,
            name: fbData.name,
            normalized_name: Partup.helpers.normalize(fbData.name),
            settings: {
                locale: Partup.helpers.parseLocale(fbData.locale),
                optionalDetailsCompleted: false,
                email: defaultEmailObject,
                unsubscribe_email_token: Random.secret()
            }
        };

        imageUrl = 'https://graph.facebook.com/' + fbData.id + '/picture?width=750';
        user.emails.push({address: fbData.email, verified: true});
    }

    try {
        var result = HTTP.get(imageUrl, {'npmRequestOptions': {'encoding': null}});
        var body = new Buffer(result.content, 'binary');
        var image = Partup.server.services.images.upload(user._id + '.jpg', body, 'image/jpeg');

        profile.image = image._id;
    } catch (error) {
        Log.error(error.message);
    }

    if (!profile.image) {
        d('Registered user has no image so far, using one of the default profile pictures');

        var images = Images.find({'meta.default_profile_picture': true}).fetch();
        image = mout.random.choice(images);
        profile.image = image._id;
    }

    user.profile = profile;
    user.completeness = Partup.server.services.profile_completeness.updateScore(user);
    user.flags = {
        dailyDigestEmailHasBeenSent: false
    };
    user.profile.settings.locale = Meteor.call('users.get_locale');

    return user;
});

Accounts.validateNewUser(function(user) {
    var emailAddress = User(user).getEmail();

    var socialUser = Meteor.users.findOne({'emails.address': emailAddress});
    var passwordUser = Meteor.users.findOne({'registered_emails.address': emailAddress});

    if (socialUser) {
        if (socialUser.services.facebook) throw new Meteor.Error(409, 'user-registered-with-facebook');
        if (socialUser.services.linkedin) throw new Meteor.Error(409, 'user-registered-with-linkedin');
    }

    if (passwordUser) throw new Meteor.Error(409, 'user-registered-with-username-and-password');

    var liData = mout.object.get(user, 'services.linkedin');
    var fbData = mout.object.get(user, 'services.facebook');
    if (!liData && !fbData) {
        Meteor.setTimeout(function() {
            d('User registered with username and password, sending verification email');
            Accounts.sendVerificationEmail(user._id);
        }, 5000);
    }

    Event.emit('users.inserted', user);

    return true;
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/accounts_email_configuration.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Generic Email Configuration
 */
Accounts.emailTemplates.from = Partup.constants.EMAIL_FROM;
Accounts.emailTemplates.headers = {
    'X-Mailgun-Tag': 'email-accountsmanagement'
};

/**
 * Password Reset Email
 */
Accounts.emailTemplates.resetPassword.subject = function(user) {
    return TAPi18n.__('emails-reset-password-subject', {}, User(user).getLocale());
};
Accounts.emailTemplates.resetPassword.html = function(user, url) {
    return SSR.render('email-reset_password-' + User(user).getLocale(), {
        user: user,
        url: url.replace('/#', '')
    });
};

/**
 * Verify Email
 */
Accounts.emailTemplates.verifyEmail.subject = function(user) {
    return TAPi18n.__('emails-verify-account-subject', {}, User(user).getLocale());
};
Accounts.emailTemplates.verifyEmail.html = function(user, url) {
    return SSR.render('email-verify_account-' + User(user).getLocale(), {
        user: user,
        url: url.replace('/#', ''),
        count: Meteor.users.find().count() - 1
    });
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/helpers/collection.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var pluralize = Npm.require('pluralize');

/**
 * Find one document, throw an error if it doesn't exist.
 *
 * @method findOneOrFail
 * @return {mixed}
 * @memberof Mongo.Collection
 */
Mongo.Collection.prototype.findOneOrFail = function(selector, options) {
    var partup = this.findOne(selector, options);

    if (!partup) {
        var singular = pluralize.singular(this._name);
        var name = singular.charAt(0).toUpperCase() + singular.slice(1);
        throw new Meteor.Error(404, name + '_could_not_be_found');
    }

    return partup;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var events = Npm.require('eventemitter2');

/**
 * The global event emitter instance.
 *
 * @type {EventEmitter2}
 * @namespace Event
 */
Event = new events.EventEmitter2({
    wildcard: true,
    delimiter: '.'
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/collection_hooks.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// For the collection events documentation, see [https://github.com/matb33/meteor-collection-hooks].
var equal = Npm.require('deeper');

/**
 * Generate a basic after insert handler.
 *
 * @param {String} namespace
 * @return {function}
 * @ignore
 */
var basicAfterInsert = function(namespace) {
    return function(userId, document) {
        Event.emit(namespace + '.inserted', userId, document);
    };
};

/**
 * Generate a basic after update handler.
 *
 * @param {String} namespace
 *
 * @return {function}
 * @ignore
 */
var basicAfterUpdate = function(namespace) {
    return function(userId, document, fieldNames, modifier, options) {
        Event.emit(namespace + '.updated', userId, document, this.previous);

        if (this.previous) {
            var previous = this.previous;

            fieldNames.forEach(function(key) {
                var value = {
                    'name': key,
                    'old': previous[key],
                    'new': document[key]
                };

                if (equal(value.old, value.new)) return;

                Event.emit(namespace + '.' + key + '.changed', userId, document, value);
            });
        }
    };
};

/**
 * Generate a basic after remove handler.
 *
 * @param {String} namespace
 *
 * @return {function}
 * @ignore
 */
var basicAfterRemove = function(namespace) {
    return function(userId, document) {
        Event.emit(namespace + '.removed', userId, document);
    };
};

// Partup Events
Partups.after.insert(basicAfterInsert('partups'));
Partups.after.update(basicAfterUpdate('partups'));
Partups.after.remove(basicAfterRemove('partups'));

// Networks Events
Networks.after.insert(basicAfterInsert('networks'));
Networks.after.update(basicAfterUpdate('networks'));
Networks.after.remove(basicAfterRemove('networks'));

// Activity Events
Activities.after.insert(basicAfterInsert('partups.activities'));
Activities.after.update(basicAfterUpdate('partups.activities'));
Activities.after.remove(basicAfterRemove('partups.activities'));

// Update Events
Updates.hookOptions.after.update = {fetchPrevious: false};
Updates.after.insert(basicAfterInsert('partups.updates'));
Updates.after.update(basicAfterUpdate('partups.updates'));
Updates.after.remove(basicAfterRemove('partups.updates'));

// Contribution Events
Contributions.after.insert(basicAfterInsert('partups.contributions'));
Contributions.after.update(basicAfterUpdate('partups.contributions'));
Contributions.after.remove(basicAfterRemove('partups.contributions'));

// Ratings Events
Ratings.after.insert(basicAfterInsert('partups.contributions.ratings'));
Ratings.after.update(basicAfterUpdate('partups.contributions.ratings'));
Ratings.after.remove(basicAfterRemove('partups.contributions.ratings'));

// Notifications Events
Notifications.after.insert(basicAfterInsert('partups.notifications'));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/factories/updates_factory.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Partup updates factory
 @name Partup.factories.updatesFactory
 @memberof Partup.factories
 */
Partup.factories.updatesFactory = {

    /**
     * Make a new update
     *
     * @param  {int} userId
     * @param  {int} partupId
     * @param  {string} updateType
     * @param  {mixed} updateTypeData
     *
     * @return {Update}
     */
    make: function(userId, partupId, updateType, updateTypeData) {
        var update = {};

        if (!userId) throw new Meteor.Error(500, 'Required argument [userId] is missing for method [Partup.factories.updatesFactory::make]');
        if (!partupId) throw new Meteor.Error(500, 'Required argument [partupId] is missing for method [Partup.factories.updatesFactory::make]');
        if (!updateType) throw new Meteor.Error(500, 'Required argument [updateType] is missing for method [Partup.factories.updatesFactory::make]');
        if (!updateTypeData) throw new Meteor.Error(500, 'Required argument [updateTypeData] is missing for method [Partup.factories.updatesFactory::make]');

        update.upper_id = userId;
        update.partup_id = partupId;
        update.type = updateType;
        update.type_data = updateTypeData;
        update.comments_count = 0;
        update.created_at = new Date();
        update.updated_at = new Date();
        update.upper_data = [];

        return update;
    },

    /**
     * Make a new update made by the system
     *
     * @param  {int} partupId
     * @param  {string} updateType
     * @param  {mixed} updateTypeData
     *
     * @return {Update}
     */
    makeSystem: function(partupId, updateType, updateTypeData) {
        var update = {};

        if (!partupId) throw new Meteor.Error(500, 'Required argument [partupId] is missing for method [Partup.factories.updatesFactory::make]');
        if (!updateType) throw new Meteor.Error(500, 'Required argument [updateType] is missing for method [Partup.factories.updatesFactory::make]');
        if (!updateTypeData) throw new Meteor.Error(500, 'Required argument [updateTypeData] is missing for method [Partup.factories.updatesFactory::make]');

        update.upper_id = null;
        update.partup_id = partupId;
        update.system = true;
        update.type = updateType;
        update.type_data = updateTypeData;
        update.comments_count = 0;
        update.created_at = new Date();
        update.updated_at = new Date();

        return update;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/cache_service.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:cache');

var cache = {};

/**
 @namespace Partup server cache service
 @name Partup.server.services.cache
 @memberof Partup.server.services
 */
Partup.server.services.cache = {

    set: function(key, value, ttl) {
        ttl = ttl || false;

        var data = {
            value: value,
            ttl: ttl * 1000,
            timestamp: Date.now()
        };

        d('Cache value written [' + key + ']');

        mout.object.set(cache, key, data);
    },

    get: function(key) {
        var data = mout.object.get(cache, key);

        if (data) {
            d('Cache value read [' + key + ']');

            return data.value;
        }
    },

    has: function(key) {
        var data = mout.object.get(cache, key);

        if (!data) return false;

        if (data.ttl && (data.timestamp + data.ttl) < Date.now()) {
            mout.object.unset(cache, key);

            return false;
        }

        return true;
    },

    clear: function() {
        cache = {};
    }

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/notifications_service.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
'use strict';

var NotificationModel = Npm.require('part-up-js-models').NotificationModel;

var d = Debug('services:notifications');

// Check notifications.md for all active notifications

/**
 @namespace Partup server notifications service
 @name Partup.server.services.notifications
 @memberof Partup.server.services
 */
Partup.server.services.notifications = {
    /**
     * Make a new notification
     *
     * @param  {object} options
     */
    send: function(options) {
        options = options || {};
        var notification = {};

        if (!options.userId) throw new Meteor.Error('Required argument [options.userId] is missing for method [Partup.server.services.notifications::send]');
        if (!options.type) throw new Meteor.Error('Required argument [options.type] is missing for method [Partup.server.services.notifications::send]');
        if (!options.typeData) throw new Meteor.Error('Required argument [options.typeData] is missing for method [Partup.server.services.notifications::send]');

        // If conversation notification, check if there is already an unread notification from the same user on this topic
        if (options.type === 'partups_new_comment_in_involved_conversation') {
            var isAlreadyNotified = Notifications.findOne({
                for_upper_id: options.userId,
                new: true,
                'type_data.update._id': options.typeData.update._id,
                'type_data.commenter._id': options.typeData.commenter._id
            });
            // Nothing else to do here
            if (isAlreadyNotified) return;
        }

        notification.for_upper_id = options.userId;
        notification.type = options.type;
        notification.type_data = options.typeData;
        notification.created_at = new Date();
        notification.new = true;
        notification.clicked = false;

        d('Notification created for user [' + notification.for_upper_id + '] with type [' + notification.type + ']');

        notification._id = Notifications.insert(notification);

        // Send push notification
        var receivers = [notification.for_upper_id];
        var filterDevices = function() {
            return true;
        }; // all devices
        var n = new NotificationModel(notification);
        var message = n.getText(function(key, data) {

            // Issue #436
            if (key === 'notification-partups_archived') {
                key = 'notification-partup_archived_by_upper';
            }
            if (key === 'notification-partups_unarchived') {
                key = 'notification-partup_unarchived_by_upper';
            }

            key = 'dropdown-' + key; // Issue #437

            return TAPi18n.__(key, data.replace);
        });

        var payload = {
            notification: {
                _id: n._id,
                type: n.type,
                type_data: n.type_data,
                created_at: n.created_at
            }
        };

        Partup.server.services.pushnotifications.send(receivers, filterDevices, message, payload);
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/pushnotifications_service.js                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
'use strict';

var apn = Npm.require('apn'); // Apple Push Notification
var gcm = Npm.require('gcm'); // Google Cloud Messaging

var sendApnNotification;
var sendGcmNotification;

Meteor.startup(function() {

    /**
     * Apple Push Notification
     */
    if (process.env.PUSH_APPLE_APN_PFX) {
        var apnConnection = new apn.Connection({
            pfx: new Buffer(process.env.PUSH_APPLE_APN_PFX, 'base64'),
        });

        sendApnNotification = function(device, user, message, payload, badge) {
            var apnDevice = new apn.Device(device.registration_id);
            var note = new apn.Notification();

            note.badge = badge;
            note.alert = message;
            note.payload = payload;

            apnConnection.pushNotification(note, apnDevice);
        };
    }

    /**
     * Google Cloud Messaging
     */
    if (process.env.PUSH_GOOGLE_GCM_API) {
        var gcmConnection = new gcm.GCM(
            process.env.PUSH_GOOGLE_GCM_API
        );

        sendGcmNotification = function(device, user, message, payload, collapseKey) {
            var note = {
                registration_id: device.registration_id,
                'data.title': 'Part-up',
                'data.body': message
            };

            if (collapseKey) {
                note.collapse_key = collapseKey;
            }


            // _.forOwn(payload || {}, function(val, key) {
            //     note['data.' + key] = val;
            // });

            gcmConnection.send(note, function(err, messageId) {
                if (err) {
                    console.log(err);
                }
                console.log("sent message with ID: ", messageId);
            });
        };
    }
});

/**
 @namespace Partup server app notifications service
 @name Partup.server.services.pushnotifications
 @memberof Partup.server.services
 */
Partup.server.services.pushnotifications = {

    /**
     * Send app notifications to all mobile phones of a set of users
     *
     * @param userIds {Array} - users you want to deliver the notification to
     * @param filterDevices {Function} - optional filter function for devices (first arg is `device`, second arg is `user`)
     * @param message {String} - message of the notification
     * @param payload {Object} - payload for the app to receive on notification tap
     * @param collapseKey {String} - collapse notifications with the same collapseKey
     */
    send: function(userIds, filterDevices, message, payload, collapseKey) {
        userIds.forEach(function(id) {
            var user = Meteor.users.findOne(id);
            check(user, Object);

            var devices = (user.push_notification_devices || [])
                .filter(function(device) {
                    if (!filterDevices) return true;
                    return filterDevices(device, user);
                });

            if (devices.length > 0) {

                var badge;
                devices.forEach(function(device) {
                    if (device.platform === 'iOS') {
                        if (typeof badge === 'undefined') {
                            badge = User(user).calculateApplicationIconBadgeNumber();
                        }

                        if (sendApnNotification) {
                            sendApnNotification(device, user, message, payload, badge);
                        }
                    } else if (device.platform === 'Android') {
                        if (sendGcmNotification) {
                            sendGcmNotification(device, user, message, payload, collapseKey);
                        }
                    }
                });
            }
        });
    }

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/system_messages_service.js                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Partup server system messages service
 @name Partup.server.services.system_messages
 @memberof Partup.server.services
 */
Partup.server.services.system_messages = {

    /**
     * Create a system message
     *
     * @param  {mixed[]} upper
     * @param  {string} updateId
     * @param  {string} content
     * @param  {object} settings
     * @param  {boolean} settings.update_timestamp defaults to true
     *
     * @return {Update}
     */
    send: function(upper, updateId, content, settings) {
        var _settings = {
            update_timestamp: true
        };

        if (settings && !mout.lang.isUndefined(settings.update_timestamp)) {
            _settings.update_timestamp = !!settings.update_timestamp;
        }

        try {
            var update = Updates.findOneOrFail(updateId);

            // skip the system message if it was the same as the last one
            var lastComment = update.getLastComment();
            if (lastComment.content == content) return false;

            var query = {
                $push: {
                    comments: {
                        _id: Random.id(),
                        content: content,
                        type: 'system',
                        creator: {
                            _id: upper._id,
                            name: upper.profile.name
                        },
                        created_at: new Date(),
                        updated_at: new Date()
                    }
                }
            };

            if (_settings.update_timestamp) mout.object.set(query, '$set.updated_at', new Date());

            Updates.update(update._id, query);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'system-message-insert-failure');
        }
    }

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/email_service.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:emails');

/**
 @namespace Partup server email service
 @name Partup.server.services.emails
 @memberof Partup.server.services
 */
Partup.server.services.emails = {
    /**
     * Send an email
     *
     * @param {Object} options
     * @param {String} options.type
     * @param {Object} options.typeData
     * @param {String} options.toAddress
     * @param {String} options.fromAddress
     * @param {String} options.subject
     * @param {String} options.locale
     * @param {Object} options.userEmailPreferences
     * @param {String|null} options.body
     */
    send: function(options) {
        options = options || {};
        var emailSettings = {};

        if (!options.type) throw new Meteor.Error('Required argument [options.type] is missing for method [Partup.server.services.emails::send]');
        if (!options.typeData) throw new Meteor.Error('Required argument [options.typeData] is missing for method [Partup.server.services.emails::send]');
        if (!options.toAddress) throw new Meteor.Error('Required argument [options.toAddress] is missing for method [Partup.server.services.emails::send]');
        if (!options.fromAddress) options.fromAddress = Partup.constants.EMAIL_FROM;
        if (!options.subject) throw new Meteor.Error('Required argument [options.subject] is missing for method [Partup.server.services.emails::send]');
        if (!options.locale) throw new Meteor.Error('Required argument [options.locale] is missing for method [Partup.server.services.emails::send]');

        // Check if user has disabled this email type
        if (options.userEmailPreferences && !options.userEmailPreferences[options.type]) {
            // This mail is disabled, so end here
            return;
        }

        options.typeData.baseUrl = Meteor.absoluteUrl();

        emailSettings.from = options.fromAddress;
        emailSettings.to = options.toAddress;
        emailSettings.subject = options.subject;

        // Check if locale needs a fallback to provide an existing mail template
        if (options.locale !== 'en' && options.locale !== 'nl') {
            options.locale = 'en';
        }

        var template = 'email-' + options.type + '-' + options.locale;
        emailSettings.html = SSR.render(template, options.typeData);
        emailSettings.headers = {
            'X-Mailgun-Tag': template
        };

        Email.send(emailSettings);
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/images_service.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var gm = Npm.require('gm').subClass({imageMagick: true});
var path = Npm.require('path');

/**
 @namespace Partup server images service
 @name Partup.server.services.images
 @memberof Partup.server.services
 */
Partup.server.services.images = {

    /**
     * Upload (and resize) an image
     *
     * @param {String} filename
     * @param {String} body
     * @param {String} mimetype
     * @param {Object} options
     * @param {String} options._id
     * @param {Object} options.meta
     */
    upload: function(filename, body, mimetype, options) {
        var s3 = new AWS.S3({params: {Bucket: process.env.AWS_BUCKET_NAME}});

        var options = options || {};
        var meta = options.meta || {};
        var id = options.id || Random.id();

        var extension = path.extname(filename);
        var filename = id + extension;

        var image = {
            _id: id,
            name: filename,
            type: mimetype,
            copies: {},
            createdAt: new Date(),
            meta: meta
        };

        var filekey = id + '-' + filename;

        // TODO (extra): Add .autoOrient() to gm calls

        s3.putObjectSync({Key: 'images/' + filekey, Body: body, ContentType: mimetype});
        image.copies['original'] = {key: 'images/' + filekey, size: body.length};

        var sizes = [{w:32, h:32}, {w:80, h:80}, {w:360, h:360}, {w:1200, h:520}];

        var resize = function(filename, body, width, height, callback) {
            gm(body, filename).resize(width, height).toBuffer(function(error, resizedBody) {
                if (error) return callback(error);
                return callback(null, resizedBody);
            });
        };

        var resizeSync = Meteor.wrapAsync(resize);

        sizes.forEach(function(size) {
            var directory = size.w + 'x' + size.h;
            var resizedBody = resizeSync(filename, body, size.w, size.h);
            image.copies[directory] = {key: 'images/' + filekey, size: resizedBody.length};
            s3.putObjectSync({Key: directory + '/images/' + filekey, Body: resizedBody, ContentType: mimetype});
        });

        Images.insert(image);

        return image;
    },

    /**
     * Store a focuspoint in an image
     *
     * @param {string} imageId
     * @param {number} focuspoint_x
     * @param {number} focuspoint_y
     */
    storeFocuspoint: function(imageId, focuspoint_x, focuspoint_y) {

        if (!imageId) throw new Error('Required argument [imageId] is missing for method [Partup.server.services.images::storeFocuspoint]');
        if (!mout.lang.isNumber(focuspoint_x)) throw new Error('Required argument [focuspoint_x] is not a number for method [Partup.server.services.images::storeFocuspoint]');
        if (!mout.lang.isNumber(focuspoint_y)) throw new Error('Required argument [focuspoint_y] is not a number for method [Partup.server.services.images::storeFocuspoint]');
        if (focuspoint_x < 0 || focuspoint_x > 1) throw new Error('Argument [focuspoint_x] is not a number between 0 and 1 for method [Partup.server.services.images::storeFocuspoint]');
        if (focuspoint_y < 0 || focuspoint_y > 1) throw new Error('Argument [focuspoint_y] is not a number between 0 and 1 for method [Partup.server.services.images::storeFocuspoint]');

        var image = Images.findOne(imageId);
        if (!image) throw new Error('Could not find an image by [imageId] for method [Partup.server.services.images::storeFocuspoint]');

        var focuspoint = {
            x: focuspoint_x,
            y: focuspoint_y
        };

        Images.update(imageId, {$set: {focuspoint: focuspoint}});

    }

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/google_service.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:google');

/**
 @namespace Partup server google service
 @name Partup.server.services.google
 @memberof Partup.server.services
 */
Partup.server.services.google = {

    searchCities: function(query) {
        var key = process.env.GOOGLE_API_KEY;
        var placesAutocomplete = PlacesAutocompletes.findOne({query: query});

        if (placesAutocomplete) {
            d('Autocompleted cities for [' + query + '] from Cache');
            return placesAutocomplete.places;
        }

        // For more details: https://developers.google.com/places/webservice/autocomplete
        var response = HTTP.get('https://maps.googleapis.com/maps/api/place/autocomplete/json?key=' + key + '&input=' + encodeURIComponent(query) + '&types=(cities)');

        if (response.statusCode !== 200) {
            Log.error('Google places api returned with a [' + response.statusCode + ']', response);
            return [];
        }

        var data = get(response, 'data.predictions');

        if (!data) return [];

        PlacesAutocompletes.insert({query: query, created_at: new Date, places: data});

        d('Autocompleted cities for [' + query + '] from Google');

        return data;
    },

    getCity: function(googlePlaceId) {
        var key = process.env.GOOGLE_API_KEY;
        var place = Places.findOne({place_id: googlePlaceId});

        if (place) {
            d('Loaded city with placeId [' + googlePlaceId + '] from Cache');
            return place;
        }

        // For more details: https://developers.google.com/places/webservice/details
        var response = HTTP.get('https://maps.googleapis.com/maps/api/place/details/json?key=' + key + '&placeid=' + googlePlaceId);

        if (response.statusCode !== 200) {
            Log.error('Google places api returned with a [' + response.statusCode + ']', response);
            return false;
        }

        var data = mout.object.get(response, 'data.result');

        if (!data) return false;

        data.place_id = googlePlaceId;
        data.created_at = new Date;

        d('Loaded city with placeId [' + googlePlaceId + '] from Google');

        // Insert new location
        Places.insert(data);

        // Return the retrieved data object
        return data;
    },

    detectLanguage: function(query) {
        var defaultValue = 'en';
        if (!query) return defaultValue;

        var key = process.env.GOOGLE_API_KEY;

        try {
            // For more details: https://cloud.google.com/translate/v2/using_rest?hl=en#detect-language
            var response = HTTP.get('https://www.googleapis.com/language/translate/v2/detect?key=' + key + '&q=' + query);
        } catch (error) {
            Log.error('Error while detecting language: ' + error);
            return defaultValue;
        }

        if (response.statusCode !== 200) {
            return defaultValue;
        }

        if (response.error) return defaultValue;
        if (response.data.error) return defaultValue;

        var data = mout.object.get(response, 'data.data.detections')[0][0];
        var language = data.language;

        if (!language) return defaultValue;

        d('Detected language for [' + query + '] ("' + language + '") from Google');

        return language;
    }

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/matching_service.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Partup server matching service
 @name Partup.server.services.matching
 @memberof Partup.server.services
 */
Partup.server.services.matching = {
    /**
     * Match uppers for a given activity
     *
     * @param {String} activityId
     * @param {Object} searchOptions
     * @param {String} searchOptions.query
     * @param {Number} searchOptions.limit
     * @param {Number} searchOptions.skip
     *
     * @return {[String]}
     */
    matchUppersForActivity: function(activityId, searchOptions) {
        var activity = Activities.findOneOrFail(activityId);
        var partup = Partups.findOneOrFail(activity.partup_id);
        var tags = partup.tags || [];
        var uppers = partup.uppers || [];

        return this.findMatchingUppers(searchOptions, tags, uppers);
    },

    /**
     * Match uppers for a given network
     *
     * @param {String} networkSlug
     * @param {Object} searchOptions
     * @param {String} searchOptions.query
     * @param {Number} searchOptions.limit
     * @param {Number} searchOptions.skip
     *
     * @return {[String]}
     */
    matchUppersForNetwork: function(networkSlug, searchOptions) {
        var network = Networks.findOneOrFail({slug: networkSlug});
        var tags = network.tags || [];
        var uppers = network.uppers || [];

        return this.findMatchingUppers(searchOptions, tags, uppers);
    },

    /**
     * Match uppers for a given partup
     *
     * @param {String} partupId
     * @param {Object} searchOptions
     * @param {String} searchOptions.query
     * @param {Number} searchOptions.limit
     * @param {Number} searchOptions.skip
     *
     * @return {[String]}
     */
    matchUppersForPartup: function(partupId, searchOptions) {
        var partup = Partups.findOneOrFail(partupId);
        var tags = partup.tags || [];
        var uppers = partup.uppers || [];

        return this.findMatchingUppers(searchOptions, tags, uppers);
    },

    /**
     * Find uppers that match with the provided criteria
     *
     * @param {Object} searchOptions
     * @param {String} searchOptions.query
     * @param {Number} searchOptions.limit
     * @param {Number} searchOptions.skip
     * @param {[String]} tags
     * @param {[String]} excludedUppers
     * @return {[String]}
     */
    findMatchingUppers: function(searchOptions, tags, excludedUppers) {
        var selector = {};

        // Exclude the current logged in user from the results
        selector['_id'] = {$nin: [Meteor.userId()]};

        if (searchOptions.query !== '') {
            // Remove accents that might have been added to the query
            var searchQuery = mout.string.replaceAccents(searchOptions.query.toLowerCase());

            // Set the search criteria
            var searchCriteria = [
                {'profile.normalized_name': new RegExp('.*' + searchQuery + '.*', 'i')},
                {'profile.description': new RegExp('.*' + searchQuery + '.*', 'i')},
                {'profile.tags': new RegExp('.*' + searchQuery + '.*', 'i')},
                {'profile.location.city': new RegExp('.*' + searchQuery + '.*', 'i')}
            ];

            // search for separate tags if multiple words are detected in searchQuery
            var multipleWordsQuery = searchQuery.split(' ');
            if (multipleWordsQuery.length > 1) {
                searchCriteria.push({'profile.tags': {$in: multipleWordsQuery}});
            }

            // Combine it in an $or selector
            selector = {$and: [selector, {$or: searchCriteria}]};
        } else {
            // No search query is provided, so match the uppers on the provided tags
            tags = tags || [];
            selector['profile.tags'] = {$in: tags};

            // Exclude provided uppers from result
            excludedUppers = excludedUppers || [];
            selector['_id'] = {$nin: excludedUppers};
        }

        // Set options
        var options = {
            limit: searchOptions.limit ? parseInt(searchOptions.limit) : 10,
            skip: searchOptions.skip ? parseInt(searchOptions.skip) : 0,
            sort: {participation_score: -1}, // Sort the uppers on participation_score
            fields: {_id: 1} // Only return the IDs
        };

        var results = Meteor.users.findActiveUsers(selector, options).fetch();

        // If there are no results, we remove some matching steps (only when no search options were provided)
        if (!searchOptions.query) {
            var iteration = 0;
            while (results.length === 0) {
                if (iteration === 0) delete selector['profile.tags'];

                results = Meteor.users.findActiveUsers(selector, options).fetch();
                iteration++;
            }
        }

        return results;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/slugify_service.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var slugify = Npm.require('slug');
var d = Debug('services:slugify');

/**
 @namespace Partup server slugify service
 @name Partup.server.services.slugify
 @memberof Partup.server.services
 */
Partup.server.services.slugify = {

    /**
     * Slugify a string
     *
     * @param  {String} value
     *
     * @return {String}
     */
    slugify: function(value) {
        var slug = slugify(value).toLowerCase();

        d('Slugified [' + value + '] to [' + slug + ']');

        return slug;
    },

    /**
     * Generate a slug in the following form:
     *
     * {slugified-property-value}-{document-id}
     *
     * Example: lifely-s-partup-12345
     *
     * @param  {Document} document
     * @param  {string} property
     */
    slugifyDocument: function(document, property) {
        var value = document[property];
        var slug = slugify(value).toLowerCase() + '-' + document._id;

        d('Slugified [' + value + '] to [' + slug + ']');

        return slug;
    }

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/participation_calculator_service.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:participation_calculator');

/**
 @namespace Partup server participation calculator service
 @name Partup.server.services.participation_calculator
 @memberof Partup.server.services
 */
Partup.server.services.participation_calculator = {

    calculateParticipationScoreForUpper: function(upperId) {
        var score = 0;
        var upper = Meteor.users.findOneOrFail(upperId);

        var score1 = this._calculateLoginScore(upper);
        var score1weight = 0.25;
        d('Login score for user [' + upperId + '] is ' + score1 + '/100 and counts for 25% → ' + (score1 * score1weight) + '/100');
        score += score1 * score1weight;

        var score2 = this._calculateSupportsRecentPartupsScore(upper);
        var score2weight = 0.25;
        d('Supports recent partups score for user [' + upperId + '] is ' + score2 + '/100 and counts for 25% → ' + (score2 * score2weight) + '/100');
        score += score2 * score2weight;

        var score3 = this._calculateAverageContributionRatingScore(upper);
        var score3weight = 0.25;
        d('Average contribution rating score for user [' + upperId + '] is ' + score3 + '/100 and counts for 25% → ' + (score3 * score3weight) + '/100');
        score += score3 * score3weight;

        var score4 = this._calculateActiveContributionsScore(upper);
        var score4weight = 0.25;
        d('Active contributions score for user [' + upperId + '] is ' + score4 + '/100 and counts for 25% → ' + (score4 * score4weight) + '/100');
        score += score4 * score4weight;

        d('Total participation score for user [' + upperId + '] is ' + score + '/100');

        return Math.min(100, score);
    },

    _calculateActiveContributionsScore: function(upper) {
        var activeContributionsScore = 0;

        // By using a score delta of 4, an upper can receive the full
        // 100 score of this part by having 25 active contributions
        var scoreDelta = 4;

        var contributions = Contributions.find({upper_id: upper._id, verified:true});

        contributions.forEach(function(contribution) {
            var partup = Partups.findOne(contribution.partup_id);

            if (partup && !partup.hasEnded()) {
                activeContributionsScore += scoreDelta;
            }
        });

        return Math.min(100, activeContributionsScore);
    },

    _calculateAverageContributionRatingScore: function(upper) {
        return Math.min(100, upper.average_rating || 0);
    },

    _calculateSupportsRecentPartupsScore: function(upper) {
        var supports = upper.supporterOf || [];
        var partups = Partups.find({_id: {'$in': supports}});

        var supportsRecentPartupsScore = 0;

        // By using a score delta of 4, an upper can receive the full
        // 100 score of this part by supporting 25 active partups
        var scoreDelta = 4;

        partups.forEach(function(partup) {
            if (!partup.hasEnded()) {
                supportsRecentPartupsScore += scoreDelta;
            }
        });

        return Math.min(100, supportsRecentPartupsScore);
    },

    _calculateLoginScore: function(upper) {
        var logins = upper.logins || [];

        var loginScore = 0;

        // By using a score delta of 4, an upper can receive the full
        // 100 score of this part by logging in 25 days consecutively
        var scoreDelta = 4;

        var day = 24 * 60 * 60 * 1000;
        var now = new Date;
        var createdAt = new Date(upper.createdAt);
        var createdDaysAgo = (now - createdAt) / day;

        var maximumDaysAgoToGiveScore = 25;

        if (createdDaysAgo <= maximumDaysAgoToGiveScore) {
            loginScore += scoreDelta * (maximumDaysAgoToGiveScore - createdDaysAgo);
        }

        logins.forEach(function(login) {
            var daysBetweenLoginAndNow = Math.round(Math.abs((login.getTime() - now.getTime()) / day));

            if (daysBetweenLoginAndNow <= maximumDaysAgoToGiveScore) {
                loginScore += scoreDelta;
            }
        });

        return Math.min(100, loginScore);
    }

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/partup_progress_calculator_service.js                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:partup_progress_calculator');

/**
 @namespace Partup server partup progress calculator service
 @name Partup.server.services.partup_progress_calculator
 @memberof Partup.server.services
 */
Partup.server.services.partup_progress_calculator = {

    calculatePartupProgressScore: function(partupId) {
        var score = 0;
        var partup = Partups.findOneOrFail(partupId);

        var score1 = this._calculateTimeBasedScore(partup);
        d('Time based partup progress score is ' + score1);
        score += score1;

        var score2 = this._calculateUppersBasedScore(partup);
        var score2weight = 0.1;
        d('Upper based partup progress score is ' + (score2 * score2weight));
        score += (score2 * score2weight);

        var score3 = this._calculateActivitiesBasedScore(partup);
        var score3weight = 0.8;
        d('Activities based partup progress score is ' + (score3 * score3weight));
        score += (score3 * score3weight);

        return Math.max(0, Math.min(100, score));
    },

    _calculateActivitiesBasedScore: function(partup) {
        var score = 0;
        var activities = Activities.findForPartup(partup);

        activities.forEach(function(activity) {
            if (activity.isClosed()) score += 20;
            else score -= 10;
        });

        return Math.min(100, score);
    },

    _calculateUppersBasedScore: function(partup) {
        var uppers = partup.uppers || [];
        var score = (uppers.length * (1 / 3)) * 100;

        return Math.min(100, score);
    },

    _calculateTimeBasedScore: function(partup) {
        if (partup.hasEnded()) return 100;

        var day = 1000 * 60 * 60 * 24;

        var now = new Date();
        var endsAt = new Date(partup.end_date);
        var createdAt = new Date(partup.created_at);

        var daysTotal = (endsAt - createdAt) / day;
        var daysExists = (now - createdAt) / day;

        var percentage = (daysExists / daysTotal) * 100;

        var score = Math.pow((0.0465 * percentage), 3);

        return Math.min(100, score);
    }

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/shared_count_service.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:shared_count');

/**
 @namespace Partup server shared count service
 @name Partup.server.services.shared_count
 @memberof Partup.server.services
 */
Partup.server.services.shared_count = {
    facebook: function(url) {
        var response = HTTP.get('http://graph.facebook.com/?id=' + url);

        if (response.statusCode !== 200) {
            Log.error('Facebook Graph API resulted in status code [' + response.statusCode + ']', response);
            return false;
        }

        var data = mout.object.get(response, 'data');
        if (!data) return false;

        return data.shares ? data.shares : 0;
    },

    twitter: function(url) {
        var response = HTTP.get('https://cdn.api.twitter.com/1/urls/count.json?url=' + url);

        if (response.statusCode !== 200) {
            Log.error('Twitter shared count API resulted in status code [' + response.statusCode + ']', response);
            return false;
        }

        var data = mout.object.get(response, 'data');
        if (!data) return false;

        return data.count;
    },

    linkedin: function(url) {
        var response = HTTP.get('https://www.linkedin.com/countserv/count/share?format=json&url=' + url);

        if (response.statusCode !== 200) {
            Log.error('LinkedIn shared count API resulted in status code [' + response.statusCode + ']', response);
            return false;
        }

        var data = mout.object.get(response, 'data');
        if (!data) return false;

        return data.count;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/language_service.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var CountryLanguage = Npm.require('country-language');
var d = Debug('services:language');

/**
 @namespace Partup server language service
 @name Partup.server.services.language
 @memberof Partup.server.services
 */
Partup.server.services.language = {
    /**
     * Get native language name from a country code
     *
     * @param {String} languageCode
     *
     * @return {String}
     */
    nativeLanguageName: function(languageCode) {
        return CountryLanguage.getLanguage(languageCode, function(error, languages) {
            if (error) {
                Log.error('Error while trying to get native language name from languageCode [' + languageCode + ']: ' + error);
            } else {
                var nativeName = languages.nativeName[0].toLocaleLowerCase();

                d('Got language name [' + nativeName + '] from country code [' + languageCode + ']');

                return nativeName;
            }
        });
    },

    addNewLanguage: function(languageCode) {
        if (!Languages.findOne({_id: languageCode})) {
            var nativeLanguageName = this.nativeLanguageName(languageCode);
            Languages.insert({_id: languageCode, native_name: nativeLanguageName});
        }
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/locale_service.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Partup server locale service
 @name Partup.server.services.locale
 @memberof Partup.server.services
 */
Partup.server.services.locale = {
    /**
     * Return a user's locale
     *
     * @param  {string} ipAddress
     * @return {String}
     */
    get_locale: function(ipAddress) {
        var DEFAULT_LOCALE = 'en';

        try {
            var response = HTTP.get('http://ip-api.com/json/' + ipAddress);

            if (response.statusCode !== 200) {
                Log.error('IP API resulted in an error [' + response.statusCode + ']', response);
                return DEFAULT_LOCALE;
            }

            var data = get(response, 'data');

            if (data.status !== 'success') {
                Log.error('IP API had unsuccessful results, returning default locale');
                return DEFAULT_LOCALE;
            }

            var countryCode = data.countryCode.toLocaleLowerCase();
            var locale = countryCode === 'nl' ? 'nl' : DEFAULT_LOCALE; // Must be either Dutch or English
            Log.debug('Got country code [' + countryCode + ']. Returning [' + locale + ']');

            return locale;
        } catch (error) {
            Log.error('Error while retrieving country data from IP: ' + error);
            return DEFAULT_LOCALE;
        }
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/meurs_service.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:meurs');

var meursCall = function(url, data) {
    try {
        var result = HTTP.post(url, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            data: data
        });

        if (result.statusCode !== 200 || result.data.errors.length > 0) {
            // Check if there is a fallback that can save the day
            var error = result.data.errors[0]; // Always just 1 error
            if (error.code == 59 && error.messageProp == 'authenticatorErrorInvalidUsernameExists') {
                // User already has a q4youId, so let's find and return it
                var q4youId = Partup.server.services.meurs.getExistingQ4youId(data.authToken, data.userName);
                if (q4youId) {
                    // Set the retrieved ID
                    result.data.q4youID = q4youId;
                    return result;
                }
            }

            Log.error('[Meurs API Error] Url: [' + url + ']. Status code: [' + result.statusCode + ']. Errors: ', result.data.errors);
            throw new Meteor.Error(400, '[Meurs API Error] Url: [' + url + ']. Status code: [' + result.statusCode + ']. Errors: ', result.data.errors);
        }

        // No errors
        return result;
    } catch (error) {
        Log.error(error);
        throw new Meteor.Error(400, '[Meurs API Exception] Url: [' + url + ']. Errors: ', error);
    }
};

/**
 @namespace Partup server meurs service
 @name Partup.server.services.meurs
 @memberof Partup.server.services
 */
Partup.server.services.meurs = {
    getToken: function(portal) {
        var apiKey = process.env.MEURS_EN_API_KEY;
        var apiSecret = process.env.MEURS_EN_API_SECRET;

        if (portal === 'nl') {
            apiKey = process.env.MEURS_NL_API_KEY;
            apiSecret = process.env.MEURS_NL_API_SECRET;
        }

        var result = meursCall(process.env.MEURS_BASE_URL + 'authenticator/api/authenticate', {
            apiKey: apiKey,
            apiSecret: apiSecret
        });

        return result.data.authToken;
    },

    addUser: function(token, userId, email) {
        if (!token) {
            d('No authentication token given');
            throw new Meteor.Error(400, 'Token needed for Meurs API');
        }

        var result = meursCall(process.env.MEURS_BASE_URL + 'authenticator/api/adduser', {
            authToken: token,
            userName: userId,
            password: '@1Aa' + Random.id(),
            email: email.replace('+', '')
        });

        return result.data.q4youID;
    },

    activateUser: function(token, q4youId) {
        if (!token) {
            d('No authentication token given');
            throw new Meteor.Error(400, 'Token needed for Meurs API');
        }

        var result = meursCall(process.env.MEURS_BASE_URL + 'authenticator/api/activateuser', {
            authToken: token,
            q4youID: q4youId
        });

        return result.data.errors.length < 1;
    },

    getExistingQ4youId: function(token, userName) {
        if (!token) {
            d('No authentication token given');
            throw new Meteor.Error(400, 'Token needed for Meurs API');
        }

        var result = meursCall(process.env.MEURS_BASE_URL + 'authenticator/api/getusers', {
            authToken: token
        });

        var user = lodash.find(result.data.users, function(user) {
            return user.userName == userName;
        });

        return user.id;
    },

    createProgramSessionId: function(portal, token, q4youId) {
        if (!token) {
            d('No authentication token given');
            throw new Meteor.Error(400, 'Token needed for Meurs API');
        }

        var templateId = portal === 'en' ? process.env.MEURS_EN_PROGRAM_TEMPLATE_ID : process.env.MEURS_NL_PROGRAM_TEMPLATE_ID;

        var result = meursCall(process.env.MEURS_BASE_URL + 'q4u/api/createprogramsession', {
            authToken: token,
            q4youID: q4youId,
            programTemplateId: templateId
        });

        return result.data.programSessionId;
    },

    setActiveProgramSession: function(token, q4youId, programSessionId) {
        if (!token) {
            d('No authentication token given');
            throw new Meteor.Error(400, 'Token needed for Meurs API');
        }

        var result = meursCall(process.env.MEURS_BASE_URL + 'q4u/api/setactiveprogramsession', {
            authToken: token,
            q4youID: q4youId,
            programSessionId: programSessionId
        });

        return result.data.errors.length < 1;
    },

    getBrowserToken: function(portal, token, q4youId, returnUrl) {
        if (!token) {
            d('No authentication token given');
            throw new Meteor.Error(400, 'Token needed for Meurs API');
        }

        var serviceId = portal === 'en' ? process.env.MEURS_EN_SERVICE_ID : process.env.MEURS_NL_SERVICE_ID;

        var result = meursCall(process.env.MEURS_BASE_URL + 'q4u/api/getbrowsertoken', {
            authToken: token,
            q4youID: q4youId,
            returnUrl: returnUrl,
            startPageId: 1,
            autoStartServiceId: serviceId
        });

        return result.data.url;
    },

    getServiceSessionData: function(token, q4youId, programSessionId) {
        if (!token) {
            d('No authentication token given');
            throw new Meteor.Error(400, 'Token needed for Meurs API');
        }

        var sessionStatus = meursCall(process.env.MEURS_BASE_URL + 'q4u/api/getservicesessionstatus', {
            authToken: token,
            userIdList: [q4youId]
        });

        // Get the active session data
        var activeSessionData = {};
        sessionStatus.data.result.forEach(function(sessionData) {
            if (sessionData.programSessionId == programSessionId) {
                activeSessionData = sessionData;
            }
        });

        return activeSessionData;
    },

    getResults: function(token, serviceSessionId) {
        if (!token) {
            d('No authentication token given');
            throw new Meteor.Error(400, 'Token needed for Meurs API');
        }

        var sessionResult = meursCall(process.env.MEURS_BASE_URL + 'q4u/api/getservicesessionsresults', {
            authToken: token,
            serviceSessionIds: [serviceSessionId]
        });

        return sessionResult.data.result[0].data.result[0].varScores;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/profile_completeness_service.js                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:profile_completeness');

/**
 @namespace Partup server profile_completeness service
 @name Partup.server.services.profile_completeness
 @memberof Partup.server.services
 */
Partup.server.services.profile_completeness = {
    /**
     * Update new profile completeness percentage
     *
     * @param {Object} user
     */
    updateScore: function(user) {
        user = user || Meteor.user();

        var allFields = [
            'name',
            'image',
            'description',
            'tags',
            'location',
            'facebook_url',
            'twitter_url',
            'instagram_url',
            'linkedin_url',
            'phonenumber',
            'website',
            'skype',
            'tiles',
            'meurs'
        ];
        var providedValues = 0;

        _.each(user.profile, function(value, key) {
            // Don't count empty values
            if (!value || value.length < 1) return;

            // Neglect fields that are not important to this score
            if (allFields.indexOf(key) < 0) return;

            // Handle the special cases
            if (key === 'location' && !value.city) return;
            if (key === 'meurs' && (!value.fetched_results || value.results.length < 1)) return;

            // Valid stuff, add to score count
            providedValues++;
        });

        // Calculate new percentage
        var completeness = Math.round((providedValues * 100) / allFields.length);

        // And update if valid
        if (typeof completeness == 'number') {
            Meteor.users.update(user._id, {$set: {completeness: completeness}});
        }
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/partup_popularity_calculator_service.js                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:partup_popularity_calculator');

/**
 @namespace Partup server partup popularity calculator service
 @name Partup.server.services.partup_popularity_calculator
 @memberof Partup.server.services
 */
Partup.server.services.partup_popularity_calculator = {

    calculatePartupPopularityScore: function(partupId) {
        var partup = Partups.findOneOrFail(partupId);

        var activityScore = this._calculateActivityBasedScore(partup);
        var activityScoreWeight = 0.5;

        var shareScore = this._calculateShareBasedScore(partup);
        var shareScoreWeight = 0.2;

        var partnerScore = this._calculatePartnerBasedScore(partup);
        var partnerScoreWeight = 0.1;

        var supporterScore = this._calculateSupporterBasedScore(partup);
        var supporterScoreWeight = 0.1;

        var viewScore = this._calculateViewBasedScore(partup);
        var viewScoreWeight = 0.1;

        var score = (activityScore * activityScoreWeight) +
            (shareScore * shareScoreWeight) +
            (partnerScore * partnerScoreWeight) +
            (supporterScore * supporterScoreWeight) +
            (viewScore * viewScoreWeight);

        return Math.floor(score);
    },

    _calculateActivityBasedScore: function(partup) {
        var count = 0;
        var now = new Date();
        var two_weeks = 1000 * 60 * 60 * 24 * 14;

        Updates.find({partup_id: partup._id}).forEach(function(update) {
            var updated_at = new Date(update.updated_at);
            if ((now - updated_at) > two_weeks) return; // Don't count the updates that are older than 2 weeks
            count += update.comments_count + 1; // The additional 1 is for the update itself
        });

        if (count > 150) count = 150; // Set limit

        return count / 1.5; // Results in max score of 100%
    },

    _calculateShareBasedScore: function(partup) {
        var count = 0;
        if (!partup.shared_count) return count;
        if (partup.shared_count.facebook) count += partup.shared_count.facebook;
        if (partup.shared_count.twitter) count += partup.shared_count.twitter;
        if (partup.shared_count.linkedin) count += partup.shared_count.linkedin;
        if (partup.shared_count.email) count += partup.shared_count.email;

        return count > 100 ? 100 : count; // Results in max score of 100%
    },

    _calculatePartnerBasedScore: function(partup) {
        var partners = partup.uppers || [];
        var partnerCount = partners.length > 15 ? 15 : partners.length; // Set limit

        return partnerCount / 0.15; // Results in max score of 100%
    },

    _calculateSupporterBasedScore: function(partup) {
        var supporters = partup.supporters || [];

        return supporters.length > 100 ? 100 : supporters.length; // Results in max score of 100%
    },

    _calculateViewBasedScore: function(partup) {
        if (!partup || !partup.analytics) return 0;
        var views = partup.analytics.clicks_total || 0;
        if (views > 500) views = 500;

        return views / 5; // Results in max score of 100%
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/swarms_service.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:swarms');

/**
 @namespace Partup server swarms service
 @name Partup.server.services.swarms
 @memberof Partup.server.services
 */
Partup.server.services.swarms = {
    /**
     * Update the swarm stats
     *
     * @param {Object} swarm
     */
    updateStats: function(swarm) {
        // Initialize stats counters
        var swarm_stats = {
            activity_count: 0,
            network_count: 0,
            partner_count: 0,
            partup_count: 0,
            supporter_count: 0,
            upper_count: 0
        };
        var unique_swarm_uppers = [];
        var unique_swarm_partners = [];
        var unique_swarm_supporters = [];

        // Get all the network IDs to loop through
        var networks = swarm.networks || [];

        // Set the network count
        swarm_stats.network_count = networks.length;

        // Loop through each of the networks to get all partups
        networks.forEach(function(networkId) {
            // Retrieve the network
            var network = Networks.findOne(networkId);

            // Initialize stats counters
            var network_stats = {
                activity_count: 0,
                partner_count: 0,
                partup_count: 0,
                supporter_count: 0,
                upper_count: 0
            };
            var unique_network_partners = [];
            var unique_network_supporters = [];

            // Store the partup IDs to loop through for the activities
            var partups = Partups.find({network_id: network._id, deleted_at: {$exists: false}, archived_at: {$exists: false}}, {_id: 1}).fetch();
            var network_partups = [];
            partups.forEach(function(partup) {
                network_partups.push(partup._id);
            });

            // Update the partup counter with the amount of partups in this network
            network_stats.partup_count = network_partups.length;
            swarm_stats.partup_count += network_stats.partup_count;

            // Update the upper counter with the amount of uppers in this network
            var network_uppers = network.uppers || [];
            network_stats.upper_count = network_uppers.length;
            unique_swarm_uppers.push.apply(unique_swarm_uppers, network_uppers);

            // Loop through each partup to get activity and supporter count
            network_partups.forEach(function(partupId) {
                // Retrieve the partup
                var partup = Partups.findOne(partupId);

                // Update the activity counter with the amount of activities in this partup
                var partup_activity_count = partup.activity_count || 0;
                network_stats.activity_count += partup_activity_count;
                swarm_stats.activity_count += partup_activity_count;

                // Update the partner array
                var partup_partners = partup.uppers || [];
                unique_network_partners.push.apply(unique_network_partners, partup_partners);
                unique_swarm_partners.push.apply(unique_swarm_partners, partup_partners);

                // And lastly, update the supporter array
                var partup_supporters = partup.supporters || [];
                unique_network_supporters.push.apply(unique_network_supporters, partup_supporters);
                unique_swarm_supporters.push.apply(unique_swarm_supporters, partup_supporters);
            });

            // Deduping the network-level dups
            network_stats.partner_count = lodash.unique(unique_network_partners).length;
            network_stats.supporter_count = lodash.unique(unique_network_supporters).length;

            // Update the network with the new stats
            Networks.update(network._id, {
                $set: {
                    stats: network_stats,
                    updated_at: new Date()
                }
            });
        });

        // Deduping the swarm-level dups
        swarm_stats.upper_count = lodash.unique(unique_swarm_uppers).length;
        swarm_stats.partner_count = lodash.unique(unique_swarm_partners).length;
        swarm_stats.supporter_count = lodash.unique(unique_swarm_supporters).length;

        // Update the swarm with the new stats
        Swarms.update(swarm._id, {
            $set: {
                stats: swarm_stats,
                updated_at: new Date()
            }
        });

        // Return the list of network IDs that have been updated
        return networks;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/services/networks_service.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('services:networks');

/**
 @namespace Partup server networks service
 @name Partup.server.services.networks
 @memberof Partup.server.services
 */
Partup.server.services.networks = {
    /**
     * Update the stats of a network
     *
     * @param {Object} network
     */
    updateStats: function(network) {
        // Initialize stats counters
        var network_stats = {
            activity_count: 0,
            partner_count: 0,
            partup_count: 0,
            supporter_count: 0,
            upper_count: 0
        };
        var unique_network_partners = [];
        var unique_network_supporters = [];

        // Store the partup IDs to loop through for the activities
        var partups = Partups.find({network_id: network._id, deleted_at: {$exists: false}, archived_at: {$exists: false}}, {_id: 1}).fetch();
        var network_partups = [];
        partups.forEach(function(partup) {
            network_partups.push(partup._id);
        });

        // Update the partup counter with the amount of partups in this network
        network_stats.partup_count = network_partups.length;

        // Update the upper counter with the amount of uppers in this network
        var network_uppers = network.uppers || [];
        network_stats.upper_count = network_uppers.length;

        // Loop through each partup to get activity and supporter count
        network_partups.forEach(function(partupId) {
            // Retrieve the partup
            var partup = Partups.findOne(partupId);

            // Update the activity counter with the amount of activities in this partup
            var partup_activity_count = partup.activity_count || 0;
            network_stats.activity_count += partup_activity_count;

            // Update the partner array
            var partup_partners = partup.uppers || [];
            unique_network_partners.push.apply(unique_network_partners, partup_partners);

            // And lastly, update the supporter array
            var partup_supporters = partup.supporters || [];
            unique_network_supporters.push.apply(unique_network_supporters, partup_supporters);
        });

        // Deduping the network-level dups
        network_stats.partner_count = lodash.unique(unique_network_partners).length;
        network_stats.supporter_count = lodash.unique(unique_network_supporters).length;

        // Update the network with the new stats
        Networks.update(network._id, {
            $set: {
                stats: network_stats,
                updated_at: new Date()
            }
        });
    },

    /**
     * Calculate the most active uppers of a network
     *
     * @param {Object} network
     */
    calculateActiveUppers: function(network) {
        // Initialization
        var network_uppers = network.uppers || [];
        var network_partners = [];

        Partups.find({network_id: network._id, deleted_at: {$exists: false}, archived_at: {$exists: false}}).fetch().forEach(function(partup) {
            var uppers = partup.uppers || [];
            network_partners.push.apply(network_partners, uppers);
        });

        // We now have all the partners, so sort on frequency
        network_partners = lodash.chain(network_partners).countBy().pairs().sortBy(1).reverse().pluck(0).value();

        // We only want the uppers that are member of the tribe in our array
        var active_uppers = lodash.intersection(network_partners, network_uppers);
        var leftover_uppers = lodash.difference(network_uppers, active_uppers);
        active_uppers.push.apply(active_uppers, leftover_uppers);

        // Update the network with the new stats
        Networks.update(network._id, {
            $set: {
                most_active_uppers: active_uppers.slice(0, 7), // We only need to show 7 uppers
                updated_at: new Date()
            }
        });
    },

    /**
     * Calculate the most active partups of a network
     *
     * @param {Object} network
     */
    calculateActivePartups: function(network) {
        var partups = Partups.find({
            network_id: network._id,
            deleted_at: {$exists: false},
            archived_at: {$exists: false}
        }, {
            fields: {
                _id: 1,
                popularity: 1
            },
            sort: {
                popularity: -1
            },
            limit: 3
        }).fetch();

        // We now have all the partup objects, so transform them into an array containing the IDs
        var popular_partups = [];
        partups.forEach(function(partup) {
            popular_partups.push(partup._id);
        });

        // Update the network with the new stats
        Networks.update(network._id, {
            $set: {
                most_active_partups: popular_partups,
                updated_at: new Date()
            }
        });
    },

    /**
     * Create tags that are common in the underlying partups of the network
     *
     * @param {Object} network
     */
    getCommonTags: function(network) {
        // Initialization
        var partup_tags = [];

        // Get the tags of all partups in this networks in one array
        Partups.find({network_id: network._id, deleted_at: {$exists: false}}).fetch().forEach(function(partup) {
            var tags = partup.tags || [];
            partup_tags.push.apply(partup_tags, tags);
        });

        // We now have all the tags, so sort on frequency
        partup_tags = lodash.chain(partup_tags)
            .countBy()
            .pairs()
            .sortBy(1)
            .reverse()
            .pick(function(value, key) {
                return value[1] > 1; // Only collect the tags that occur more than once
            })
            .value();

        // Create an array of tag objects containing their frequency
        var common_tags = [];
        for (var key in partup_tags) {
            if (partup_tags.hasOwnProperty(key)) {
                var tagArray = partup_tags[key];

                common_tags.push({
                    tag: tagArray[0],
                    frequency: tagArray[1]
                });
            }
        }

        // Update the network
        Networks.update(network._id, {
            $set: {
                common_tags: common_tags,
                updated_at: new Date()
            }
        });
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/seo/routes.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var SeoRouter = Picker.filter(function(request, response) {
    // TODO: Add more checks to see if we should render a snippet

    var botAgents = [
        /^facebookexternalhit/i, // Facebook
        /^linkedinbot/i, // LinkedIn
        /^twitterbot/i, // Twitter
        /^slackbot-linkexpanding/i, // Slack
        /^bingbot/i // Bing
    ];

    var userAgent = request.headers['user-agent'];
    var botIsUsed = false;

    botAgents.forEach(function(botAgent) {
        if (botAgent.test(userAgent)) botIsUsed = true;
    });

    var escapedFragmentIsUsed = /_escaped_fragment_/.test(request.url);

    return escapedFragmentIsUsed || botIsUsed;
});

var renderGeneralInformation = function(request, response) {
    SSR.compileTemplate('seo_home', Assets.getText('private/templates/seo/home.html'));

    Template.seo_home.helpers({
        getHomeUrl: function() {
            return Meteor.absoluteUrl();
        },
        getImageUrl: function() {
            return Meteor.absoluteUrl() + 'images/partup-logo.png';
        }
    });

    var html = SSR.render('seo_home');

    response.setHeader('Content-Type', 'text/html');
    response.end(html);
};

/**
 * Generate a SEO Route for all the routes that are defined for the application
 */
Router.routes.forEach(function(route) {
    if (route && route.getName() !== '(.*)') {
        var path = route.path();

        if (path) {
            SeoRouter.route(path, function(params, request, response) {
                renderGeneralInformation(request, response);
            });
        }
    }
});

/**
 * SEO Route for the Partup detail page
 */
SeoRouter.route('/partups/:slug', function(params, request, response) {
    var slug = params.slug;
    var partupId = slug.split('-').pop();
    var partup = Partups.findOne(partupId);

    if (!partup) {
        response.statusCode = 404;
        return response.end();
    }

    var image = Images.findOne(partup.image);

    SSR.compileTemplate('seo_partup', Assets.getText('private/templates/seo/partup.html'));

    Template.seo_partup.helpers({
        getPartupUrl: function() {
            return Meteor.absoluteUrl() + 'partups/' + partup.slug;
        },
        getImageUrl: function() {
            if (!image) return Meteor.absoluteUrl() + 'images/partup-logo.png';

            return Partup.helpers.url.getImageUrl(image);
        }
    });

    var html = SSR.render('seo_partup', partup);

    response.setHeader('Content-Type', 'text/html');
    response.end(html);
});

/**
 * SEO Route for the Profile detail page
 */
SeoRouter.route('/profile/:id', function(params, request, response) {
    var userId = params.id;
    var user = Meteor.users.findOne(userId);

    if (!user) {
        response.statusCode = 404;
        return response.end();
    }

    var image = Images.findOne(user.profile.image);

    SSR.compileTemplate('seo_profile', Assets.getText('private/templates/seo/profile.html'));

    Template.seo_profile.helpers({
        getProfileUrl: function() {
            return Meteor.absoluteUrl() + 'profile/' + user._id;
        },
        getImageUrl: function() {
            if (!image) return Meteor.absoluteUrl() + 'images/partup-logo.png';

            return Partup.helpers.url.getImageUrl(image);
        }
    });

    var html = SSR.render('seo_profile', user);

    response.setHeader('Content-Type', 'text/html');
    response.end(html);
});

/**
 * SEO Route for the Network detail page
 */
SeoRouter.route('/tribes/:slug', function(params, request, response) {
    var slug = params.slug;
    var network = Networks.findOne({slug: slug});

    if (!network) {
        response.statusCode = 404;
        return response.end();
    }

    var image = Images.findOne(network.image);

    SSR.compileTemplate('seo_network', Assets.getText('private/templates/seo/network.html'));

    Template.seo_network.helpers({
        getNetworkUrl: function() {
            return Meteor.absoluteUrl() + 'tribes/' + network.slug;
        },
        getImageUrl: function() {
            if (!image) return Meteor.absoluteUrl() + 'images/partup-logo.png';

            return Partup.helpers.url.getImageUrl(image);
        }
    });

    var html = SSR.render('seo_network', network);

    response.setHeader('Content-Type', 'text/html');
    response.end(html);
});

/**
 * SEO Route for the Swarm page
 */
SeoRouter.route('/:slug', function(params, request, response) {
    var slug = params.slug;
    var swarm = Swarms.findOne({slug: slug});

    if (!swarm) {
        response.statusCode = 404;
        return response.end();
    }

    var image = Images.findOne(swarm.image);

    SSR.compileTemplate('seo_swarm', Assets.getText('private/templates/seo/swarm.html'));

    Template.seo_swarm.helpers({
        getSwarmUrl: function() {
            return Meteor.absoluteUrl() + swarm.slug;
        },
        getImageUrl: function() {
            if (!image) return Meteor.absoluteUrl() + 'images/partup-logo.png';

            return Partup.helpers.url.getImageUrl(image);
        }
    });

    var html = SSR.render('seo_swarm', swarm);

    response.setHeader('Content-Type', 'text/html');
    response.end(html);
});

/**
 * SEO Route for the Network About page
 */
SeoRouter.route('/tribes/:slug/about', function(params, request, response) {
    var slug = params.slug;
    var network = Networks.findOne({slug: slug});

    if (!network) {
        response.statusCode = 404;
        return response.end();
    }

    var image = Images.findOne(network.image);

    SSR.compileTemplate('seo_network_about', Assets.getText('private/templates/seo/network_about.html'));

    Template.seo_network_about.helpers({
        getAboutUrl: function() {
            return Meteor.absoluteUrl() + 'tribes/' + network.slug + '/about';
        },
        getAboutTitle: function() {
            if (!network.contentblocks) return network.name;
            var contentblockId = network.contentblocks[0];
            var contentblock = ContentBlocks.findOne(contentblockId);
            if (!contentblock) return network.name;
            return contentblock.title ? contentblock.title : network.name;
        },
        getAboutDescription: function() {
            if (!network.contentblocks) return network.description;
            var contentblockId = network.contentblocks[0];
            var contentblock = ContentBlocks.findOne(contentblockId);
            if (!contentblock) return network.description;
            return contentblock.text ? contentblock.text : network.description;
        },
        getImageUrl: function() {
            if (!image) return Meteor.absoluteUrl() + 'images/partup-logo.png';

            return Partup.helpers.url.getImageUrl(image);
        }
    });

    var html = SSR.render('seo_network_about', network);

    response.setHeader('Content-Type', 'text/html');
    response.end(html);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/any_handler.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('event_handlers');

/**
 * Log every event fired by the application including it's arguments
 */
Event.onAny(function() {
    d('Event fired', this.event);

    if (process.env.LOG_EVENTS) {
        Log.debug('Event fired: '.white + this.event.magenta, arguments);
    }

    if (process.env.EVENT_ENDPOINT_URL && process.env.EVENT_ENDPOINT_AUTHORIZATION) {
        var data = {
            'timestamp': new Date().toISOString(),
            'eventname': this.event,
            'payload': arguments
        };
        HTTP.call('POST', process.env.EVENT_ENDPOINT_URL, {
            data: data,
            headers: {
                'Authorization': 'Bearer ' + process.env.EVENT_ENDPOINT_AUTHORIZATION
            },
            npmRequestOptions: {
                rejectUnauthorized: false
            }
        }, function(err, result) {
            if (err && process.env.LOG_EVENTS) {
                Log.error('Could not push event to store.');
                Log.error(err);
                Log.error(result);
            } else {
                //silently ignore success of posting to eventstore
            }
        });
    } else {
        Log.debug('Event store endpoint is not configured.');
    }
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_handler.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Event.on('partups.inserted', function(userId, partup) {
    if (!userId) return;

    // Store new tags into collection
    Partup.services.tags.insertNewTags(partup.tags);

    // Add language to collection if new
    Partup.server.services.language.addNewLanguage(partup.language);

    // "User created this part-up" update
    var update_created = Partup.factories.updatesFactory.make(userId, partup._id, 'partups_created', {});
    Updates.insert(update_created);

    // "System message" update
    var update_systemmessage = Partup.factories.updatesFactory.makeSystem(partup._id, 'partups_message_added', {
        type: 'welcome_message'
    });
    Updates.insert(update_systemmessage);

    // If the Partup has been created in a Network, notify all its users
    if (partup.network_id) {
        var network = Networks.findOneOrFail(partup.network_id);
        var creator = Meteor.users.findOneOrFail(userId);

        network.uppers.forEach(function(upperId) {
            // Dont send a notification to the creator of the partup
            if (upperId === creator._id) return;

            var upper = Meteor.users.findOneOrFail(upperId);

            // Set the notification details
            var notificationOptions = {
                userId: upper._id,
                type: 'partup_created_in_network',
                typeData: {
                    creator: {
                        _id: creator._id,
                        name: creator.profile.name,
                        image: creator.profile.image
                    },
                    network: {
                        name: network.name
                    },
                    partup: {
                        _id: partup._id,
                        name: partup.name,
                        slug: partup.slug
                    }
                }
            };

            // Send the notification
            Partup.server.services.notifications.send(notificationOptions);

            // Set the email details
            var emailOptions = {
                type: 'partup_created_in_network',
                toAddress: User(upper).getEmail(),
                subject: TAPi18n.__('emails-partup_created_in_network-subject', {network: network.name}, User(upper).getLocale()),
                locale: User(upper).getLocale(),
                typeData: {
                    name: User(upper).getFirstname(),
                    creatorName: creator.profile.name,
                    partupName: partup.name,
                    networkName: network.name,
                    url: Meteor.absoluteUrl() + 'partups/' + partup.slug,
                    unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/partup_created_in_network/' + upper.profile.settings.unsubscribe_email_token,
                    unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + upper.profile.settings.unsubscribe_email_token
                },
                userEmailPreferences: upper.profile.settings.email
            };

            // Send the email
            Partup.server.services.emails.send(emailOptions);
        });
    }
});

Event.on('partups.updated', function(userId, partup, fields) {
    // Store new tags into collection
    Partup.services.tags.insertNewTags(partup.tags);

    // Add language to collection if new
    Partup.server.services.language.addNewLanguage(partup.language);
});

Event.on('partups.archived', function(userId, partup) {
    // "User archived this part-up" update
    var update_archived = Partup.factories.updatesFactory.make(userId, partup._id, 'partups_archived', {});
    Updates.insert(update_archived);

    var archiver = Meteor.users.findOneOrFail(userId);

    var notify_uppers = partup.uppers || [];
    var partup_supporters = partup.supporters || [];
    notify_uppers.push.apply(notify_uppers, partup_supporters);

    notify_uppers.forEach(function(upperId) {
        // Dont send a notification to the archiver of the partup
        if (upperId === userId) return;

        var upper = Meteor.users.findOneOrFail(upperId);

        // Set the notification details
        var notificationOptions = {
            userId: upper._id,
            type: 'partups_archived',
            typeData: {
                archiver: {
                    _id: archiver._id,
                    name: archiver.profile.name,
                    image: archiver.profile.image
                },
                partup: {
                    _id: partup._id,
                    name: partup.name,
                    slug: partup.slug
                }
            }
        };

        // Send the notification
        Partup.server.services.notifications.send(notificationOptions);
    });
});

Event.on('partups.unarchived', function(userId, partup) {
    // "User unarchived this part-up" update
    var update_unarchived = Partup.factories.updatesFactory.make(userId, partup._id, 'partups_unarchived', {});
    Updates.insert(update_unarchived);

    var unarchiver = Meteor.users.findOneOrFail(userId);

    var notify_uppers = partup.uppers || [];
    var partup_supporters = partup.supporters || [];
    notify_uppers.push.apply(notify_uppers, partup_supporters);

    notify_uppers.forEach(function(upperId) {
        // Dont send a notification to the unarchiver of the partup
        if (upperId === userId) return;

        var upper = Meteor.users.findOneOrFail(upperId);

        // Set the notification details
        var notificationOptions = {
            userId: upper._id,
            type: 'partups_unarchived',
            typeData: {
                unarchiver: {
                    _id: unarchiver._id,
                    name: unarchiver.profile.name,
                    image: unarchiver.profile.image
                },
                partup: {
                    _id: partup._id,
                    name: partup.name,
                    slug: partup.slug
                }
            }
        };

        // Send the notification
        Partup.server.services.notifications.send(notificationOptions);
    });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_supporters_handler.js                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Generate Updates and Notifications in a Partup when there is a new Supporter.
 */
Event.on('partups.supporters.inserted', function(partup, upper) {
    // Generate Update
    var updateType = 'partups_supporters_added';
    var updateTypeData = {};
    var existingUpdateId = Updates.findOne({
        type: updateType,
        partup_id: partup._id,
        upper_id: upper._id
    }, {_id: 1});

    // Update the update if one exists
    if (existingUpdateId) {
        Partup.server.services.system_messages.send(upper, existingUpdateId, 'system_supporters_added');
        return;
    }

    var update = Partup.factories.updatesFactory.make(upper._id, partup._id, updateType, updateTypeData);
    var updateId = Updates.insert(update);

    // Generate a Notification for each upper in a Partup when there is a new Supporter.
    var notificationOptions = {
        type: 'partups_supporters_added',
        typeData: {
            supporter: {
                _id: upper._id,
                name: upper.profile.name,
                image: upper.profile.image
            },
            partup: {
                _id: partup._id,
                name: partup.name,
                slug: partup.slug
            },
            update: {
                _id: updateId
            }
        }
    };

    if (partup.uppers) {
        partup.uppers.forEach(function(upperId) {
            notificationOptions.userId = upperId;

            Partup.server.services.notifications.send(notificationOptions);
        });
    }

});

/**
 * Update the Update in a Partup when a Supporter stops supporting.
 */
Event.on('partups.supporters.removed', function(partup, upper) {
    var existingUpdateId = Updates.findOne({type: 'partups_supporters_added', partup_id: partup._id, upper_id: upper._id}, {_id: 1});
    if (existingUpdateId) {
        Partup.server.services.system_messages.send(upper, existingUpdateId, 'system_supporters_removed');
    }
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_uppers_handler.js                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Generate an Update in a Partup when there is a new Upper.
 */
Event.on('partups.uppers.inserted', function(partupId, upperId) {
    var updateType = 'partups_uppers_added';
    var updateTypeData = {};

    var update = Partup.factories.updatesFactory.make(upperId, partupId, updateType, updateTypeData);

    // TODO: Validation

    Updates.insert(update);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_invited_handler.js                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Generate a notification and email when an invite gets sent
 */
Event.on('invites.inserted.partup', function(inviter, partup, invitee, searchQuery) {
    // Check if there is already an invite update
    var inviteUpdate = Updates.findOne({partup_id: partup._id, upper_id: inviter._id, type: 'partups_invited'}, {sort: {updated_at: -1}});

    if (inviteUpdate && inviteUpdate.isLatestUpdateOfItsPartup()) {
        // Update the update with new invitee name
        var inviteeNames = inviteUpdate.type_data.invitee_names;
        inviteeNames.unshift(User(invitee).getFirstname());
        Updates.update(inviteUpdate._id, {$set: {
            'type_data.invitee_names': inviteeNames,
            updated_at: new Date()
        }});
    } else {
        // Create a new update
        var updateType = 'partups_invited';
        var updateTypeData = {
            invitee_names: [User(invitee).getFirstname()]
        };
        var update = Partup.factories.updatesFactory.make(inviter._id, partup._id, updateType, updateTypeData);
        Updates.insert(update);
    }

    // Set the notification details
    var notificationOptions = {
        userId: invitee._id,
        type: 'invite_upper_to_partup',
        typeData: {
            inviter: {
                _id: inviter._id,
                name: inviter.profile.name,
                image: inviter.profile.image
            },
            partup: {
                _id: partup._id,
                name: partup.name,
                slug: partup.slug
            }
        }
    };

    // Send notification
    Partup.server.services.notifications.send(notificationOptions);

    // Set the email details
    var emailOptions = {
        type: 'invite_upper_to_partup',
        toAddress: User(invitee).getEmail(),
        subject: TAPi18n.__('emails-invite_upper_to_partup-subject', {partup: partup.name}, User(invitee).getLocale()),
        locale: User(invitee).getLocale(),
        typeData: {
            name: User(invitee).getFirstname(),
            partupName: partup.name,
            partupDescription: partup.description,
            inviterName: inviter.profile.name,
            searchQuery: searchQuery,
            url: Meteor.absoluteUrl() + 'partups/' + partup.slug,
            unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/invite_upper_to_partup/' + invitee.profile.settings.unsubscribe_email_token,
            unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + invitee.profile.settings.unsubscribe_email_token
        },
        userEmailPreferences: invitee.profile.settings.email
    };

    // Send the email
    Partup.server.services.emails.send(emailOptions);

    // Update stats
    partup.increaseEmailShareCount();
});

/**
 * Generate an email when an invite gets sent
 */
Event.on('invites.inserted.partup.by_email', function(inviter, partup, email, name, message, accessToken) {
    // Split by double newline
    var toParagraphs = function(message) {
        return message.split('\n\n');
    };

    // Interpolate email message (replace [name] with invitee name and [url] with partup url)
    var interpolate = function(message) {
        var url = Meteor.absoluteUrl() + 'partups/' + partup.slug + '?token=' + accessToken;

        return Partup.helpers.interpolateEmailMessage(message, {
            url: '<a href="' + url + '">' + url + '</a>',
            name: name
        });
    };

    // Set the email details
    var emailOptions = {
        type: 'invite_email_address_to_partup',
        toAddress: email,
        subject: TAPi18n.__('emails-invite_upper_to_partup-subject', {partup: partup.name}, User(inviter).getLocale()),
        locale: User(inviter).getLocale(),
        typeData: {
            paragraphs: toParagraphs(interpolate(message)),
            partupName: partup.name,
            inviterName: inviter.profile.name
        }
    };

    // Send the email
    Partup.server.services.emails.send(emailOptions);

    // Set the name that shows in the update
    var inviteeName = '';
    if (name.match(/.*\s.*/)) {
        inviteeName = name.split(' ')[0];
    } else {
        inviteeName = name;
    }
    // Capitalize first letter
    inviteeName = inviteeName.charAt(0).toUpperCase() + inviteeName.substring(1).toLowerCase();

    // Check if there is already an invite update
    var inviteUpdate = Updates.findOne({partup_id: partup._id, upper_id: inviter._id, type: 'partups_invited'}, {sort: {updated_at: -1}});

    if (inviteUpdate && inviteUpdate.isLatestUpdateOfItsPartup()) {
        // Update the update with new invitee name
        var inviteeNames = inviteUpdate.type_data.invitee_names;
        inviteeNames.unshift(inviteeName);
        Updates.update(inviteUpdate._id, {$set: {
            'type_data.invitee_names': inviteeNames,
            updated_at: new Date()
        }});
    } else {
        // Create a new update
        var updateType = 'partups_invited';
        var updateTypeData = {
            invitee_names: [inviteeName]
        };
        var update = Partup.factories.updatesFactory.make(inviter._id, partup._id, updateType, updateTypeData);
        Updates.insert(update);
    }

    // Update stats
    partup.increaseEmailShareCount();

    // Save the access token to the partup to allow access
    Partups.update(partup._id, {$addToSet: {access_tokens: accessToken}});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_name_changed_handler.js                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Event.on('partups.name.changed', function(userId, partup, value) {
    if (!userId) return;

    var updateType = 'partups_name_changed';
    var updateTypeData = {
        old_name: value.old,
        new_name: value.new
    };

    var update = Partup.factories.updatesFactory.make(userId, partup._id, updateType, updateTypeData);

    Updates.insert(update);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_description_changed_handler.js                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Event.on('partups.description.changed', function(userId, partup, value) {
    if (!userId) return;

    var updateType = 'partups_description_changed';
    var updateTypeData = {
        old_description: value.old,
        new_description: value.new
    };

    var update = Partup.factories.updatesFactory.make(userId, partup._id, updateType, updateTypeData);

    Updates.insert(update);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_budget_changed_handler.js                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Event.on('partups.updated', function(userId, partup, oldPartup) {
    if (!userId) return;

    // Return if nothing changed
    if (partup.type === oldPartup.type &&
        partup['type_' + partup.type + '_budget'] == oldPartup['type_' + oldPartup.type + '_budget'] &&
        partup.currency === oldPartup.currency)
        return;

    var updateType = 'partups_budget_changed';
    var updateTypeData = {
        old_type: oldPartup.type,
        old_value: oldPartup['type_' + oldPartup.type + '_budget'],
        old_currency: oldPartup.currency,
        new_type: partup.type,
        new_value: partup['type_' + partup.type + '_budget'],
        new_currency: partup.currency
    };

    var update = Partup.factories.updatesFactory.make(userId, partup._id, updateType, updateTypeData);

    Updates.insert(update);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_location_changed_handler.js                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Event.on('partups.location.changed', function(userId, partup, value) {
    if (!userId) return;

    var updateType = 'partups_location_changed';
    var updateTypeData = {
        old_location: value.old,
        new_location: value.new
    };

    var update = Partup.factories.updatesFactory.make(userId, partup._id, updateType, updateTypeData);

    Updates.insert(update);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_tags_changed_handler.js                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Event.on('partups.tags.changed', function(userId, partup, value) {
    if (!userId) return;

    var changes = Partup.services.tags.calculateChanges(value.old, value.new);

    changes.forEach(function(change) {
        var updateType = false;
        var updateTypeData = {};

        if (change.type === 'changed') {
            updateType = 'partups_tags_changed';
            updateTypeData = {
                old_tag: change.old_tag,
                new_tag: change.new_tag
            }
        }

        if (change.type === 'added') {
            updateType = 'partups_tags_added';
            updateTypeData = {
                new_tag: change.new_tag
            }
        }

        if (change.type === 'removed') {
            updateType = 'partups_tags_removed';
            updateTypeData = {
                old_tag: change.old_tag
            }
        }

        if (updateType) {
            var update = Partup.factories.updatesFactory.make(userId, partup._id, updateType, updateTypeData);
            Updates.insert(update);

            Log.debug('Update generated for Partup [' + partup._id + '] with type [' + updateType + '].');
        }
    });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_end_date_changed_handler.js                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Event.on('partups.end_date.changed', function(userId, partup, value) {
    if (!userId) return;

    var updateType = 'partups_end_date_changed';
    var updateTypeData = {
        old_end_date: value.old,
        new_end_date: value.new
    };

    var update = Partup.factories.updatesFactory.make(userId, partup._id, updateType, updateTypeData);

    Updates.insert(update);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_image_changed_handler.js                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Event.on('partups.image.changed', function(userId, partup, value) {
    if (!userId) return;

    var updateType = 'partups_image_changed';
    var updateTypeData = {
        old_image: value.old,
        new_image: value.new
    };

    var update = Partup.factories.updatesFactory.make(userId, partup._id, updateType, updateTypeData);

    Updates.insert(update);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/partups/partups_language_handler.js                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Check if an updated language is still being used
 */
Event.on('partups.language.updated', function(oldLanguage, newLanguage) {
    // Do nothing if language is the same
    if (oldLanguage === newLanguage) return;

    // Check if the old language is still being used and delete if it isn't
    var partupLanguageCount = Partups.find({language: oldLanguage}).count();
    if (partupLanguageCount < 1) {
        Languages.remove({_id: oldLanguage});
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/users/users_settings_handler.js                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Update the optionalDetailsCompleted settings when a user is updated
 */
Event.on('users.updated', function(userId, fields) {
    var user = Meteor.users.findOne({_id: userId});

    if (user) {
        if (!user.profile.settings || !user.profile.settings.optionalDetailsCompleted) {
            Meteor.users.update(userId, {$set: {'profile.settings.optionalDetailsCompleted': true}});
        }

        // Store new tags into collection
        Partup.services.tags.insertNewTags(user.profile.tags);

        // Update profile completion percentage
        Partup.server.services.profile_completeness.updateScore();
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/activities/activities_handler.js                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Generate a Partup update when an activity is inserted
 */
Event.on('partups.activities.inserted', function(userId, activity) {
    if (!userId) return;

    var updateType = 'partups_activities_added';
    var updateTypeData = {
        activity_id: activity._id
    };

    var update = Partup.factories.updatesFactory.make(userId, activity.partup_id, updateType, updateTypeData);
    var updateId = Updates.insert(update);

    Activities.update({_id: activity._id}, {$set: {update_id: updateId}});

    var partup = Partups.findOneOrFail(activity.partup_id);
    var creator = Meteor.users.findOneOrFail(activity.creator_id);

    var notificationOptions = {
        type: 'partups_activities_inserted',
        typeData: {
            creator: {
                _id: creator._id,
                name: creator.profile.name,
                image: creator.profile.image
            },
            partup: {
                _id: partup._id,
                name: partup.name,
                slug: partup.slug
            },
            update: {
                _id: updateId
            }
        }
    };

    // Send a notification to each partner of the partup
    var uppers = partup.uppers || [];
    uppers.forEach(function(partnerId) {
        if (userId === partnerId) return;
        notificationOptions.userId = partnerId;
        Partup.server.services.notifications.send(notificationOptions);
    });

    // Send a notification to each supporter of the partup
    var supporters = partup.supporters || [];
    supporters.forEach(function(supporterId) {
        if (userId === supporterId) return;
        notificationOptions.userId = supporterId;
        Partup.server.services.notifications.send(notificationOptions);
    });
});

/**
 * Generate a Partup update when an activity is updated
 */
Event.on('partups.activities.updated', function(userId, activity, oldActivity) {
    if (!userId) return;
    if (!oldActivity.update_id) return;

    var set = {
        upper_id: userId,
        type: 'partups_activities_changed',
        updated_at: new Date()
    };

    Updates.update({_id: activity.update_id}, {$set: set});
});

/**
 * Generate a Partup update when an activity is removed
 */
Event.on('partups.activities.removed', function(userId, activity) {
    if (!userId) return;
    if (!activity.update_id) return;

    var set = {
        upper_id: userId,
        type: 'partups_activities_removed',
        updated_at: new Date()
    };

    Updates.update({_id: activity.update_id}, {$set: set});
});

/**
 * Generate a Partup update when an activity is archived
 */
Event.on('partups.activities.archived', function(userId, activity) {
    if (!userId) return;
    if (!activity.update_id) return;

    var set = {
        upper_id: userId,
        type: 'partups_activities_archived',
        updated_at: new Date()
    };

    Updates.update({_id: activity.update_id}, {$set: set});
});

/**
 * Generate a Partup update when an activity is unarchived
 */
Event.on('partups.activities.unarchived', function(userId, activity) {
    if (!userId) return;
    if (!activity.update_id) return;

    var set = {
        upper_id: userId,
        type: 'partups_activities_unarchived',
        updated_at: new Date()
    };

    Updates.update({_id: activity.update_id}, {$set: set});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/contributions/contributions_handler.js                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Create the update for the contribution
 */
Event.on('partups.contributions.inserted', function(userId, contribution) {
    if (!userId) return;

    var updateType = contribution.verified ? 'partups_contributions_added' : 'partups_contributions_proposed';
    var updateTypeData = {
        activity_id: contribution.activity_id,
        contribution_id: contribution._id
    };

    var update = Partup.factories.updatesFactory.make(userId, contribution.partup_id, updateType, updateTypeData);
    var updateId = Updates.insert(update);

    Contributions.update({_id: contribution._id}, {$set: {update_id: updateId}});

    var user = Meteor.users.findOneOrFail(userId);
    if (!user) return;

    var activity = Activities.findOneOrFail(contribution.activity_id);
    var system_message_type = contribution.verified ? 'system_contributions_added' : 'system_contributions_proposed';
    Partup.server.services.system_messages.send(user, activity.update_id, system_message_type, {update_timestamp: false});

    var creator = Meteor.users.findOneOrFail(contribution.upper_id);

    // Make the user a supporter
    var partup = Partups.findOneOrFail(activity.partup_id);
    if (!partup.hasUpper(user._id)) {
        partup.makeSupporter(user._id);

        var notificationOptions = {
            type: 'partups_contributions_proposed',
            typeData: {
                creator: {
                    _id: creator._id,
                    name: creator.profile.name,
                    image: creator.profile.image
                },
                partup: {
                    _id: partup._id,
                    name: partup.name,
                    slug: partup.slug
                },
                update: {
                    _id: activity.update_id
                }
            }
        };

        // Send a notification to each partner of the partup
        var uppers = partup.uppers || [];
        uppers.forEach(function(partnerId) {
            if (userId === partnerId) return;
            notificationOptions.userId = partnerId;
            Partup.server.services.notifications.send(notificationOptions);
        });
    } else {
        var notificationOptions = {
            type: 'partups_contributions_inserted',
            typeData: {
                creator: {
                    _id: creator._id,
                    name: creator.profile.name,
                    image: creator.profile.image
                },
                partup: {
                    _id: partup._id,
                    name: partup.name,
                    slug: partup.slug
                },
                update: {
                    _id: activity.update_id
                }
            }
        };

        // Send a notification to each partner of the partup
        var uppers = partup.uppers || [];
        uppers.forEach(function(partnerId) {
            if (userId === partnerId) return;
            notificationOptions.userId = partnerId;
            Partup.server.services.notifications.send(notificationOptions);
        });

        // Send a notification to each supporter of the partup
        var supporters = partup.supporters || [];
        supporters.forEach(function(supporterId) {
            if (userId === supporterId) return;
            notificationOptions.userId = supporterId;
            Partup.server.services.notifications.send(notificationOptions);
        });
    }
});

/**
 * Change update_type of Update when the Contribution is changed
 */
Event.on('partups.contributions.updated', function(userId, contribution, oldContribution) {
    if (!userId) return;
    if (!oldContribution.update_id) return;

    var cause = false;
    if (!oldContribution.archived && contribution.archived) {
        cause = 'archived';
    } else if (oldContribution.archived && !contribution.archived) {
        cause = 're-added';
    } else if (!oldContribution.verified && contribution.verified) {
        cause = 'verified';
    }

    var set = {
        upper_id: userId,
        type: cause === 're-added' ? 'partups_contributions_proposed' : 'partups_contributions_changed',
        updated_at: new Date()
    };

    Updates.update({_id: contribution.update_id}, {$set: set});

    var user = Meteor.users.findOneOrFail(userId);
    var activity = Activities.findOneOrFail(contribution.activity_id);

    // When there's a cause, it means that the system_message will be created somewhere else
    if (!cause) {
        Partup.server.services.system_messages.send(user, activity.update_id, 'system_contributions_updated', {update_timestamp: false});
    }

    if (cause === 're-added') {
        var system_message_type = contribution.verified ? 'system_contributions_added' : 'system_contributions_proposed';
        Partup.server.services.system_messages.send(user, activity.update_id, system_message_type, {update_timestamp: false});
    }
});

/**
 * Change update_type of Update when the Contribution is archived
 */
Event.on('partups.contributions.archived', function(userId, contribution) {
    if (!userId) return;
    if (!contribution.update_id) return;

    var set = {
        upper_id: userId,
        type: 'partups_contributions_removed',
        updated_at: new Date()
    };

    Updates.update({_id: contribution.update_id}, {$set: set});

    var user = Meteor.users.findOneOrFail(userId);
    var activity = Activities.findOneOrFail(contribution.activity_id);
    Partup.server.services.system_messages.send(user, activity.update_id, 'system_contributions_removed', {update_timestamp: false});
});

/**
 * Generate a Notification for an Upper when his contribution(s) get(s) accepted
 */
Event.on('contributions.accepted', function(userId, activityId, upperId) {
    var activity = Activities.findOneOrFail(activityId);
    var partup = Partups.findOneOrFail(activity.partup_id);
    var accepter = Meteor.users.findOne(userId);

    var notificationOptions = {
        userId: upperId,
        type: 'partups_contributions_accepted',
        typeData: {
            accepter: {
                _id: accepter._id,
                name: accepter.profile.name,
                image: accepter.profile.image
            },
            activity: {
                _id: activity._id,
                name: activity.name
            },
            partup: {
                _id: partup._id,
                name: partup.name,
                slug: partup.slug
            },
            update: {
                _id: activity.update_id
            }
        }
    };

    Partup.server.services.notifications.send(notificationOptions);
});

/**
 * Generate a Notification for an Upper when his contribution gets rejected
 */
Event.on('contributions.rejected', function(userId, activityId, upperId) {
    var activity = Activities.findOneOrFail(activityId);
    var partup = Partups.findOneOrFail(activity.partup_id);
    var rejecter = Meteor.users.findOne(userId);

    var notificationOptions = {
        userId: upperId,
        type: 'partups_contributions_rejected',
        typeData: {
            rejecter: {
                _id: rejecter._id,
                name: rejecter.profile.name,
                image: rejecter.profile.image
            },
            activity: {
                _id: activity._id,
                name: activity.name
            },
            partup: {
                _id: partup._id,
                name: partup.name,
                slug: partup.slug
            },
            update: {
                _id: activity.update_id
            }
        }
    };

    Partup.server.services.notifications.send(notificationOptions);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/ratings/ratings_handler.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function updateUserAverageRating(rating) {
    // TODO: Aggregation for improved speed
    var ratings = Ratings.find({rated_upper_id: rating.rated_upper_id}).fetch();
    var sumRating = ratings.reduce(function(sum, rating) { return sum + rating.rating; }, 0);
    var averageRating = sumRating / ratings.length;

    Meteor.users.update({_id: rating.rated_upper_id}, {$set: {'average_rating': averageRating}});
}

/**
 * Set the average rating when rating is inserted
 */
Event.on('partups.contributions.ratings.inserted', function(userId, rating) {
    if (!userId) return;
    updateUserAverageRating(rating);

    var contribution = Contributions.findOne(rating.contribution_id);
    if (!contribution) return Log.error('Contribution [' + rating.contribution_id + '] for Rating [' + rating._id + '] could not be found?');

    var contributionUpper = Meteor.users.findOne(contribution.upper_id);
    if (!contributionUpper) return Log.error('User [' + contribution.upper_id + '] for Contribution [' + contribution._id + '] could not be found?');

    var rater = Meteor.users.findOne(userId);
    if (!rater) return Log.error('Rater [' + userId + '] for Contribution [' + contribution._id + '] could not be found?');

    var partup = Partups.findOne(contribution.partup_id);
    if (!partup) return Log.error('Partup [' + contribution.partup_id + '] for Contribution [' + contribution._id + '] could not be found?');

    var activity = Activities.findOne(rating.activity_id);
    if (!activity) return Log.error('Activity [' + rating.activity_id + '] for Rating [' + rating._id + '] could not be found?');

    var notificationOptions = {
        userId: contributionUpper._id,
        type: 'contributions_ratings_inserted',
        typeData: {
            rater: {
                _id: rater._id,
                name: rater.profile.name,
                image: rater.profile.image
            },
            partup: {
                _id: partup._id,
                name: partup.name,
                slug: partup.slug
            },
            update: {
                _id: activity.update_id
            }
        }
    };

    Partup.server.services.notifications.send(notificationOptions);
});

/**
 * Set the average rating when rating is updated
 */
Event.on('partups.contributions.ratings.updated', function(userId, rating) {
    if (!userId) return;
    updateUserAverageRating(rating);
});

/**
 * Update the contribution update with the new rating
 */
Event.on('partups.contributions.ratings.inserted', function(userId, rating) {
    if (!userId) return;

    var contribution = Contributions.findOne(rating.contribution_id);
    if (!contribution) return;

    var set = {
        upper_id: userId,
        type: 'partups_ratings_inserted',
        type_data: {
            activity_id: rating.activity_id,
            contribution_id: rating.contribution_id,
            rating_id: rating._id
        },
        updated_at: new Date()
    };

    Updates.update({_id: contribution.update_id}, {$set: set});
});

/**
 * Update the contribution update with the updated rating
 */
Event.on('partups.contributions.ratings.updated', function(userId, rating, oldRating) {
    if (!userId) return;

    var contribution = Contributions.findOne(rating.contribution_id);
    if (!contribution) return;

    var set = {
        upper_id: userId,
        type: 'partups_ratings_changed',
        type_data: {
            activity_id: rating.activity_id,
            contribution_id: rating.contribution_id,
            rating_id: rating._id
        },
        updated_at: new Date()
    };

    Updates.update({_id: contribution.update_id}, {$set: set});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/updates/updates_handler.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('event_handlers:updates_handler');

/**
 * Generate a notification for the partners and supporters in a partup when a message is created
 */
Event.on('partups.updates.inserted', function(userId, update) {
    var partup = Partups.findOneOrFail(update.partup_id);
    update = new Update(update);

    // Update the new_updates list for all users of this partup
    partup.addNewUpdateToUpperData(update, userId);

    // Create a clean set of new_comments list for the update
    var updateUpperData = [];
    partup.getUsers().forEach(function(upperId) {
        updateUpperData.push({
            _id: upperId,
            new_comments:[]
        });
    });
    Updates.update({_id:update._id}, {$set: {upper_data: updateUpperData}});

    if (update.type === 'partups_message_added' && !update.system) {
        var creator = Meteor.users.findOneOrFail(update.upper_id);

        var mentions = Partup.helpers.mentions.extract(update.type_data.new_value);
        var mentionedUsersIds = lodash.union(lodash.flatten(mentions.map(function(mention) {
            if (mention.type === 'group') return mention.users;
            if (mention.type === 'single') return [mention._id];
            return [];
        })));

        var notificationOptions = {
            type: 'partups_messages_inserted',
            typeData: {
                creator: {
                    _id: creator._id,
                    name: creator.profile.name,
                    image: creator.profile.image
                },
                partup: {
                    _id: partup._id,
                    name: partup.name,
                    slug: partup.slug
                },
                update: {
                    _id: update._id
                }
            }
        };

        // Send a notification to each partner of the partup
        var uppers = partup.uppers || [];
        uppers.forEach(function(partnerId) {
            if (userId === partnerId || mentionedUsersIds.indexOf(partnerId) > -1) return;
            notificationOptions.userId = partnerId;
            Partup.server.services.notifications.send(notificationOptions);
        });

        // Send a notification to each supporter of the partup
        var supporters = partup.supporters || [];
        supporters.forEach(function(supporterId) {
            if (userId === supporterId || mentionedUsersIds.indexOf(supporterId) > -1) return;
            notificationOptions.userId = supporterId;
            Partup.server.services.notifications.send(notificationOptions);
        });
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/updates/updates_comments_handler.js                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('event_handlers:updates_comments_handler');

/**
 * Generate a Notification for the upper for the first comment posted on a message/update
 */
Event.on('updates.comments.inserted', function(upper, partup, update, comment) {
    update = new Update(update);
    var commenterId = upper._id;
    var notifiedUppers = [];

    // Parse message for user mentions
    var limitExceeded = Partup.helpers.mentions.exceedsLimit(comment.content);
    var mentions = Partup.helpers.mentions.extract(comment.content);
    var process = function(user) {
        if (partup.isViewableByUser(user._id)) {
            // Set the notification details
            var notificationOptions = {
                userId: user._id,
                type: 'partups_user_mentioned',
                typeData: {
                    mentioning_upper: {
                        _id: upper._id,
                        name: upper.profile.name,
                        image: upper.profile.image
                    },
                    update: {
                        _id: update._id
                    },
                    partup: {
                        _id: partup._id,
                        name: partup.name,
                        slug: partup.slug
                    }
                }
            };

            // Send the notification
            Partup.server.services.notifications.send(notificationOptions);

            notifiedUppers.push(user._id);

            // Set the email details
            var emailOptions = {
                type: 'upper_mentioned_in_partup',
                toAddress: User(user).getEmail(),
                subject: TAPi18n.__('emails-upper_mentioned_in_partup-subject', {partup: partup.name}, User(user).getLocale()),
                locale: User(user).getLocale(),
                typeData: {
                    name: User(user).getFirstname(),
                    mentioningUpper: upper.profile.name,
                    partupName: partup.name,
                    url: Meteor.absoluteUrl() + 'partups/' + partup.slug + '/updates/' + update._id,
                    unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/upper_mentioned_in_partup/' + user.profile.settings.unsubscribe_email_token,
                    unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + user.profile.settings.unsubscribe_email_token
                },
                userEmailPreferences: user.profile.settings.email
            };

            // Send the email
            Partup.server.services.emails.send(emailOptions);
        }
    };
    if (!limitExceeded) {
        mentions.forEach(function(mention) {
            if (mention.type === 'single') {
                // Retrieve the user from the database (ensures that the user does indeed exists!)
                if (mention._id === commenterId) return;
                var user = Meteor.users.findOne(mention._id);
                process(user);
            } else if (mention.type === 'group') {
                // Retrieve each user from the database (ensures that the user does indeed exists!)
                mention.users.forEach(function(userId) {
                    if (userId === commenterId) return;
                    var user = Meteor.users.findOne(userId);
                    process(user);
                });
            }
        });
    }

    /* -------------------------------------------------- */

    // Add the comment to new comment list for the targeted users
    var upperIds = partup.getUsers();
    update.addNewCommentToUpperData(comment, upperIds);

    /* -------------------------------------------------- */

    // Check if a new comment notification needs to be created
    if (comment.type === 'motivation') return; // Nope

    // Collect all uppers that should receive a new comment notification
    var involvedUppers = update.getInvolvedUppers();

    // Filter the creator of the comment and the already mentioned uppers
    var filteredUppers = involvedUppers.filter(function(upperId) {
        return (upperId !== commenterId && notifiedUppers.indexOf(upperId) < 0);
    });

    var notificationType = 'partups_new_comment_in_involved_conversation';

    Meteor.users.find({_id: {$in: filteredUppers}}).fetch().forEach(function(notifiedUpper) {
        var notificationOptions = {
            userId: notifiedUpper._id,
            type: notificationType,
            typeData: {
                commenter: {
                    _id: comment.creator._id,
                    name: comment.creator.name,
                    image: comment.creator.image
                },
                partup: {
                    _id: partup._id,
                    name: partup.name,
                    slug: partup.slug
                },
                update: {
                    _id: update._id
                }
            }
        };

        // Send the notification
        Partup.server.services.notifications.send(notificationOptions);

        // Set the email details
        var emailOptions = {
            type: notificationType,
            toAddress: User(notifiedUpper).getEmail(),
            subject: TAPi18n.__('emails-' + notificationType + '-subject', {}, User(notifiedUpper).getLocale()),
            locale: User(notifiedUpper).getLocale(),
            typeData: {
                name: User(notifiedUpper).getFirstname(),
                upperName: comment.creator.name,
                partupName: partup.name,
                url: Meteor.absoluteUrl() + 'partups/' + partup.slug + '/updates/' + update._id,
                unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/' + notificationType + '/' + notifiedUpper.profile.settings.unsubscribe_email_token,
                unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + notifiedUpper.profile.settings.unsubscribe_email_token
            },
            userEmailPreferences: notifiedUpper.profile.settings.email
        };

        // Send the email
        Partup.server.services.emails.send(emailOptions);
    });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/updates/updates_messages_handler.js                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('event_handlers:updates_messages_handler');

/**
 * Notify mentioned uppers
 */
Event.on('partups.messages.insert', function(upper, partup, update, message) {
    var messagerId = upper._id;
    // Parse message for user mentions
    var limitExceeded = Partup.helpers.mentions.exceedsLimit(message);
    var mentions = Partup.helpers.mentions.extract(message);
    var process = function(user) {
        if (partup.isViewableByUser(user._id)) {
            // Set the notification details
            var notificationOptions = {
                userId: user._id,
                type: 'partups_user_mentioned',
                typeData: {
                    mentioning_upper: {
                        _id: upper._id,
                        name: upper.profile.name,
                        image: upper.profile.image
                    },
                    update: {
                        _id: update._id
                    },
                    partup: {
                        _id: partup._id,
                        name: partup.name,
                        slug: partup.slug
                    }
                }
            };

            // Send the notification
            Partup.server.services.notifications.send(notificationOptions);

            // Set the email details
            var emailOptions = {
                type: 'upper_mentioned_in_partup',
                toAddress: User(user).getEmail(),
                subject: TAPi18n.__('emails-upper_mentioned_in_partup-subject', {partup: partup.name}, User(user).getLocale()),
                locale: User(user).getLocale(),
                typeData: {
                    name: User(user).getFirstname(),
                    mentioningUpper: upper.profile.name,
                    partupName: partup.name,
                    url: Meteor.absoluteUrl() + 'partups/' + partup.slug + '/updates/' + update._id,
                    unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/upper_mentioned_in_partup/' + user.profile.settings.unsubscribe_email_token,
                    unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + user.profile.settings.unsubscribe_email_token
                },
                userEmailPreferences: user.profile.settings.email
            };

            // Send the email
            Partup.server.services.emails.send(emailOptions);
        }
    };
    if (!limitExceeded) {
        mentions.forEach(function(mention) {
            if (mention.type === 'single') {
                // make sure the mentioned user is not the same as the creator
                if (messagerId === mention._id) return;
                // Retrieve the user from the database (ensures that the user does indeed exists!)
                var user = Meteor.users.findOne(mention._id);
                process(user);
            } else if (mention.type === 'group') {
                // Retrieve each user from the database (ensures that the user does indeed exists!)
                mention.users.forEach(function(userId) {
                    // make sure the mentioned user is not the same as the creator
                    if (messagerId === userId) return;
                    var user = Meteor.users.findOne(userId);
                    process(user);
                });
            }
        });
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/networks/networks_handler.js                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Generate a notification for an upper when getting accepted for a network
 */
Event.on('networks.accepted', function(userId, networkId, upperId) {
    var network = Networks.findOneOrFail(networkId);
    var acceptedUpper = Meteor.users.findOneOrFail(upperId);
    var notificationType = 'partups_networks_accepted';

    // Send notifications to accepted upper
    var notificationOptions = {
        userId: acceptedUpper._id,
        type: notificationType,
        typeData: {
            network: {
                _id: network._id,
                name: network.name,
                image: network.image,
                slug: network.slug
            }
        }
    };

    Partup.server.services.notifications.send(notificationOptions);

    // Set the email details
    var emailOptions = {
        type: notificationType,
        toAddress: User(acceptedUpper).getEmail(),
        subject: TAPi18n.__('emails-partups_networks_accepted-subject', {network: network.name}, User(acceptedUpper).getLocale()),
        locale: User(acceptedUpper).getLocale(),
        typeData: {
            name: User(acceptedUpper).getFirstname(),
            networkName: network.name,
            url: Meteor.absoluteUrl() + 'tribes/' + network.slug,
            unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/' + notificationType + '/' + acceptedUpper.profile.settings.unsubscribe_email_token,
            unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + acceptedUpper.profile.settings.unsubscribe_email_token
        },
        userEmailPreferences: acceptedUpper.profile.settings.email
    };

    // Send the email
    Partup.server.services.emails.send(emailOptions);
});

/**
 * Generate a notification for the network admins when a new upper is pending
 */
Event.on('networks.new_pending_upper', function(network, pendingUpper) {
    var notificationType = 'partups_networks_new_pending_upper';
    var admins = Meteor.users.find({_id: {$in: network.admins}});

    admins.forEach(function(admin) {
        // Send notifications to network admin
        var notificationOptions = {
            userId: admin._id,
            type: notificationType,
            typeData: {
                pending_upper: {
                    _id: pendingUpper._id,
                    name: pendingUpper.profile.name,
                    image: pendingUpper.profile.image
                },
                network: {
                    _id: network._id,
                    name: network.name,
                    image: network.image,
                    slug: network.slug
                }
            }
        };

        Partup.server.services.notifications.send(notificationOptions);

        // Set the email details
        var emailOptions = {
            type: notificationType,
            toAddress: User(admin).getEmail(),
            subject: TAPi18n.__('emails-partups_networks_new_pending_upper-subject', {
                upper: pendingUpper.profile.name,
                network: network.name
            }, User(admin).getLocale()),
            locale: User(admin).getLocale(),
            typeData: {
                name: User(admin).getFirstname(),
                pendingUpperName: pendingUpper.profile.name,
                networkName: network.name,
                url: Meteor.absoluteUrl() + 'tribes/' + network.slug + '/settings/requests',
                unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/' + notificationType + '/' + admin.profile.settings.unsubscribe_email_token,
                unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + admin.profile.settings.unsubscribe_email_token
            },
            userEmailPreferences: admin.profile.settings.email
        };

        // Send the email
        Partup.server.services.emails.send(emailOptions);
    });
});

/**
 * Generate a notification for the network uppers to notify the new upper
 */
Event.on('networks.uppers.inserted', function(newUpper, network) {
    var notificationType = 'partups_networks_new_upper';

    // Send notifications to all uppers in network
    var networkUppers = network.uppers || [];
    Meteor.users.find({_id: {$in: networkUppers}}).forEach(function(networkUpper) {
        // Don't notify the upper that just joined
        if (networkUpper._id === newUpper._id) return;

        // Set-up notification options
        var notificationOptions = {
            userId: networkUpper._id,
            type: notificationType,
            typeData: {
                upper: {
                    _id: newUpper._id,
                    name: newUpper.profile.name,
                    image: newUpper.profile.image
                },
                network: {
                    _id: network._id,
                    name: network.name,
                    image: network.image,
                    slug: network.slug
                }
            }
        };

        Partup.server.services.notifications.send(notificationOptions);

        // Set the email details
        var emailOptions = {
            type: notificationType,
            toAddress: User(networkUpper).getEmail(),
            subject: TAPi18n.__('emails-' + notificationType + '-subject', {network: network.name}, User(networkUpper).getLocale()),
            locale: User(networkUpper).getLocale(),
            typeData: {
                name: User(networkUpper).getFirstname(),
                upperName: newUpper.profile.name,
                networkName: network.name,
                url: Meteor.absoluteUrl() + 'tribes/' + network.slug + '/uppers',
                unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/' + notificationType + '/' + networkUpper.profile.settings.unsubscribe_email_token,
                unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + networkUpper.profile.settings.unsubscribe_email_token
            },
            userEmailPreferences: networkUpper.profile.settings.email
        };

        // Send the email
        Partup.server.services.emails.send(emailOptions);
    });
});

/**
 * Generate a notification for all network admins to notify that an upper left
 */
Event.on('networks.uppers.removed', function(upper, network) {
    var notificationType = 'partups_networks_upper_left';

    var admins = Meteor.users.find({_id: {$in: network.admins || []}});

    admins.forEach(function(networkAdmin) {
        var notificationOptions = {
            userId: networkAdmin._id,
            type: notificationType,
            typeData: {
                upper: {
                    _id: upper._id,
                    name: upper.profile.name,
                    image: upper.profile.image
                },
                network: {
                    _id: network._id,
                    name: network.name,
                    image: network.image,
                    slug: network.slug
                }
            }
        };

        Partup.server.services.notifications.send(notificationOptions);

        // Set the email details
        var emailOptions = {
            type: notificationType,
            toAddress: User(networkAdmin).getEmail(),
            subject: TAPi18n.__('emails-' + notificationType + '-subject', {network: network.name}, User(networkAdmin).getLocale()),
            locale: User(networkAdmin).getLocale(),
            typeData: {
                name: User(networkAdmin).getFirstname(),
                upperName: upper.profile.name,
                networkName: network.name,
                url: Meteor.absoluteUrl() + 'tribes/' + network.slug + '/uppers',
                unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/' + notificationType + '/' + networkAdmin.profile.settings.unsubscribe_email_token,
                unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + networkAdmin.profile.settings.unsubscribe_email_token
            },
            userEmailPreferences: networkAdmin.profile.settings.email
        };

        // Send the email
        Partup.server.services.emails.send(emailOptions);
    });
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/invites/activities_invites_handler.js                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Generate a notification and email when an invite gets sent
 */
Event.on('invites.inserted.activity', function(inviter, partup, activity, invitee, searchQuery) {
    // Check if there is already an invite update
    var inviteUpdate = Updates.findOne({partup_id: partup._id, upper_id: inviter._id, type: 'partups_invited'}, {sort: {updated_at: -1}});

    if (inviteUpdate && inviteUpdate.isLatestUpdateOfItsPartup()) {
        // Update the update with new invitee name
        var inviteeNames = inviteUpdate.type_data.invitee_names;
        inviteeNames.unshift(User(invitee).getFirstname());
        Updates.update(inviteUpdate._id, {$set: {
            'type_data.invitee_names': inviteeNames,
            updated_at: new Date()
        }});
    } else {
        // Create a new update
        var updateType = 'partups_invited';
        var updateTypeData = {
            invitee_names: [User(invitee).getFirstname()]
        };
        var update = Partup.factories.updatesFactory.make(inviter._id, partup._id, updateType, updateTypeData);
        Updates.insert(update);
    }

    // Set the notification details
    var notificationOptions = {
        userId: invitee._id,
        type: 'partup_activities_invited',
        typeData: {
            inviter: {
                _id: inviter._id,
                name: inviter.profile.name,
                image: inviter.profile.image
            },
            activity: {
                _id: activity._id,
                name: activity.name
            },
            partup: {
                _id: partup._id,
                name: partup.name,
                slug: partup.slug
            },
            update: {
                _id: activity.update_id
            }
        }
    };

    // Send notification
    Partup.server.services.notifications.send(notificationOptions);

    // Set the email details
    var emailOptions = {
        type: 'invite_upper_to_partup_activity',
        toAddress: User(invitee).getEmail(),
        subject: TAPi18n.__('emails-invite_upper_to_partup_activity-subject', {activity: activity.name, partup: partup.name}, User(invitee).getLocale()),
        locale: User(invitee).getLocale(),
        typeData: {
            name: User(invitee).getFirstname(),
            partupName: partup.name,
            partupDescription: partup.description,
            activityName: activity.name,
            activityDescription: activity.description,
            inviterName: inviter.profile.name,
            searchQuery: searchQuery,
            url: Meteor.absoluteUrl() + 'partups/' + partup.slug,
            unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/invite_upper_to_partup_activity/' + invitee.profile.settings.unsubscribe_email_token,
            unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + invitee.profile.settings.unsubscribe_email_token
        },
        userEmailPreferences: invitee.profile.settings.email
    };

    // Send the email
    Partup.server.services.emails.send(emailOptions);

    // Update stats
    partup.increaseEmailShareCount();
});

/**
 * Generate an email when an invite gets sent
 */
Event.on('invites.inserted.activity.by_email', function(inviter, partup, activity, email, name, message, accessToken) {

    // Split by double newline
    var toParagraphs = function(message) {
        return message.split('\n\n');
    };

    // Interpolate email message (replace [name] with invitee name and [url] with activity url)
    var interpolate = function(message) {
        var url = Meteor.absoluteUrl() + 'partups/' + partup.slug + '?token=' + accessToken;

        return Partup.helpers.interpolateEmailMessage(message, {
            url: '<a href="' + url + '">' + url + '</a>',
            name: name
        });
    };

    // Set the email details
    var emailOptions = {
        type: 'invite_email_address_to_partup_activity',
        toAddress: email,
        subject: TAPi18n.__('emails-invite_upper_to_partup_activity-subject', {activity: activity.name, partup: partup.name}, User(inviter).getLocale()),
        locale: User(inviter).getLocale(),
        typeData: {
            paragraphs: toParagraphs(interpolate(message)),
            partupName: partup.name,
            partupDescription: partup.description,
            activityName: activity.name,
            activityDescription: activity.description,
            inviterName: inviter.profile.name
        }
    };

    // Send the email
    Partup.server.services.emails.send(emailOptions);

    // Create a new update
    var updateType = 'partups_invited';
    var updateTypeData = {
        invitee_names: [name]
    };
    var update = Partup.factories.updatesFactory.make(inviter._id, partup._id, updateType, updateTypeData);
    Updates.insert(update);

    // Update stats
    partup.increaseEmailShareCount();

    // Save the access token to the partup to allow access
    Partups.update(partup._id, {$addToSet: {access_tokens: accessToken}});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/invites/networks_invites_handler.js                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Generate a notification and email when an invite gets sent
 */
Event.on('invites.inserted.network', function(inviter, network, invitee, searchQuery) {
    // Set the notification details
    var notificationOptions = {
        userId: invitee._id,
        type: 'partups_networks_invited',
        typeData: {
            inviter: {
                _id: inviter._id,
                name: inviter.profile.name,
                image: inviter.profile.image
            },
            network: {
                _id: network._id,
                name: network.name,
                image: network.image,
                slug: network.slug
            }
        }
    };

    // Send notification
    Partup.server.services.notifications.send(notificationOptions);

    // Set the email details
    var emailOptions = {
        type: 'invite_upper_to_network',
        toAddress: User(invitee).getEmail(),
        subject: TAPi18n.__('emails-invite_upper_to_network-subject', {network: network.name}, User(invitee).getLocale()),
        locale: User(invitee).getLocale(),
        typeData: {
            name: User(invitee).getFirstname(),
            networkName: network.name,
            networkDescription: network.description,
            inviterName: inviter.profile.name,
            searchQuery: searchQuery,
            url: Meteor.absoluteUrl() + 'tribes/' + network.slug,
            unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/invite_upper_to_network/' + invitee.profile.settings.unsubscribe_email_token,
            unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + invitee.profile.settings.unsubscribe_email_token
        },
        userEmailPreferences: invitee.profile.settings.email
    };

    // Send the email
    Partup.server.services.emails.send(emailOptions);
});

/**
 * Generate an email when an invite gets sent
 */
Event.on('invites.inserted.network.by_email', function(inviter, network, email, name, message, accessToken) {

    // Split by double newline
    var toParagraphs = function(message) {
        return message.split('\n\n');
    };

    // Interpolate email message (replace [name] with invitee name and [url] with network url)
    var interpolate = function(message) {
        var url = Meteor.absoluteUrl() + 'tribes/' + network.slug + '?token=' + accessToken;

        return Partup.helpers.interpolateEmailMessage(message, {
            url: '<a href="' + url + '">' + url + '</a>',
            name: name
        });
    };

    // Set the email details
    var emailOptions = {
        type: 'invite_email_address_to_network',
        toAddress: email,
        subject: TAPi18n.__('emails-invite_upper_to_network-subject', {network: network.name}, User(inviter).getLocale()),
        locale: User(inviter).getLocale(),
        typeData: {
            paragraphs: toParagraphs(interpolate(message))
        }
    };

    // Send the email
    Partup.server.services.emails.send(emailOptions);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/notifications/notifications_handler.js                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Check if notifications need to be grouped after inserted
 */
Event.on('partups.notifications.inserted', function(upperId, notification) {
    // Define the notification groups
    var updateGroup = [
        'partups_activities_inserted',
        'partups_messages_inserted',
        'partups_contributions_inserted',
        'partups_supporters_added'
    ];
    var conversationGroup = [
        'partups_new_comment_in_involved_conversation'
    ];
    var networkGroup = [
        'partups_networks_new_upper'
    ];

    // Check if notification belongs to a group
    var notificationGroupType = null;
    var group = [];
    if (updateGroup.indexOf(notification.type) > -1) {
        notificationGroupType = 'partups_multiple_updates_since_visit';
        group = updateGroup;
    } else if (conversationGroup.indexOf(notification.type) > -1) {
        notificationGroupType = 'multiple_comments_in_conversation_since_visit';
        group = conversationGroup;
    } else if (networkGroup.indexOf(notification.type) > -1) {
        notificationGroupType = 'networks_multiple_new_uppers_since_visit';
        group = networkGroup;
    }

    if (notificationGroupType) {
        // Set latest upper data
        var latestUpper = {};
        if (notification.type_data.supporter) latestUpper = notification.type_data.supporter;
        if (notification.type_data.creator) latestUpper = notification.type_data.creator;
        if (notification.type_data.commenter) latestUpper = notification.type_data.commenter;
        if (notification.type_data.upper) latestUpper = notification.type_data.upper;

        // Build unread notifications query
        var query = {
            for_upper_id: notification.for_upper_id,
            type: {$in: group},
            new: true
        };
        // Add group specific data to query
        if (group === conversationGroup) query['type_data.update._id'] = notification.type_data.update._id;
        if (group === updateGroup) query['type_data.partup._id'] = notification.type_data.partup._id;
        if (group === networkGroup) query['type_data.network._id'] = notification.type_data.network._id;

        var unreadNotifications = Notifications.find(query, {fields: {_id: 1, type_data: 1}}).fetch();
        var notificationIds = [];
        var upperIds = [];
        unreadNotifications.forEach(function(notification) {
            if (notification.type_data.supporter) upperIds.push(notification.type_data.supporter._id);
            if (notification.type_data.creator) upperIds.push(notification.type_data.creator._id);
            if (notification.type_data.commenter) upperIds.push(notification.type_data.commenter._id);
            if (notification.type_data.upper) upperIds.push(notification.type_data.upper._id);
            notificationIds.push(notification._id);
        });

        // Now check if there is already a grouped notification for this user
        query.type = notificationGroupType;
        var groupNotification = Notifications.findOne(query);
        if (groupNotification) {
            // There is, so we only need to update that notification, and set grouped property to created notification
            Notifications.update(notification._id, {$set: {grouped: true}});
            Notifications.update(groupNotification._id, {
                $set: {
                    'type_data.latest_upper': latestUpper,
                    'type_data.others_count': lodash.unique(upperIds).length - 1 // Don't include latest upper
                }
            });
        } else {
            // There is no group notification, so check if we need to create one
            if (unreadNotifications.length < 3) return;

            // We need to create a group notification at this point, so flag the single notifications
            Notifications.update({_id: {$in: notificationIds}}, {$set: {grouped: true}}, {multi: true});

            // Set the data
            var newNotification = {
                for_upper_id: notification.for_upper_id,
                type: notificationGroupType,
                type_data: notification.type_data,
                created_at: new Date(),
                new: true,
                clicked: false
            };
            newNotification.type_data.latest_upper = latestUpper;
            newNotification.type_data.others_count = lodash.unique(upperIds).length - 1; // Don't include latest upper

            Notifications.insert(newNotification);
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/event_handlers/swarms/swarms_handler.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Update the swarm stats
 */
Event.on('partups.swarms.networks.updated', function(userId, swarm) {
    if (!userId) return;

    // A network has been added or removed, so we need to update the swarm stats
    Partup.server.services.swarms.updateStats(swarm);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/users.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {

        if (!Meteor.users.find().count()) {
            Meteor.users.insert({
                '_id': 'K5c5M4Pbdg3B82wQH',
                'createdAt': new Date(),
                'services': {
                    'password': {
                        'bcrypt': '$2a$10$nytjhtAbBUXe1Td8LrVJ4.jJa/lE62riuDM/dm79f3fqfeuZo2xNG'
                    },
                    'resume': {
                        'loginTokens': [
                            {
                                'when': new Date(),
                                'hashedToken': 'yoxRsvKflDfC/tKh2en1Pka+rVymsYIQ3QOlq0EVSB4='
                            }
                        ]
                    },
                    'email': {
                        'verificationTokens': [
                            {
                                'token': 'CTel11muhC80_UYGDcVz8J5kTU4zkli_UEo73oH427d',
                                'address': 'user@example.com',
                                'when': new Date()
                            }
                        ]
                    }
                },
                'emails': [
                    {
                        'address': 'user@example.com',
                        'verified': false
                    }
                ],
                'completeness': 100,
                'profile': {
                    'name': 'Default User',
                    'normalized_name': 'default user',
                    'settings': {
                        'locale': 'en',
                        'optionalDetailsCompleted': true,
                        'email': {
                            'dailydigest': true,
                            'upper_mentioned_in_partup': true,
                            'invite_upper_to_partup_activity': true,
                            'invite_upper_to_network': true,
                            'partup_created_in_network': true,
                            'partups_networks_new_pending_upper': true,
                            'partups_networks_accepted': true,
                            'partups_new_comment_in_involved_conversation': true,
                            'partups_networks_new_upper': true,
                            'partups_networks_upper_left': true
                        },
                        'unsubscribe_email_token': 'nj8fwDnhzaPSKX4vf-8ZHFyWRL0ZKVRz00ZOrJdB-ug'
                    },
                    'image': 'oQeqgwkdd44JSBSW5',
                    'description': 'I am the first test user',
                    'tags': [
                        'education',
                        'school',
                        'teaching'
                    ],
                    'location': {
                        'city': 'Amsterdam',
                        'lat': 52.3702157000000028,
                        'lng': 4.8951679000000006,
                        'place_id': 'ChIJVXealLU_xkcRja_At0z9AGY',
                        'country': 'Netherlands'
                    },
                    'facebook_url': 'https://www.facebook.com/zuck',
                    'twitter_url': 'https://twitter.com/finkd',
                    'instagram_url': 'https://instagram.com/zuck/',
                    'linkedin_url': 'https://www.linkedin.com/pub/mark-zuckerberg/0/290/362',
                    'phonenumber': '+31612345678',
                    'website': 'http://www.facebook.com',
                    'skype': 'markzuckerberg',
                    'meurs': {
                        'portal': 'en',
                        'en_id': 'a15902ee-2b0d-49d6-9c7d-b54c2fdd6eee',
                        'nl_id': 'b59e003c-4bd4-48bd-80bf-69948df9a3b7',
                        'program_session_id': 32228,
                        'fetched_results': true,
                        'results': [
                            {
                                'code': 103401,
                                'name': 'Denkkracht',
                                'score': 8,
                                'zscore': 0.80003,
                                'dscore': 7,
                                'highIndex': 1
                            },
                            {
                                'code': 103403,
                                'name': 'Slagkracht',
                                'score': 8,
                                'zscore': 0.8000200000000001,
                                'dscore': 7,
                                'highIndex': 1
                            }
                        ]
                    }
                },
                'status': {
                    'online': true,
                    'lastLogin': {
                        'date': new Date('2015-07-21T13:29:39.740Z'),
                        'ipAddr': '127.0.0.1',
                        'userAgent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36'
                    },
                    'idle': false
                },
                'registered_emails': [
                    {
                        'address': 'user@example.com',
                        'verified': false
                    }
                ],
                'logins': [
                    new Date('2015-07-21T13:29:39.754Z')
                ],
                'networks': [
                    'ibn27M3ePaXhmKzWq',
                    'kRCjWDBkKru3KfsjW'
                ],
                'participation_score': 2,
                'upperOf': [
                    'ASfRYBAzo2ayYk5si',
                    'WxrpPuJkhafJB3gfF',
                    'gJngF65ZWyS9f3NDE'
                ],
                'flags': {
                    'dailyDigestEmailHasBeenSent': false
                }
            });

            Meteor.users.insert({
                '_id': 'K5c5M4Pbdg3B82wQI',
                'createdAt': new Date('2015-07-21T13:43:28.401Z'),
                'services': {
                    'password': {
                        'bcrypt': '$2a$10$nytjhtAbBUXe1Td8LrVJ4.jJa/lE62riuDM/dm79f3fqfeuZo2xNG'
                    },
                    'resume': {
                        'loginTokens': [
                            {
                                'when': new Date('2015-07-21T13:43:28.427Z'),
                                'hashedToken': 'OpaU/qV1S7zHl00V9Nkvc9cd6HVBgldaSOjxTbZKLUk='
                            }
                        ]
                    },
                    'email': {
                        'verificationTokens': [
                            {
                                'token': 'iLvpqSreco1pP4vBXXpxf3_tASF-KeDKMcDv1STKLhD',
                                'address': 'john@example.com',
                                'when': new Date('2015-07-21T13:43:33.407Z')
                            }
                        ]
                    }
                },
                'emails': [
                    {
                        'address': 'john@example.com',
                        'verified': false
                    }
                ],
                'completeness': 27,
                'profile': {
                    'name': 'John Partup',
                    'normalized_name': 'john partup',
                    'settings': {
                        'locale': 'en',
                        'optionalDetailsCompleted': true,
                        'email': {
                            'dailydigest': true,
                            'upper_mentioned_in_partup': true,
                            'invite_upper_to_partup_activity': true,
                            'invite_upper_to_network': true,
                            'partup_created_in_network': true,
                            'partups_networks_new_pending_upper': true,
                            'partups_networks_accepted': true,
                            'partups_new_comment_in_involved_conversation': true,
                            'partups_networks_new_upper': true,
                            'partups_networks_upper_left': true
                        },
                        'unsubscribe_email_token': '6BQGhT9KnxBKAIrn6Y7s565CTOO-SIqfjuHOkJt8ZbQ'
                    },
                    'image': 'cHhjpWKo9DHjXQQjy',
                    'description': null,
                    'tags': [
                        'education',
                        'nonprofit',
                        'development'
                    ],
                    'location': {
                        'city': 'Amstelveen',
                        'lat': 52.3114206999999993,
                        'lng': 4.8700869999999998,
                        'place_id': 'ChIJL2JPy9DhxUcRqXfKsBMyNVw',
                        'country': 'Netherlands'
                    },
                    'facebook_url': null,
                    'twitter_url': null,
                    'instagram_url': null,
                    'linkedin_url': null,
                    'phonenumber': null,
                    'website': '',
                    'skype': null,
                    'meurs': {
                        'portal': 'nl',
                        'nl_id': 'caba5cd4-f769-4093-878c-4ce3807781c3',
                        'program_session_id': 31373
                    }
                },
                'status': {
                    'online': true,
                    'lastLogin': {
                        'date': new Date('2015-07-21T13:43:28.514Z'),
                        'ipAddr': '127.0.0.1',
                        'userAgent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36'
                    },
                    'idle': false
                },
                'registered_emails': [
                    {
                        'address': 'john@example.com',
                        'verified': false
                    }
                ],
                'logins': [
                    new Date('2015-07-21T13:43:28.542Z')
                ],
                'participation_score': 3,
                'pending_networks': [],
                'networks': [
                    'wfCv4ZdPe5WNT4xfg'
                ],
                'upperOf': [
                    'CJETReuE6uo2eF7eW',
                    'gJngF65ZWyS9f3NDE'
                ],
                'flags': {
                    'dailyDigestEmailHasBeenSent': false
                }
            });

            Meteor.users.insert({
                '_id': 'q63Kii9wwJX3Q6rHS',
                'createdAt': new Date('2015-07-21T13:48:03.558Z'),
                'services': {
                    'password': {
                        'bcrypt': '$2a$10$nytjhtAbBUXe1Td8LrVJ4.jJa/lE62riuDM/dm79f3fqfeuZo2xNG'
                    },
                    'resume': {
                        'loginTokens': [
                            {
                                'when': new Date('2015-07-21T13:48:03.566Z'),
                                'hashedToken': 'vctK9ULMl4Gdegbr+73LED8So83rPz67Xi6KnnNQCVQ='
                            }
                        ]
                    },
                    'email': {
                        'verificationTokens': [
                            {
                                'token': '8crlkpFefwhO_RdgJbnV-8q4S-_M0yfjFsn--YYh4YZ',
                                'address': 'admin@example.com',
                                'when': new Date('2015-07-21T13:48:08.563Z')
                            }
                        ]
                    }
                },
                'emails': [
                    {
                        'address': 'admin@example.com',
                        'verified': false
                    }
                ],
                'completeness': 27,
                'profile': {
                    'name': 'Admin User',
                    'normalized_name': 'admin user',
                    'settings': {
                        'locale': 'en',
                        'optionalDetailsCompleted': true,
                        'email': {
                            'dailydigest': true,
                            'upper_mentioned_in_partup': true,
                            'invite_upper_to_partup_activity': true,
                            'invite_upper_to_network': true,
                            'partup_created_in_network': true,
                            'partups_networks_new_pending_upper': true,
                            'partups_networks_accepted': true,
                            'partups_new_comment_in_involved_conversation': true,
                            'partups_networks_new_upper': true,
                            'partups_networks_upper_left': true
                        },
                        'unsubscribe_email_token': 'Xr_FQVj16IQRwpoMxQOWgHMVr5z6Jd04wpvF00n6rK6'
                    },
                    'image': 'CxEprGKNWo6HdrTdq',
                    'description': null,
                    'tags': [
                        'administration',
                        'finance'
                    ],
                    'location': {
                        'city': 'Utrecht',
                        'lat': 52.0907373999999876,
                        'lng': 5.1214200999999999,
                        'place_id': 'ChIJNy3TOUNvxkcR6UqvGUz8yNY',
                        'country': 'Netherlands'
                    },
                    'facebook_url': null,
                    'twitter_url': null,
                    'instagram_url': null,
                    'linkedin_url': null,
                    'phonenumber': null,
                    'website': '',
                    'skype': null,
                    'meurs': {
                        'portal': 'en',
                        'nl_id': '44e74f98-fd0f-4c9a-82e1-82e1528409f5',
                        'en_id': 'b7b44c5b-36f9-4c88-a2a7-3b3aa8709255',
                        'program_session_id': 32724,
                        'fetched_results': true,
                        'results': [
                            {
                                'code': 103405,
                                'name': 'Persoonlijke kracht',
                                'score': 8,
                                'zscore': 0.8000400000000001,
                                'dscore': 7,
                                'highIndex': 1
                            },
                            {
                                'code': 103402,
                                'name': 'Stuurkracht',
                                'score': 7,
                                'zscore': 0.7000500000000001,
                                'dscore': 6,
                                'highIndex': 1
                            }
                        ]
                    }
                },
                'status': {
                    'online': true,
                    'lastLogin': {
                        'date': new Date('2015-07-21T13:48:03.623Z'),
                        'ipAddr': '127.0.0.1',
                        'userAgent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36'
                    },
                    'idle': false
                },
                'registered_emails': [
                    {
                        'address': 'admin@example.com',
                        'verified': false
                    }
                ],
                'logins': [
                    new Date('2015-07-21T13:48:03.641Z')
                ],
                'roles': ['admin'],
                'networks': [
                    'nqBnE8nSLasaapXXS',
                    'kRCjWDBkKru3KfsjW',
                    'wfCv4ZdPe5WNT4xfg',
                    'ibn27M3ePaXhmKzWq'
                ],
                'participation_score': 2,
                'flags': {
                    'dailyDigestEmailHasBeenSent': false
                }
            });

            Meteor.users.insert({
                '_id': 'a7qcp5RHnh5rfaeW9',
                'createdAt': new Date('2015-07-21T14:11:01.053Z'),
                'services': {
                    'password': {
                        'bcrypt': '$2a$10$nytjhtAbBUXe1Td8LrVJ4.jJa/lE62riuDM/dm79f3fqfeuZo2xNG'
                    },
                    'resume': {
                        'loginTokens': [
                            {
                                'when': new Date('2015-07-21T14:11:01.061Z'),
                                'hashedToken': 'QR5jRUOgOYNkrUZNjPdYicokC8hggzWimey9ccMMSG8='
                            }
                        ]
                    },
                    'email': {
                        'verificationTokens': [
                            {
                                'token': 'X0BHuAeVNCWozOenCCTdXltEXE1kPB0VZBriz39Src4',
                                'address': 'judy@example.com',
                                'when': new Date('2015-07-21T14:11:06.055Z')
                            }
                        ]
                    }
                },
                'emails': [
                    {
                        'address': 'judy@example.com',
                        'verified': false
                    }
                ],
                'completeness': 27,
                'profile': {
                    'name': 'Judy Partup',
                    'normalized_name': 'judy partup',
                    'settings': {
                        'locale': 'en',
                        'optionalDetailsCompleted': true,
                        'email': {
                            'dailydigest': true,
                            'upper_mentioned_in_partup': true,
                            'invite_upper_to_partup_activity': true,
                            'invite_upper_to_network': true,
                            'partup_created_in_network': true,
                            'partups_networks_new_pending_upper': true,
                            'partups_networks_accepted': true,
                            'partups_new_comment_in_involved_conversation': true,
                            'partups_networks_new_upper': true,
                            'partups_networks_upper_left': true
                        },
                        'unsubscribe_email_token': 'WiYdZ-AoYintHgYofjIlOyWTsP8f2oNKLhh3jhhpIdN'
                    },
                    'image': 'bMTGT9oSDGzxCL3r4',
                    'description': null,
                    'tags': [
                        'design',
                        'ux',
                        'photography',
                        'nonprofit'
                    ],
                    'location': {
                        'city': 'Maastricht',
                        'lat': 50.8513682000000031,
                        'lng': 5.6909725000000000,
                        'place_id': 'ChIJnwZBWOzpwEcRbqi-zHuV61M',
                        'country': 'Netherlands'
                    },
                    'facebook_url': null,
                    'twitter_url': null,
                    'instagram_url': null,
                    'linkedin_url': null,
                    'phonenumber': null,
                    'website': '',
                    'skype': null,
                    'meurs': {
                        'portal': 'en',
                        'nl_id': 'f8cb5c45-bdb5-4a98-9f98-a7d5fdcd7115',
                        'en_id': '503a6931-4a68-4595-83fa-4e77098727cc',
                        'program_session_id': 32698,
                        'fetched_results': true,
                        'results': [
                            {
                                'code': 103401,
                                'name': 'Denkkracht',
                                'score': 9,
                                'zscore': 0.90003,
                                'dscore': 8,
                                'highIndex': 1
                            },
                            {
                                'code': 103405,
                                'name': 'Persoonlijke kracht',
                                'score': 7,
                                'zscore': 0.7000400000000001,
                                'dscore': 6,
                                'highIndex': 1
                            }
                        ]
                    }
                },
                'status': {
                    'online': true,
                    'lastLogin': {
                        'date': new Date('2015-07-21T14:11:01.089Z'),
                        'ipAddr': '127.0.0.1',
                        'userAgent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36'
                    },
                    'idle': false
                },
                'registered_emails': [
                    {
                        'address': 'judy@example.com',
                        'verified': false
                    }
                ],
                'logins': [
                    new Date('2015-07-21T14:11:01.103Z')
                ],
                'supporterOf': [
                    'gJngF65ZWyS9f3NDE'
                ],
                'participation_score': 3,
                'pending_networks': [
                    'wfCv4ZdPe5WNT4xfg'
                ],
                'networks': [
                    'ibn27M3ePaXhmKzWq'
                ],
                'upperOf': [
                    'vGaxNojSerdizDPjb'
                ],
                'flags': {
                    'dailyDigestEmailHasBeenSent': false
                }
            });
        }

    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/partups.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {
        if (!Partups.find().count()) {
            /* 1 */
            Partups.insert({
                '_id' : 'gJngF65ZWyS9f3NDE',
                'name' : 'Crowd funding Part-up organiseren',
                'description' : 'Crowd funding campagne lanceren voor marketing en financiering app development.',
                'type' : Partups.TYPE.COMMERCIAL,
                'type_commercial_budget' : 1000,
                'end_date' : new Date('2016-11-30T00:00:00.000Z'),
                'image' : 'FTHbg6wbPxjiA4Y8w',
                'tags' : [
                    'crowdfunding',
                    'marketing',
                    'part-up',
                    'geld'
                ],
                'location' : {
                    'city' : 'Amsterdam',
                    'lat' : 52.3702157000000028,
                    'lng' : 4.8951679000000006,
                    'place_id' : 'ChIJVXealLU_xkcRja_At0z9AGY',
                    'country' : 'Netherlands'
                },
                'privacy_type' : 1,
                'uppers' : [
                    'K5c5M4Pbdg3B82wQH',
                    'K5c5M4Pbdg3B82wQI'
                ],
                'creator_id' : 'K5c5M4Pbdg3B82wQH',
                'created_at' : new Date('2015-07-21T14:03:19.964Z'),
                'slug' : 'crowd-funding-part-up-organiseren-gJngF65ZWyS9f3NDE',
                'activity_count' : 2,
                'analytics' : {
                    'clicks_total' : 1,
                    'clicks_per_day' : 1,
                    'clicks_per_hour' : [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
                    'last_ip' : '127.0.0.1'
                },
                'supporters' : [
                    'a7qcp5RHnh5rfaeW9'
                ],
                'featured' : {
                    'active' : true,
                    'by_upper' : {
                        '_id' : 'q63Kii9wwJX3Q6rHS',
                        'title' : 'Founder Part-up'
                    },
                    'comment' : '"Dit is een nederlandse quote voor een nederlandse partup"'
                },
                'language' : 'nl',
                'upper_data' : [
                    {
                        '_id' : 'K5c5M4Pbdg3B82wQH',
                        'new_updates' : []
                    },
                    {
                        '_id' : 'K5c5M4Pbdg3B82wQI',
                        'new_updates' : []
                    },
                    {
                        '_id' : 'a7qcp5RHnh5rfaeW9',
                        'new_updates' : []
                    }
                ]
            });

            /* 2 */
            Partups.insert({
                '_id' : 'CJETReuE6uo2eF7eW',
                'name' : 'Super secret closed ING partup',
                'description' : 'secret stuff',
                'type' : Partups.TYPE.CHARITY,
                'end_date' : new Date('2017-03-31T00:00:00.000Z'),
                'image' : 'D3zGxajTjWCLhXokS',
                'tags' : [
                    'ing',
                    'financial'
                ],
                'location' : {
                    'city' : 'Amsterdam',
                    'lat' : 52.3702157000000028,
                    'lng' : 4.8951679000000006,
                    'place_id' : 'ChIJVXealLU_xkcRja_At0z9AGY',
                    'country' : 'Netherlands'
                },
                'network_id' : 'wfCv4ZdPe5WNT4xfg',
                'privacy_type' : 5,
                'uppers' : [
                    'K5c5M4Pbdg3B82wQI'
                ],
                'creator_id' : 'K5c5M4Pbdg3B82wQI',
                'created_at' : new Date('2015-07-22T09:26:51.361Z'),
                'slug' : 'super-secret-closed-ing-partup-CJETReuE6uo2eF7eW',
                'analytics' : {
                    'clicks_total' : 1,
                    'clicks_per_day' : 1,
                    'clicks_per_hour' : [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    'last_ip' : '127.0.0.1'
                },
                'language' : 'en',
                'upper_data' : [
                    {
                        '_id' : 'K5c5M4Pbdg3B82wQI',
                        'new_updates' : []
                    }
                ]
            });

            /* 3 */
            Partups.insert({
                '_id' : 'ASfRYBAzo2ayYk5si',
                'name' : 'A semisecret ING partup, plus ones are ok',
                'description' : 'semi secret organized stuff',
                'type' : Partups.TYPE.ENTERPRISING,
                'end_date' : new Date('2017-01-31T00:00:00.000Z'),
                'image' : 'ComeF2exAjeKBPAf8',
                'tags' : [
                    'ing',
                    'organizational'
                ],
                'location' : {
                    'city' : 'Amsterdam',
                    'lat' : 52.3702157000000028,
                    'lng' : 4.8951679000000006,
                    'place_id' : 'ChIJVXealLU_xkcRja_At0z9AGY',
                    'country' : 'Netherlands'
                },
                'network_id' : 'kRCjWDBkKru3KfsjW',
                'privacy_type' : 4,
                'uppers' : [
                    'K5c5M4Pbdg3B82wQH'
                ],
                'creator_id' : 'K5c5M4Pbdg3B82wQH',
                'created_at' : new Date('2015-07-22T09:38:22.609Z'),
                'slug' : 'a-semisecret-ing-partup-plus-ones-are-ok-ASfRYBAzo2ayYk5si',
                'analytics' : {
                    'clicks_total' : 1,
                    'clicks_per_day' : 1,
                    'clicks_per_hour' : [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    'last_ip' : '127.0.0.1'
                },
                'language' : 'en',
                'upper_data' : [
                    {
                        '_id' : 'K5c5M4Pbdg3B82wQH',
                        'new_updates' : []
                    }
                ]
            });

            /* 4 */
            Partups.insert({
                '_id' : 'vGaxNojSerdizDPjb',
                'name' : 'Organise a Meteor Meetup',
                'description' : 'organise a meetup at lifely',
                'type' : Partups.TYPE.CHARITY,
                'end_date' : new Date('2017-01-31T00:00:00.000Z'),
                'image' : 'J2KxajXMcqiKwrEBu',
                'tags' : [
                    'lifely',
                    'meetup',
                    'meteor'
                ],
                'location' : {
                    'city' : 'Utrecht',
                    'lat' : 52.0907373999999876,
                    'lng' : 5.1214200999999999,
                    'place_id' : 'ChIJNy3TOUNvxkcR6UqvGUz8yNY',
                    'country' : 'Netherlands'
                },
                'network_id' : 'ibn27M3ePaXhmKzWq',
                'privacy_type' : 3,
                'uppers' : [
                    'a7qcp5RHnh5rfaeW9'
                ],
                'creator_id' : 'a7qcp5RHnh5rfaeW9',
                'created_at' : new Date('2015-07-22T09:42:13.878Z'),
                'slug' : 'organise-a-meteor-meetup-vGaxNojSerdizDPjb',
                'analytics' : {
                    'clicks_total' : 1,
                    'clicks_per_day' : 1,
                    'clicks_per_hour' : [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                    'last_ip' : '127.0.0.1'
                },
                'language' : 'en',
                'featured' : {
                    'active' : true,
                    'by_upper' : {
                        '_id' : 'q63Kii9wwJX3Q6rHS',
                        'title' : 'Founder Part-up'
                    },
                    'comment' : '"This is an english quote for an english partup"'
                },
                'upper_data' : [
                    {
                        '_id' : 'a7qcp5RHnh5rfaeW9',
                        'new_updates' : []
                    }
                ]
            });

            /* 5 */
            Partups.insert({
                '_id' : 'WxrpPuJkhafJB3gfF',
                'name' : 'Partup Premium Part-up',
                'description' : 'private',
                'type' : Partups.TYPE.ORGANIZATION,
                'type_organization_budget' : 130,
                'end_date' : new Date('2017-05-31T00:00:00.000Z'),
                'image' : 'xfYreAouRFh4mnctk',
                'tags' : [
                    'private'
                ],
                'location' : {
                    'city' : 'Amsterdam',
                    'lat' : 52.3702157000000028,
                    'lng' : 4.8951679000000006,
                    'place_id' : 'ChIJVXealLU_xkcRja_At0z9AGY',
                    'country' : 'Netherlands'
                },
                'privacy_type' : 2,
                'uppers' : [
                    'K5c5M4Pbdg3B82wQH'
                ],
                'creator_id' : 'K5c5M4Pbdg3B82wQH',
                'created_at' : new Date('2015-07-28T15:26:34.086Z'),
                'slug' : 'partup-premium-part-up-WxrpPuJkhafJB3gfF',
                'analytics' : {
                    'clicks_total' : 1,
                    'clicks_per_day' : 1,
                    'clicks_per_hour' : [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
                    'last_ip' : '127.0.0.1'
                },
                'language' : 'en',
                'upper_data' : [
                    {
                        '_id' : 'K5c5M4Pbdg3B82wQH',
                        'new_updates' : []
                    }
                ]
            });

            /* 6-36 */
            /*
            for (var i = 0; i < 30; i++) {
               var descriptions = [
                   'This describes just how great this Part-up is, so please join and let\'s make it the best part-up on the web.',
                   'This describes just how great this Part-up is.',
                   'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima error veritatis ratione dolor perferendis inventore optio. Error omnis nostrum expedita.',
                   'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum repudiandae exercitationem unde sunt voluptatum consequatur at ipsum incidunt praesentium. Lorem ipsum dolor sit amet.'
               ];

               Partups.insert({
                   name: Fake.fromArray([Fake.sentence(2), Fake.sentence(3), Fake.sentence(4), Fake.sentence(5)]).replace('.', ''),
                   description: Fake.paragraph(Fake.fromArray([1, 2, 3, 4])),
                   creator_id: 'K5c5M4Pbdg3B82wQH',
                   tags: Fake.fromArray([[Fake.word()], [Fake.word(), Fake.word()], [Fake.word(), Fake.word(), Fake.word()], [Fake.word(), Fake.word(), Fake.word(), Fake.word()]]),
                   uppers: ['K5c5M4Pbdg3B82wQH', 'K5c5M4Pbdg3B82wQI'],
                   location: undefined,
                   privacy_type: Partups.PUBLIC,
                   image: 'FTHbg6wbPxjiA4Y8w',
                   created_at : new Date('2015-03-26T16:25:07.816Z'),
                   end_date: new Date('2015-06-01T10:00:07.100Z'),
               });
            }
            */
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/updates.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {

        if (!Updates.find().count()) {
            //First partup
            /* 1 */
            Updates.insert({
                '_id' : 'ZpxagHRXEZzxqnEtx',
                'upper_id' : 'K5c5M4Pbdg3B82wQH',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type' : 'partups_created',
                'type_data' : {},
                'comments_count' : 0,
                'created_at' : new Date('2015-07-21T14:03:19.990Z'),
                'updated_at' : new Date('2015-07-21T14:03:19.990Z')
            });

            /* 2 */
            Updates.insert({
                '_id' : 'Mq83xei2S62HNNRHH',
                'upper_id' : null,
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'system' : true,
                'type' : 'partups_message_added',
                'type_data' : {
                    'type' : 'welcome_message'
                },
                'comments_count' : 0,
                'created_at' : new Date('2015-07-21T14:03:19.995Z'),
                'updated_at' : new Date('2015-07-21T14:03:19.995Z')
            });

            /* 3 */
            Updates.insert({
                '_id' : 'BWQzehWhCX5ZTpLLh',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type_data' : {
                    'new_value' : 'Default user was here. Maybe we can add some more activities?',
                    'images' : []
                },
                'comments_count' : 1,
                'upper_id' : 'K5c5M4Pbdg3B82wQH',
                'created_at' : new Date('2015-07-21T14:07:20.064Z'),
                'updated_at' : new Date('2015-07-21T14:08:02.797Z'),
                'type' : 'partups_message_added',
                'comments' : [
                    {
                        '_id' : 'gX9ZDAfsgkaZFPag5',
                        'content' : 'That sounds like a good idea. I will do some suggestions for contributions as well!',
                        'type' : null,
                        'creator' : {
                            '_id' : 'K5c5M4Pbdg3B82wQI',
                            'name' : 'John Partup',
                            'image' : 'nL2MYYXJ3eFeb2GYq'
                        },
                        'created_at' : new Date('2015-07-21T14:08:02.796Z'),
                        'updated_at' : new Date('2015-07-21T14:08:02.796Z')
                    }
                ]
            });

            /* 4 */
            Updates.insert({
                '_id' : 'Wjtg7f6TqX78qPZ68',
                'upper_id' : 'K5c5M4Pbdg3B82wQI',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type' : 'partups_supporters_added',
                'type_data' : {},
                'comments_count' : 0,
                'created_at' : new Date('2015-07-21T14:08:02.827Z'),
                'updated_at' : new Date('2015-07-21T14:08:02.827Z')
            });

            /* 5 */
            Updates.insert({
                '_id' : '5BDYurmbYkiFbNho4',
                'upper_id' : 'K5c5M4Pbdg3B82wQH',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type' : 'partups_ratings_changed',
                'type_data' : {
                    'activity_id' : 'ruvTupX9WMmqFTLuL',
                    'contribution_id' : 'yZ42ydeKrXCfGsjXo',
                    'rating_id' : 'qRckrxhXHWTsgwFcu'
                },
                'comments_count' : 0,
                'created_at' : new Date('2015-07-21T14:09:28.476Z'),
                'updated_at' : new Date('2015-07-21T14:10:00.404Z')
            });

            /* 6 */
            Updates.insert({
                '_id' : 'fWNZE2Xmd2KeQBWJK',
                'upper_id' : 'K5c5M4Pbdg3B82wQI',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type' : 'partups_uppers_added',
                'type_data' : {},
                'comments_count' : 0,
                'created_at' : new Date('2015-07-21T14:09:44.627Z'),
                'updated_at' : new Date('2015-07-21T14:09:44.627Z')
            });

            /* 7 */
            Updates.insert({
                '_id' : 'rqAFPrKayDd8Ko6YK',
                'upper_id' : 'K5c5M4Pbdg3B82wQI',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type' : 'partups_activities_comments_added',
                'type_data' : {
                    'activity_id' : 'ruvTupX9WMmqFTLuL'
                },
                'comments_count' : 4,
                'created_at' : new Date('2015-07-21T14:03:49.141Z'),
                'updated_at' : new Date('2015-07-21T14:09:28.443Z'),
                'comments' : [
                    {
                        '_id' : 'tPakKpxTBLTnNRhEy',
                        'content' : 'Im known with these kind of platforms, it would be a perfect fit',
                        'type' : 'motivation',
                        'creator' : {
                            '_id' : 'K5c5M4Pbdg3B82wQI',
                            'name' : 'John Partup',
                            'image' : 'nL2MYYXJ3eFeb2GYq'
                        },
                        'created_at' : new Date('2015-07-21T14:09:28.442Z'),
                        'updated_at' : new Date('2015-07-21T14:09:28.442Z')
                    },
                    {
                        '_id' : 'DazsZWrkJr8nvYdhd',
                        'content' : 'system_contributions_proposed',
                        'type' : 'system',
                        'creator' : {
                            '_id' : 'K5c5M4Pbdg3B82wQI',
                            'name' : 'John Partup'
                        },
                        'created_at' : new Date('2015-07-21T14:09:28.491Z'),
                        'updated_at' : new Date('2015-07-21T14:09:28.491Z')
                    },
                    {
                        '_id' : 'SZRMLnpTrqYA89Mot',
                        'content' : 'system_contributions_accepted',
                        'type' : 'system',
                        'creator' : {
                            '_id' : 'K5c5M4Pbdg3B82wQH',
                            'name' : 'Default User'
                        },
                        'created_at' : new Date('2015-07-21T14:09:44.632Z'),
                        'updated_at' : new Date('2015-07-21T14:09:44.632Z')
                    },
                    {
                        '_id' : 'zLnzvPTg4r8CPyhJx',
                        'content' : 'system_ratings_inserted',
                        'type' : 'system',
                        'creator' : {
                            '_id' : 'K5c5M4Pbdg3B82wQH',
                            'name' : 'Default User'
                        },
                        'created_at' : new Date('2015-07-21T14:09:50.919Z'),
                        'updated_at' : new Date('2015-07-21T14:09:50.919Z')
                    }
                ]
            });

            /* 8 */
            Updates.insert({
                '_id' : 'hvL6bnH5ckaA599d4',
                'upper_id' : 'a7qcp5RHnh5rfaeW9',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type' : 'partups_activities_comments_added',
                'type_data' : {
                    'activity_id' : 'SYwR9AHWc7AKsfMrv'
                },
                'comments_count' : 2,
                'created_at' : new Date('2015-07-21T14:03:57.906Z'),
                'updated_at' : new Date('2015-07-21T14:11:51.704Z'),
                'comments' : [
                    {
                        '_id' : 'cMPLeKqdH3j84ocZ5',
                        'content' : 'Ive written quite a few of these before, let me do it!',
                        'type' : 'motivation',
                        'creator' : {
                            '_id' : 'a7qcp5RHnh5rfaeW9',
                            'name' : 'Judy Partup',
                            'image' : 'LG9J5XA4PPg5B8ZNu'
                        },
                        'created_at' : new Date('2015-07-21T14:11:51.703Z'),
                        'updated_at' : new Date('2015-07-21T14:11:51.703Z')
                    },
                    {
                        '_id' : 'ZFHwPcstE3vbcuFDt',
                        'content' : 'system_contributions_proposed',
                        'type' : 'system',
                        'creator' : {
                            '_id' : 'a7qcp5RHnh5rfaeW9',
                            'name' : 'Judy Partup'
                        },
                        'created_at' : new Date('2015-07-21T14:11:51.996Z'),
                        'updated_at' : new Date('2015-07-21T14:11:51.996Z')
                    }
                ]
            });

            /* 9 */
            Updates.insert({
                '_id' : 'cSrhFNj9egtsbcAZM',
                'upper_id' : 'a7qcp5RHnh5rfaeW9',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type' : 'partups_supporters_added',
                'type_data' : {},
                'comments_count' : 0,
                'created_at' : new Date('2015-07-21T14:11:51.758Z'),
                'updated_at' : new Date('2015-07-21T14:11:51.758Z')
            });

            /* 10 */
            Updates.insert({
                '_id' : 'AttwbATkJYcTeNtHz',
                'upper_id' : 'a7qcp5RHnh5rfaeW9',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'type' : 'partups_contributions_proposed',
                'type_data' : {
                    'activity_id' : 'SYwR9AHWc7AKsfMrv',
                    'contribution_id' : '4GggDMBiHz44afReM'
                },
                'comments_count' : 0,
                'created_at' : new Date('2015-07-21T14:11:51.960Z'),
                'updated_at' : new Date('2015-07-21T14:11:51.960Z')
            });

            /* 11 */
            Updates.insert({
                '_id' : 'uHf3ZxiK57rRQMqqg',
                'upper_id' : 'K5c5M4Pbdg3B82wQI',
                'partup_id' : 'CJETReuE6uo2eF7eW',
                'type' : 'partups_created',
                'type_data' : {},
                'comments_count' : 0,
                'created_at' : new Date('2015-07-22T09:26:51.376Z'),
                'updated_at' : new Date('2015-07-22T09:26:51.376Z')
            });

            /* 12 */
            Updates.insert({
                '_id' : 'AFsgqhFAnyruXC5bQ',
                'upper_id' : null,
                'partup_id' : 'CJETReuE6uo2eF7eW',
                'system' : true,
                'type' : 'partups_message_added',
                'type_data' : {
                    'type' : 'welcome_message'
                },
                'comments_count' : 0,
                'created_at' : new Date('2015-07-22T09:26:51.377Z'),
                'updated_at' : new Date('2015-07-22T09:26:51.377Z')
            });

            /* 13 */
            Updates.insert({
                '_id' : '9S6sskRnudTefQXrs',
                'upper_id' : 'K5c5M4Pbdg3B82wQH',
                'partup_id' : 'ASfRYBAzo2ayYk5si',
                'type' : 'partups_created',
                'type_data' : {},
                'comments_count' : 0,
                'created_at' : new Date('2015-07-22T09:38:22.622Z'),
                'updated_at' : new Date('2015-07-22T09:38:22.622Z')
            });

            /* 14 */
            Updates.insert({
                '_id' : '5KyKiFf3ZyKeepX8S',
                'upper_id' : null,
                'partup_id' : 'ASfRYBAzo2ayYk5si',
                'system' : true,
                'type' : 'partups_message_added',
                'type_data' : {
                    'type' : 'welcome_message'
                },
                'comments_count' : 0,
                'created_at' : new Date('2015-07-22T09:38:22.627Z'),
                'updated_at' : new Date('2015-07-22T09:38:22.627Z')
            });

            /* 15 */
            Updates.insert({
                '_id' : '5H5BdQxxgdTQotgCq',
                'upper_id' : 'a7qcp5RHnh5rfaeW9',
                'partup_id' : 'vGaxNojSerdizDPjb',
                'type' : 'partups_created',
                'type_data' : {},
                'comments_count' : 0,
                'created_at' : new Date('2015-07-22T09:42:13.894Z'),
                'updated_at' : new Date('2015-07-22T09:42:13.894Z')
            });

            /* 16 */
            Updates.insert({
                '_id' : '9g5dpuR5SWkvnDJLH',
                'upper_id' : null,
                'partup_id' : 'vGaxNojSerdizDPjb',
                'system' : true,
                'type' : 'partups_message_added',
                'type_data' : {
                    'type' : 'welcome_message'
                },
                'comments_count' : 0,
                'created_at' : new Date('2015-07-22T09:42:13.895Z'),
                'updated_at' : new Date('2015-07-22T09:42:13.895Z')
            });
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/activities.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {

        if (!Activities.find().count()) {

            //first partup
            Activities.insert({
                '_id' : 'ruvTupX9WMmqFTLuL',
                'name' : 'crowd funding platform selectie',
                'description' : 'kickstarter wellicht?',
                'end_date' : new Date('2016-04-21T00:00:00.000Z'),
                'created_at' : new Date('2015-07-21T14:03:49.139Z'),
                'updated_at' : new Date('2015-07-21T14:03:49.139Z'),
                'creator_id' : 'K5c5M4Pbdg3B82wQH',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'archived' : false,
                'update_id' : 'rqAFPrKayDd8Ko6YK'
            });

            Activities.insert({
                '_id' : 'SYwR9AHWc7AKsfMrv',
                'name' : 'communicatie campagne bedenken',
                'description' : null,
                'end_date' : null,
                'created_at' : new Date('2015-07-21T14:03:57.905Z'),
                'updated_at' : new Date('2015-07-21T14:03:57.905Z'),
                'creator_id' : 'K5c5M4Pbdg3B82wQH',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'archived' : false,
                'update_id' : 'hvL6bnH5ckaA599d4'
            });

        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/contributions.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {

        if (!Contributions.find().count()) {
            //First partup
            /* 1 */
            Contributions.insert({
                '_id' : 'TtC4Dnbo4CSdTLR9L',
                'hours' : 10,
                'rate' : 50,
                'created_at' : new Date('2015-03-26T16:25:07.816Z'),
                'activity_id' : 'ZtJwZWikiFE7HpXLk',
                'upper_id' : '124',
                'partup_id' : '1111',
                'verified' : true,
                'update_id' : 'FzvicjkgyXPiYTqbs',
                'updated_at' : new Date('2015-03-26T16:25:07.816Z')
            });

            /* 2 */
            Contributions.insert({
                '_id' : 'JbXCzb82hqm4Bjwze',
                'hours' : null,
                'rate' : null,
                'created_at' : new Date('2015-03-26T16:25:07.816Z'),
                'activity_id' : 'ZtJwZWikiFE7HpXLk',
                'upper_id' : '124',
                'partup_id' : '1111',
                'verified' : false,
                'update_id' : '38mpZCcjpS8vBA8Ys'
            });

            /* 3 */
            Contributions.insert({
                '_id' : 'yZ42ydeKrXCfGsjXo',
                'hours' : null,
                'rate' : null,
                'created_at' : new Date('2015-07-21T14:09:28.473Z'),
                'activity_id' : 'ruvTupX9WMmqFTLuL',
                'upper_id' : 'K5c5M4Pbdg3B82wQI',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'verified' : true,
                'update_id' : '5BDYurmbYkiFbNho4'
            });

            /* 4 */
            Contributions.insert({
                '_id' : '4GggDMBiHz44afReM',
                'hours' : null,
                'rate' : null,
                'created_at' : new Date('2015-07-21T14:11:51.956Z'),
                'activity_id' : 'SYwR9AHWc7AKsfMrv',
                'upper_id' : 'a7qcp5RHnh5rfaeW9',
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'verified' : false,
                'update_id' : 'AttwbATkJYcTeNtHz'
            });
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/ratings.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {

        if (!Ratings.find().count()) {

            Ratings.insert({
                '_id' : 'qRckrxhXHWTsgwFcu',
                'created_at' : new Date('2015-07-21T14:09:50.895Z'),
                'partup_id' : 'gJngF65ZWyS9f3NDE',
                'activity_id' : 'ruvTupX9WMmqFTLuL',
                'contribution_id' : 'yZ42ydeKrXCfGsjXo',
                'rating' : 79,
                'feedback' : 'Very nice work John!',
                'upper_id' : 'K5c5M4Pbdg3B82wQH',
                'rated_upper_id' : 'K5c5M4Pbdg3B82wQI',
                'updated_at' : new Date('2015-07-21T14:10:00.389Z')
            });
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/tags.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {

        if (!Tags.find().count()) {

            Tags.insert({
                '_id' : 'crowdfunding'
            });

            /* 2 */
            Tags.insert({
                '_id' : 'marketing'
            });

            /* 3 */
            Tags.insert({
                '_id' : 'part-up'
            });

            /* 4 */
            Tags.insert({
                '_id' : 'geld'
            });

            /* 5 */
            Tags.insert({
                '_id' : 'design'
            });

            /* 6 */
            Tags.insert({
                '_id' : 'ux'
            });

            /* 7 */
            Tags.insert({
                '_id' : 'photography'
            });

            /* 8 */
            Tags.insert({
                '_id' : 'nonprofit'
            });

            /* 9 */
            Tags.insert({
                '_id' : 'ing'
            });

            /* 10 */
            Tags.insert({
                '_id' : 'financial'
            });

            /* 11 */
            Tags.insert({
                '_id' : 'organizational'
            });

            /* 12 */
            Tags.insert({
                '_id' : 'lifely'
            });

            /* 13 */
            Tags.insert({
                '_id' : 'meetup'
            });

            /* 14 */
            Tags.insert({
                '_id' : 'meteor'
            });
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/notifications.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {
        if (!Notifications.find().count()) {

            /* 1 */
            Notifications.insert({
                '_id' : 'zBWjQJLbB3s6XJbi7',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQH',
                'type' : 'partups_supporters_added',
                'type_data' : {
                    'partup' : {
                        '_id': 'gJngF65ZWyS9f3NDE',
                        'name' : 'Crowd funding Part-up organiseren',
                        'slug' : 'crowd-funding-part-up-organiseren-gJngF65ZWyS9f3NDE'
                    },
                    'supporter' : {
                        '_id' : 'K5c5M4Pbdg3B82wQI',
                        'name' : 'John Partup',
                        'image' : 'cHhjpWKo9DHjXQQjy'
                    }
                },
                'created_at' : new Date('2015-07-21T14:08:02.831Z'),
                'new' : true,
                'clicked': false
            });

            /* 2 */
            Notifications.insert({
                '_id' : '924QY78LuAhmr3g8P',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQI',
                'type' : 'partups_contributions_accepted',
                'type_data' : {
                    'accepter': {
                        '_id': 'K5c5M4Pbdg3B82wQH',
                        'name': 'Default User',
                        'image': 'oQeqgwkdd44JSBSW5'
                    },
                    'activity': {
                        '_id': 'ruvTupX9WMmqFTLuL',
                        'name': 'crowd funding platform selectie'
                    },
                    'partup' : {
                        '_id': 'gJngF65ZWyS9f3NDE',
                        'name' : 'Crowd funding Part-up organiseren',
                        'slug' : 'crowd-funding-part-up-organiseren-gJngF65ZWyS9f3NDE'
                    }
                },
                'created_at' : new Date('2015-07-21T14:09:44.629Z'),
                'new' : true,
                'clicked': false
            });

            /* 3 */
            Notifications.insert({
                '_id' : 'RLAuZh7JtqAD9qzHh',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQI',
                'type' : 'contributions_ratings_inserted',
                'type_data' : {
                    'rater' : {
                        '_id' : 'K5c5M4Pbdg3B82wQH',
                        'name' : 'Default User',
                        'image' : 'oQeqgwkdd44JSBSW5'
                    },
                    'partup' : {
                        '_id': 'gJngF65ZWyS9f3NDE',
                        'name' : 'Crowd funding Part-up organiseren',
                        'slug' : 'crowd-funding-part-up-organiseren-gJngF65ZWyS9f3NDE'
                    }
                },
                'created_at' : new Date('2015-07-21T14:09:50.912Z'),
                'new' : true,
                'clicked': false
            });

            /* 4 */
            Notifications.insert({
                '_id' : 'rizKNF2EnSHp8naRd',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQH',
                'type' : 'partups_supporters_added',
                'type_data' : {
                    'partup' : {
                        '_id': 'gJngF65ZWyS9f3NDE',
                        'name' : 'Crowd funding Part-up organiseren',
                        'slug' : 'crowd-funding-part-up-organiseren-gJngF65ZWyS9f3NDE'
                    },
                    'supporter' : {
                        '_id' : 'a7qcp5RHnh5rfaeW9',
                        'name' : 'Judy Partup',
                        'image' : 'bMTGT9oSDGzxCL3r4'
                    }
                },
                'created_at' : new Date('2015-07-21T14:11:51.761Z'),
                'new' : true,
                'clicked': false
            });

            /* 5 */
            Notifications.insert({
                '_id' : '2Ls7pgz7oAiyg5X2N',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQI',
                'type' : 'partups_supporters_added',
                'type_data' : {
                    'partup' : {
                        '_id': 'gJngF65ZWyS9f3NDE',
                        'name' : 'Crowd funding Part-up organiseren',
                        'slug' : 'crowd-funding-part-up-organiseren-gJngF65ZWyS9f3NDE'
                    },
                    'supporter' : {
                        '_id' : 'a7qcp5RHnh5rfaeW9',
                        'name' : 'Judy Partup',
                        'image' : 'bMTGT9oSDGzxCL3r4'
                    }
                },
                'created_at' : new Date('2015-07-21T14:11:51.763Z'),
                'new' : true,
                'clicked': false
            });

            /* 6 */
            Notifications.insert({
                '_id' : 'ERwBsEAExaN95yZ3y',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQH',
                'type' : 'partups_networks_invited',
                'type_data' : {
                    'inviter' : {
                        '_id' : 'q63Kii9wwJX3Q6rHS',
                        'name' : 'Admin User',
                        'image' : 'CxEprGKNWo6HdrTdq'
                    },
                    'network' : {
                        '_id' : 'kRCjWDBkKru3KfsjW',
                        'name' : 'ING (invite)',
                        'image' : 'efDuvuTzpqH65P9DF',
                        'slug' : 'ing-invite'
                    }
                },
                'created_at' : new Date('2015-07-22T09:00:30.168Z'),
                'new' : true,
                'clicked': false
            });

            /* 7 */
            Notifications.insert({
                '_id' : 'o9E59Hsi4FLZmcfhy',
                'for_upper_id' : 'a7qcp5RHnh5rfaeW9',
                'type' : 'partups_networks_invited',
                'type_data' : {
                    'inviter' : {
                        '_id' : 'q63Kii9wwJX3Q6rHS',
                        'name' : 'Admin User',
                        'image' : 'CxEprGKNWo6HdrTdq'
                    },
                    'network' : {
                        '_id': 'kRCjWDBkKru3KfsjW',
                        'name' : 'ING (invite)',
                        'image' : 'efDuvuTzpqH65P9DF',
                        'slug' : 'ing-invite'
                    }
                },
                'created_at' : new Date('2015-07-22T09:11:08.083Z'),
                'new' : true,
                'clicked': false
            });

            /* 8 */
            Notifications.insert({
                '_id' : 'qK2d2j4PBoNzKrqPA',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQI',
                'type' : 'partups_networks_invited',
                'type_data' : {
                    'inviter' : {
                        '_id' : 'q63Kii9wwJX3Q6rHS',
                        'name' : 'Admin User',
                        'image' : 'CxEprGKNWo6HdrTdq'
                    },
                    'network' : {
                        '_id': 'wfCv4ZdPe5WNT4xfg',
                        'name' : 'ING (closed)',
                        'image' : 'PnYAg3EX5dKfEnkdn',
                        'slug' : 'ing-closed'
                    }
                },
                'created_at' : new Date('2015-07-22T09:12:46.323Z'),
                'new' : true,
                'clicked': false
            });

            /* 9 */
            Notifications.insert({
                '_id' : 'yhkbye8nzLzxN7399',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQI',
                'type' : 'partups_networks_accepted',
                'type_data' : {
                    'network' : {
                        '_id': 'wfCv4ZdPe5WNT4xfg',
                        'name' : 'ING (closed)',
                        'image' : 'PnYAg3EX5dKfEnkdn',
                        'slug' : 'ing-closed'
                    }
                },
                'created_at' : new Date('2015-07-22T09:23:58.070Z'),
                'new' : true,
                'clicked': false
            });

            /* 10 */
            Notifications.insert({
                '_id' : 'xWx3q5f8Wviq6tuSD',
                'for_upper_id' : 'a7qcp5RHnh5rfaeW9',
                'type' : 'partups_networks_invited',
                'type_data' : {
                    'inviter' : {
                        '_id' : 'q63Kii9wwJX3Q6rHS',
                        'name' : 'Admin User',
                        'image' : 'CxEprGKNWo6HdrTdq'
                    },
                    'network' : {
                        '_id': 'wfCv4ZdPe5WNT4xfg',
                        'name' : 'ING (closed)',
                        'image' : 'PnYAg3EX5dKfEnkdn',
                        'slug' : 'ing-closed'
                    }
                },
                'created_at' : new Date('2015-07-22T09:31:48.389Z'),
                'new' : true,
                'clicked': false
            });

            /* 11 */
            Notifications.insert({
                '_id' : 'zBWjQJLbB3s6XJci8',
                'for_upper_id' : 'K5c5M4Pbdg3B82wQH',
                'type' : 'partups_ratings_reminder',
                'type_data' : {
                    'partup' : {
                        '_id': 'gJngF65ZWyS9f3NDE',
                        'name' : 'Crowd funding Part-up organiseren',
                        'slug' : 'crowd-funding-part-up-organiseren-gJngF65ZWyS9f3NDE'
                    }
                },
                'created_at' : new Date('2015-07-21T14:08:02.831Z'),
                'new' : true,
                'clicked': false
            });
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/networks.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {
        if (!Networks.find().count()) {

            /* 1 */
            Networks.insert({
                '_id' : 'nqBnE8nSLasaapXXS',
                'name' : 'ING (public)',
                'privacy_type' : 1,
                'slug' : 'ing-public',
                'image': 'T8pfWebTJmvbBNJ2g',
                'icon': 'f7yzkqh9J9JvxCCqN',
                'description': 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Possimus veniam illo inventore excepturi architecto ut, numquam enim est assumenda ex doloremque quos ratione. Repellendus blanditiis, tempora fugit velit est deleniti.',
                'uppers' : [
                    'q63Kii9wwJX3Q6rHS'
                ],
                'admins' : ['q63Kii9wwJX3Q6rHS'],
                'created_at' : new Date('2015-07-21T15:47:33.225Z'),
                'updated_at' : new Date('2015-07-21T15:47:33.225Z'),
                'featured' : {
                    'active' : true,
                    'by_upper' : {
                        '_id' : 'q63Kii9wwJX3Q6rHS',
                        'title' : 'Founder Part-up'
                    },
                    'comment' : '"This is the first featured network"'
                },
                'language': 'en'
            });

            /* 2 */
            Networks.insert({
                '_id' : 'kRCjWDBkKru3KfsjW',
                'name' : 'ING (invite)',
                'privacy_type' : 2,
                'slug' : 'ing-invite',
                'image': 'efDuvuTzpqH65P9DF',
                'icon': 'fReGXG4qkNXb4K8wp',
                'description': 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Modi architecto consequatur unde dolorem fuga laboriosam non alias blanditiis odit vero!',
                'uppers' : [
                    'q63Kii9wwJX3Q6rHS',
                    'K5c5M4Pbdg3B82wQH'
                ],
                'admins' : ['q63Kii9wwJX3Q6rHS'],
                'created_at' : new Date('2015-07-21T15:51:48.825Z'),
                'updated_at' : new Date('2015-07-21T15:51:48.825Z'),
                'invites' : [
                    {
                        '_id' : 'a7qcp5RHnh5rfaeW9',
                        'invited_at' : new Date('2015-07-22T09:11:08.062Z'),
                        'invited_by_id' : 'K5c5M4Pbdg3B82wQH'
                    }
                ]
            });

            /* 3 */
            Networks.insert({
                '_id' : 'wfCv4ZdPe5WNT4xfg',
                'name' : 'ING (closed)',
                'privacy_type' : 3,
                'slug' : 'ing-closed',
                'image': 'PnYAg3EX5dKfEnkdn',
                'icon': '4rymNTA3jFfTRKtFJ',
                'description': 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo nesciunt tempora accusamus temporibus ipsam modi.',
                'uppers' : [
                    'q63Kii9wwJX3Q6rHS',
                    'K5c5M4Pbdg3B82wQI'
                ],
                'admins' : ['q63Kii9wwJX3Q6rHS'],
                'created_at' : new Date('2015-07-21T15:51:56.562Z'),
                'updated_at' : new Date('2015-07-21T15:51:56.562Z'),
                'invites' : [
                    {
                        '_id' : 'K5c5M4Pbdg3B82wQI',
                        'invited_at' : new Date('2015-07-22T09:12:46.307Z'),
                        'invited_by_id' : 'q63Kii9wwJX3Q6rHS'
                    },
                    {
                        '_id' : 'a7qcp5RHnh5rfaeW9',
                        'invited_at' : new Date('2015-07-22T09:31:48.358Z'),
                        'invited_by_id' : 'q63Kii9wwJX3Q6rHS'
                    }
                ],
                'pending_uppers' : [
                    'a7qcp5RHnh5rfaeW9'
                ]
            });

            /* 4 */
            Networks.insert({
                '_id' : 'ibn27M3ePaXhmKzWq',
                'name' : 'Lifely (open)',
                'privacy_type' : 1,
                'slug' : 'lifely-open',
                'image': 'raaNx9aqA6okiqaS4',
                'icon': 'SEswZsYiTTKTTdnN5',
                'description': 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, delectus.',
                'uppers' : [
                    'q63Kii9wwJX3Q6rHS',
                    'K5c5M4Pbdg3B82wQH',
                    'a7qcp5RHnh5rfaeW9'
                ],
                'admins' : ['q63Kii9wwJX3Q6rHS'],
                'created_at' : new Date('2015-07-21T15:52:04.548Z'),
                'updated_at' : new Date('2015-07-21T15:52:04.548Z'),
                'featured' : {
                    'active' : true,
                    'by_upper' : {
                        '_id' : 'q63Kii9wwJX3Q6rHS',
                        'title' : 'Founder Part-up'
                    },
                    'comment' : '"Dit is een gefeaturede tribe"'
                },
                'language': 'nl'
            });
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/invites.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {
        if (!Invites.find().count()) {
            /*
            Invites.insert({
                '_id' : 'ztTLaXRyaPimwxdWh',
                'type' : 'activity_existing_upper',
                'activity_id' : 'BiiRy3t7qEjzvZYuE',
                'inviter_id' : 'K5c5M4Pbdg3B82wQH',
                'invitee_id' : 'a7qcp5RHnh5rfaeW9',
                'created_at' : new Date('2015-07-28T11:38:42.311Z')
            });
            */

            Invites.insert({
                '_id' : '92y9E2BTP7uA5WJuo',
                'type' : 'network_existing_upper',
                'network_id' : 'wfCv4ZdPe5WNT4xfg',
                'inviter_id' : 'q63Kii9wwJX3Q6rHS',
                'invitee_id' : 'a7qcp5RHnh5rfaeW9',
                'created_at' : new Date('2015-07-28T11:41:29.134Z')
            });
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/fixtures/images.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.startup(function() {
    if (process.env.NODE_ENV.match(/development|staging/)) {

        if (! AWS.config.accessKeyId || ! AWS.config.secretAccessKey || ! AWS.config.region) {
            return console.log('Image fixtures could not be loaded because the amazon s3 configuration has not been set, please check your environment variables.'.red);
        }

        var downloadAndSaveImage = function(imageId, url) {
            var result = HTTP.get(url, {'npmRequestOptions': {'encoding': null}});
            var body = new Buffer(result.content, 'binary');
            Partup.server.services.images.upload(imageId + '.jpg', body, 'image/jpeg', {id: imageId});
        };

        if (Images.find().count() === 27) {
            // Networks - Lifely (open)
            downloadAndSaveImage('raaNx9aqA6okiqaS4', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/7543891_300x300.jpg');
            downloadAndSaveImage('SEswZsYiTTKTTdnN5', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/icon152.png');

            // Networks - ING (public)
            downloadAndSaveImage('T8pfWebTJmvbBNJ2g', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/ing_logo.jpeg');
            downloadAndSaveImage('f7yzkqh9J9JvxCCqN', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/ing-no-text.jpg');

            // Networks - ING (invite)
            downloadAndSaveImage('efDuvuTzpqH65P9DF', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/ing_logo.jpeg');
            downloadAndSaveImage('fReGXG4qkNXb4K8wp', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/ing-no-text.jpg');

            // Networks - ING (closed)
            downloadAndSaveImage('PnYAg3EX5dKfEnkdn', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/ing_logo.jpeg');
            downloadAndSaveImage('4rymNTA3jFfTRKtFJ', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/ing-no-text.jpg');

            // Users - Default User
            downloadAndSaveImage('oQeqgwkdd44JSBSW5', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/normal_3810.png');

            // Users - John Partup
            downloadAndSaveImage('cHhjpWKo9DHjXQQjy', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/normal_6861.png');

            // Users - Judy Partup
            downloadAndSaveImage('bMTGT9oSDGzxCL3r4', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/normal_253.png');

            // Users - Admin User
            downloadAndSaveImage('CxEprGKNWo6HdrTdq', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/normal_511.png');

            // Partups - Crowd funding Part-up organiseren
            downloadAndSaveImage('FTHbg6wbPxjiA4Y8w', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/Premium.jpg');

            // Partups - Super secret closed ING partup
            downloadAndSaveImage('D3zGxajTjWCLhXokS', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/86-ing.jpg');

            // Partups - A semisecret ING partup, plus ones are ok
            downloadAndSaveImage('ComeF2exAjeKBPAf8', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/ing-wide-logo-wall.jpg');

            // Partups - Organise a Meteor Meetup
            downloadAndSaveImage('J2KxajXMcqiKwrEBu', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/687474703a2f2f636c2e6c792f59366a6e2f76656761732e706e672532303d32303078313032');

            // Partups - Partup Premium Part-up
            downloadAndSaveImage('xfYreAouRFh4mnctk', 'https://s3-eu-west-1.amazonaws.com/partup-dev-images/Premium.jpg');
        }

    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/activities.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Publish all activities in a partup
 *
 * @param {String} partupId
 * @param {String} accessToken
 */
Meteor.publishComposite('activities.from_partup', function(partupId, accessToken) {
    check(partupId, String);
    if (accessToken) check(accessToken, String);

    this.unblock();

    return {
        find: function() {
            var partup = Partups.guardedFind(this.userId, {_id: partupId}, {limit: 1}, accessToken).fetch().pop();
            if (!partup) return;

            return Activities.findForPartup(partup);
        },
        children: [
            {find: Updates.findForActivity},
            {find: Contributions.findForActivity, children: [
                {find: Meteor.users.findForContribution, children: [
                    {find: Images.findForUser}
                ]},
                {find: Ratings.findForContribution, children: [
                    {find: Meteor.users.findForRating, children: [
                        {find: Images.findForUser}
                    ]},
                ]}
            ]}
        ]
    };
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/partups.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Publish multiple partups for discover
 *
 * @param {Object} parameters
 * @param {string} parameters.networkId
 * @param {string} parameters.locationId
 * @param {string} parameters.sort
 * @param {string} parameters.textSearch
 * @param {number} parameters.limit
 * @param {number} parameters.skip
 * @param {string} parameters.language
 */
Meteor.routeComposite('/partups/discover', function(request, parameters) {
    check(parameters.query, {
        networkId: Match.Optional(String),
        locationId: Match.Optional(String),
        sort: Match.Optional(String),
        textSearch: Match.Optional(String),
        limit: Match.Optional(String),
        skip: Match.Optional(String),
        language: Match.Optional(String),
        userId: Match.Optional(String)
    });

    parameters = {
        networkId: parameters.query.networkId,
        locationId: parameters.query.locationId,
        sort: parameters.query.sort,
        textSearch: parameters.query.textSearch,
        limit: parameters.query.limit,
        skip: parameters.query.skip,
        language: (parameters.query.language === 'all') ? undefined : parameters.query.language
    };

    var options = {};

    if (parameters.limit) options.limit = parseInt(parameters.limit);
    if (parameters.skip) options.skip = parseInt(parameters.skip);

    return {
        find: function() {
            return Partups.findForDiscover(this.userId, options, parameters);
        },
        children: [
            {find: Images.findForPartup},
            {find: Meteor.users.findUppersForPartup, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) {
                if (!get(partup, 'featured.active')) return;
                return Meteor.users.findSinglePublicProfile(partup.featured.by_upper._id);
            }, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) { return Networks.findForPartup(partup, this.userId); }, children: [
                {find: Images.findForNetwork}
            ]}
        ]
    };
});

/**
 * Publish multiple partups by ids
 *
 * @param {[String]} partupIds
 */
Meteor.publishComposite('partups.by_ids', function(partupIds) {
    if (_.isString(partupIds)) partupIds = _.uniq(partupIds.split(','));

    check(partupIds, [String]);

    if (this.unblock) this.unblock();

    return {
        find: function() {
            return Partups.guardedFind(this.userId, {_id: {$in: partupIds}});
        },
        children: [
            {find: Images.findForPartup},
            {find: Meteor.users.findUppersForPartup, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) {
                if (!get(partup, 'featured.active')) return;
                return Meteor.users.findSinglePublicProfile(partup.featured.by_upper._id);
            }, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) { return Networks.findForPartup(partup, this.userId); }, children: [
                {find: Images.findForNetwork}
            ]}
        ]
    };
}, {url: 'partups/by_ids/:0'});

/**
 * Publish multiple partups by ids
 *
 * @param {[String]} networkSlug
 */
Meteor.publishComposite('partups.by_network_id', function(networkId, options) {
    check(networkId, String);

    var parameters = {};
    parameters.limit = options.limit || 10;

    if (this.unblock) this.unblock();

    return {
        find: function() {
            return Partups.guardedFind(this.userId, {network_id: networkId}, parameters);
        },
        children: [
            {find: Images.findForPartup},
            {find: Meteor.users.findUppersForPartup, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) {
                if (!get(partup, 'featured.active')) return;
                return Meteor.users.findSinglePublicProfile(partup.featured.by_upper._id);
            }, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) { return Networks.findForPartup(partup, this.userId); }, children: [
                {find: Images.findForNetwork}
            ]}
        ]
    };
});

/**
 * Publish a list of partups
 */
Meteor.publish('partups.list', function() {
    this.unblock();

    return Partups.guardedFind(this.userId, {}, {_id: 1, name: 1});
});

/**
 * Publish all featured partups (superadmins only)
 */
Meteor.publishComposite('partups.featured_all', function() {
    this.unblock();

    var user = Meteor.users.findOne(this.userId);
    if (!User(user).isAdmin()) return;

    return {
        find: function() {
            return Partups.find({'featured.active': true}, {featured: 1});
        },
        children: [
            {find: function(partup) {
                return Meteor.users.findSinglePublicProfile(partup.featured.by_upper._id);
            }, children: [
                {find: Images.findForUser}
            ]}
        ]
    };
});

/**
 * Publish a random featured partup
 */
Meteor.publishComposite('partups.featured_one_random', function(language) {
    if (this.unblock) this.unblock();

    return {
        find: function() {
            var selector = {'featured.active': true};

            if (language) selector.language = language;

            var count = Partups.guardedFind(this.userId, selector).count();
            var random = Math.floor(Math.random() * count);

            return Partups.guardedFind(this.userId, selector, {limit: 1, skip: random});
        },
        children: [
            {find: Images.findForPartup},
            {find: Meteor.users.findUppersForPartup, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) {
                if (!get(partup, 'featured.active')) return;
                return Meteor.users.findSinglePublicProfile(partup.featured.by_upper._id);
            }, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) { return Networks.findForPartup(partup, this.userId); }, children: [
                {find: Images.findForNetwork}
            ]}
        ]
    };
}, {url: 'partups/featured_one_random/:0'});

/**
 * Publish partups for the homepage
 */
Meteor.publishComposite('partups.home', function(language) {
    if (this.unblock) this.unblock();

    return {
        find: function() {
            return Partups.findForDiscover(this.userId, {limit: 4}, {sort: 'popular'});
        },
        children: [
            {find: Images.findForPartup},
            {find: Meteor.users.findUppersForPartup, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) {
                if (!get(partup, 'featured.active')) return;
                return Meteor.users.findSinglePublicProfile(partup.featured.by_upper._id);
            }, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) { return Networks.findForPartup(partup, this.userId); }, children: [
                {find: Images.findForNetwork}
            ]}
        ]
    };
}, {url: 'partups/home/:0'});

/**
 * Publish a single partup
 *
 * @param {String} partupId
 * @param {String} accessToken
 */
Meteor.publishComposite('partups.one', function(partupId, accessToken) {
    check(partupId, String);
    if (accessToken) check(accessToken, String);

    this.unblock();

    return {
        find: function() {
            return Partups.guardedMetaFind({_id: partupId}, {limit: 1});
        },
        children: [
            {
                find: function() {
                    return Partups.guardedFind(this.userId, {_id: partupId}, {limit: 1}, accessToken);
                },
                children: [
                    {find: Images.findForPartup},
                    {find: function(partup) { return Networks.findForPartup(partup, this.userId); }, children: [
                        {find: Images.findForNetwork}
                    ]},
                    {find: Meteor.users.findUppersForPartup, children: [
                        {find: Images.findForUser}
                    ]},
                    {find: Meteor.users.findSupportersForPartup, children: [
                        {find: Images.findForUser}
                    ]}
                ]
            }
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/images.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Publish an image
 *
 * @param {String} networkId
 */
Meteor.publish('images.one', function(imageId) {
    check(imageId, String);

    this.unblock();

    return Images.find({_id: imageId}, {limit: 1});
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/updates.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Children of an update
 */
var updateChildren = [
    {find: Meteor.users.findUserForUpdate, children: [
        {find: Images.findForUser}
    ]},
    {find: Images.findForUpdate},
    {find: Images.findForUpdateComments},
    {find: Activities.findForUpdate},
    {find: Contributions.findForUpdate, children: [
        {find: Activities.findForContribution},
        {find: Ratings.findForContribution, children: [
            {find: Meteor.users.findForRating, children: [
                {find: Images.findForUser}
            ]}
        ]}
    ]}
];

/**
 * Publish all required data for requested update
 *
 * @param {String} updateId
 */
Meteor.publishComposite('updates.one', function(updateId) {
    check(updateId, String);

    this.unblock();

    return {
        find: function() {
            var updateCursor = Updates.find({_id: updateId}, {limit: 1});

            var update = updateCursor.fetch().pop();
            if (!update) return;

            var partup = Partups.guardedFind(this.userId, {_id: update.partup_id}, {limit:1}).fetch().pop();
            if (!partup) return;

            return updateCursor;
        },
        children: updateChildren
    };
});

/**
 * Publish all required data for updates in a part-up
 *
 * @param {String} partupId
 * @param {Object} parameters
 * @param {Number} parameters.limit
 * @param {String} parameters.filter
 * @param {String} accessToken
 */
Meteor.publishComposite('updates.from_partup', function(partupId, parameters, accessToken) {
    check(partupId, String);
    if (accessToken) check(accessToken, String);

    parameters = parameters || {};
    check(parameters, {
        limit: Match.Optional(Number),
        filter: Match.Optional(String)
    });

    this.unblock();
    var self = this;

    return {
        find: function() {
            var partup = Partups.guardedFind(self.userId, {_id: partupId}, {limit:1}, accessToken).fetch().pop();
            if (!partup) return;

            return Updates.findForPartup(partup, parameters, self.userId);
        },
        children: updateChildren
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/users.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Publish a user
 *
 * @param {String} userId
 */
Meteor.publishComposite('users.one', function(userId) {
    check(userId, String);

    this.unblock();

    return {
        find: function() {
            return Meteor.users.findSinglePublicProfile(userId);
        },
        children: [
            {find: Images.findForUser}
        ]
    };
});

/**
 * Publish all partups a user is upper in
 *
 * @param {Object} request
 * @param {Object} params
 */
Meteor.routeComposite('/users/:id/upperpartups', function(request, params) {
    var options = {};

    if (request.query) {
        if (request.query.limit) options.limit = parseInt(request.query.limit);
        if (request.query.skip) options.skip = parseInt(request.query.skip);
        if (request.query.archived) options.archived = JSON.parse(request.query.archived);
    }

    return {
        find: function() {
            var user = Meteor.users.findOne(params.id);
            if (!user) return;

            return Partups.findUpperPartupsForUser(user, options, this.userId);
        },
        children: [
            {find: Images.findForPartup},
            {find: Meteor.users.findUppersForPartup, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) { return Networks.findForPartup(partup, this.userId); },
                children: [
                    {find: Images.findForNetwork}
                ]
            }
        ]
    };
});

/**
 * Publish all partups a user is supporter of
 *
 * @param {Object} request
 * @param {Object} params
 */
Meteor.routeComposite('/users/:id/supporterpartups', function(request, params) {
    var options = {};

    if (request.query) {
        if (request.query.limit) options.limit = parseInt(request.query.limit);
        if (request.query.skip) options.skip = parseInt(request.query.skip);
        if (request.query.archived) options.archived = JSON.parse(request.query.archived);
    }

    return {
        find: function() {
            var user = Meteor.users.findOne(params.id);
            if (!user) return;

            return Partups.findSupporterPartupsForUser(user, options, this.userId);
        },
        children: [
            {find: Images.findForPartup},
            {find: Meteor.users.findUppersForPartup, children: [
                {find: Images.findForUser}
            ]},
            {find: Meteor.users.findSupportersForPartup},
            {find: function(partup) { return Networks.findForPartup(partup, this.userId); },
            children: [
                {find: Images.findForNetwork}
            ]}
        ]
    };
});

/**
 * Publish all networks a user is in
 *
 * @param {Object} request
 * @param {Object} params
 */
Meteor.routeComposite('/users/:id/networks', function(request, params) {
    var options = {};

    if (request.query) {
        if (request.query.limit) options.limit = parseInt(request.query.limit);
        if (request.query.skip) options.skip = parseInt(request.query.skip);
    }

    return {
        find: function() {
            return Meteor.users.find(params.id, {fields: {networks: 1}});
        },
        children: [
            {
                find: function(user) {
                    return Networks.findForUser(user, this.userId, options);
                },
                children: [
                    {find: Images.findForNetwork}
                ]
            }
        ]
    };

});

/**
 * Publish all partners a user worked with
 *
 * @param {Object} request
 * @param {Object} params
 */
Meteor.routeComposite('/users/:id/partners', function(request, params) {
    var options = {};

    if (request.query) {
        if (request.query.limit) options.limit = parseInt(request.query.limit);
        if (request.query.skip) options.skip = parseInt(request.query.skip);
    }

    return {
        find: function() {
            var user = Meteor.users.findOne(params.id);
            if (!user) return;

            return Meteor.users.findPartnersForUpper(user);
        },
        children: [
            {find: Images.findForUser}
        ]
    };
});

/**
 * Publish the loggedin user
 */
Meteor.publishComposite('users.loggedin', function() {
    return {
        find: function() {
            if (this.userId) {
                return Meteor.users.findSinglePrivateProfile(this.userId);
            } else {
                this.ready();
            }
        },
        children: [
            {find: Images.findForUser}
        ]
    };
});

/**
 * Publish multiple users by ids
 *
 * @param {[String]} userIds
 */
Meteor.publishComposite('users.by_ids', function(userIds) {
    check(userIds, [String]);

    this.unblock();

    return {
        find: function() {
            return Meteor.users.findMultiplePublicProfiles(userIds);
        },
        children: [
            {find: Images.findForUser},
            {find: Invites.findForUser}
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/networks.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Publish a list of networks
 */
Meteor.publishComposite('networks.list', function() {
    this.unblock();

    return {
        find: function() {
            return Networks.guardedFind(this.userId);
        },
        children: [
            {find: Images.findForNetwork}
        ]
    };
});

/**
 * Publish a list of open-for-user-networks ordered by upper_count
 */
Meteor.publishComposite('networks.discoverfilter', function(urlParams, parameters, user) {
    if (this.unblock) this.unblock();

    var userId = user ? user._id : this.userId;

    return {
        find: function() {
            return Networks.findForDiscoverFilter(userId);
        },
        children: [
            {find: Images.findForNetwork}
        ]
    };
}, {url: 'networks-discoverfilter', getArgsFromRequest: function(request) {
    return [request.params, request.query, request.user];
}});

/**
 * Publish a network
 *
 * @param {String} networkSlug
 */
Meteor.publishComposite('networks.one', function(networkSlug) {
    check(networkSlug, String);

    if (this.unblock) this.unblock();

    return {
        find: function() {
            return Networks.guardedMetaFind({slug: networkSlug}, {limit: 1});
        },
        children: [
            {find: Images.findForNetwork},
            {find: Invites.findForNetwork},
            {
                find: function() {
                    return Networks.guardedFind(this.userId, {slug: networkSlug}, {limit: 1});
                }
            }
        ]
    };
});

/**
 * Publish all partups in a network
 *
 * @param {Object} urlParams
 * @param {Object} parameters
 */
Meteor.publishComposite('networks.one.partups', function(urlParams, parameters) {
    if (this.unblock) this.unblock();

    check(urlParams, {
        slug: Match.Optional(String)
    });

    parameters = parameters || {};
    if (parameters.limit) parameters.limit = parseInt(parameters.limit);
    if (parameters.skip) parameters.skip = parseInt(parameters.skip);

    check(parameters, {
        limit: Match.Optional(Number),
        skip: Match.Optional(Number),
        userId: Match.Optional(String),
        archived: Match.Optional(String),
        textSearch: Match.Optional(String)
    });

    var options = {};
    if (parameters.limit) options.limit = parameters.limit;
    if (parameters.skip) options.skip = parameters.skip;

    var selector = {
        archived: (parameters.archived) ? JSON.parse(parameters.archived) : false,
        textSearch: (parameters.textSearch) ? parameters.textSearch : undefined
    };

    return {
        find: function() {
            var network = Networks.guardedFind(this.userId, {slug: urlParams.slug}).fetch().pop();
            if (!network) return;

            return Partups.findForNetwork(network, selector, options, this.userId);
        },
        children: [
            {find: Images.findForPartup},
            {find: Meteor.users.findUppersForPartup, children: [
                {find: Images.findForUser}
            ]},
            {find: function(partup) {
                return Networks.findForPartup(partup, this.userId);
            },
            children: [
                {find: Images.findForNetwork}
            ]}
        ]
    };
}, {url: 'networks/:slug/partups', getArgsFromRequest: function(request) {
    return [request.params, request.query];
}});

/**
 * Publish all uppers in a network
 *
 * @param {Object} urlParams
 * @param {Object} parameters
 */
Meteor.publishComposite('networks.one.uppers', function(urlParams, parameters) {
    if (this.unblock) this.unblock();

    check(urlParams, {
        slug: Match.Optional(String)
    });

    parameters = parameters || {};
    if (parameters.limit) parameters.limit = parseInt(parameters.limit);
    if (parameters.skip) parameters.skip = parseInt(parameters.skip);

    check(parameters, {
        limit: Match.Optional(Number),
        skip: Match.Optional(Number),
        userId: Match.Optional(String),
        textSearch: Match.Optional(String)
    });

    var options = {};
    if (parameters.limit) options.limit = parameters.limit;
    if (parameters.skip) options.skip = parameters.skip;

    return {
        find: function() {
            var network = Networks.guardedFind(this.userId, {slug: urlParams.slug}).fetch().pop();
            if (!network) return;

            if (network.isNetworkAdmin(this.userId)) {
                parameters.isAdminOfNetwork = true;
            }

            return Meteor.users.findUppersForNetwork(network, options, parameters);
        },
        children: [
            {find: Images.findForUser}
        ]
    };
}, {url: 'networks/:slug/uppers', getArgsFromRequest: function(request) {
    return [request.params, request.query];
}});

/**
 * Publish all pending uppers in a network
 *
 * @param {String} networkSlug
 */
Meteor.publishComposite('networks.one.pending_uppers', function(networkSlug) {
    this.unblock();

    return {
        find: function() {
            var network = Networks.guardedFind(this.userId, {slug: networkSlug}).fetch().pop();
            if (!network) return;

            var pending_uppers = network.pending_uppers || [];
            var users = Meteor.users.findMultiplePublicProfiles(pending_uppers);

            return users;
        },
        children: [
            {find: Images.findForUser}
        ]
    };
});

/**
 * Publish the network chat
 *
 * @param {String} networkSlug
 */
Meteor.publishComposite('networks.one.chat', function(networkSlug, parameters) {
    // Temp disable
    return;

    if (this.unblock) this.unblock();

    check(networkSlug, String);

    parameters = parameters || {};
    if (parameters.limit) parameters.limit = parseInt(parameters.limit);
    if (parameters.skip) parameters.skip = parseInt(parameters.skip);

    check(parameters, {
        limit: Match.Optional(Number),
        skip: Match.Optional(Number)
    });

    var options = {};
    if (parameters.limit) options.limit = parameters.limit;
    if (parameters.skip) options.skip = parameters.skip;
    options.sort = {created_at: -1};

    return {
        find: function() {
            return Networks.guardedFind(this.userId, {slug: networkSlug}, {limit: 1});
        },
        children: [{
            find: function(network) {
                if (!network.chat_id) return;
                return Chats.find({_id: network.chat_id});
            },
            children: [{
                find: function(chat) {
                    return ChatMessages.find({chat_id: chat._id}, options);
                }
            }]
        },{
            find: function(network) {
                return Meteor.users.findUppersForNetwork(network, {}, {});
            },
            children: [{
                find: Images.findForUser
            }]
        }]
    };
});

/**
 * Publish all featured partups
 */
Meteor.publishComposite('networks.featured_all', function(language) {
    check(language, Match.Optional(String));

    if (this.unblock) this.unblock();

    return {
        find: function() {
            return Networks.findFeatured(language);
        },
        children: [
            {find: Images.findForNetwork},
            {find: function(network) {
                if (!get(network, 'featured.active')) return;
                return Meteor.users.findSinglePublicProfile(network.featured.by_upper._id);
            }, children: [
                {find: Images.findForUser}
            ]},
        ]
    };
}, {url: '/networks/featured/:0'});

/**
 * Publish all networks for admin panel
 */
Meteor.publishComposite('networks.admin_all', function() {
    this.unblock();

    var user = Meteor.users.findOne(this.userId);
    if (!User(user).isAdmin()) return;

    return {
        find: function() {
            return Networks.find({});
        },
        children: [
            {find: Images.findForNetwork},
            {find: function(network) {
                return Meteor.users.findMultiplePublicProfiles(network.admins);
            }, children: [
                {find: Images.findForUser}
            ]}
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/languages.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Publish all languages of partups
 *
 */
Meteor.publishComposite('languages.all', function() {
    return {
        find: function() {
            return Languages.find();
        }
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/tiles.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publishComposite('tiles.profile', function(upperId) {
    check(upperId, String);

    this.unblock();

    return {
        find: function() {
            return Tiles.find({upper_id: upperId});
        },
        children: [
            {find: Images.findForTile}
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/notifications.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publishComposite('notifications.for_upper', function(limit) {
    check(limit, Number);
    this.unblock();

    var user = Meteor.users.findOne(this.userId);
    if (!user) return;

    return {
        find: function() {
            return Notifications.findForUser(user, {}, {limit: limit});
        },
        children: [
            {find: Images.findForNotification}
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/swarms.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Publish a list of swarms
 */
Meteor.publishComposite('swarms.list', function() {
    this.unblock();

    return {
        find: function() {
            return Swarms.guardedFind(this.userId);
        },
        children: [
            {find: Images.findForSwarm}
        ]
    };
});

/**
 * Publish a swarm
 *
 * @param {String} swarmSlug
 */
Meteor.publishComposite('swarms.one', function(swarmSlug) {
    check(swarmSlug, String);

    if (this.unblock) this.unblock();

    return {
        find: function() {
            return Swarms.guardedMetaFind({slug: swarmSlug}, {limit: 1});
        },
        children: [
            {
                find: function(swarm) {
                    if (swarm.quotes.length > 0) {
                        var userIds = mout.array.map(swarm.quotes, function(quote) {
                            return quote.author._id;
                        });
                        return Meteor.users.findMultiplePublicProfiles(userIds);
                    }
                }, children: [
                    {find: Images.findForUser}
                ]
            },
            {find: Images.findForSwarm},
            {
                find: function() {
                    return Swarms.guardedFind(this.userId, {slug: swarmSlug}, {limit: 1});
                }
            }
        ]
    };
});

/**
 * Publish all tribes in a swarm
 *
 * @param {Object} urlParams
 * @param {Object} parameters
 */
Meteor.publishComposite('swarms.one.networks', function(swarmSlug, parameters) {
    check(swarmSlug, String);

    if (this.unblock) this.unblock();

    return {
        find: function() {
            return Swarms.guardedMetaFind({slug: swarmSlug}, {limit: 1});
        },
        children: [
            {find: function(swarm) {
                return Networks.guardedMetaFind({_id: {$in: swarm.networks}}, {limit: 25});
            }, children: [
                {find: Images.findForNetwork}
            ]}
        ]
    };
});

/**
 * Publish all swarms for admin panel
 */
Meteor.publishComposite('swarms.admin_all', function() {
    this.unblock();

    var user = Meteor.users.findOne(this.userId);
    if (!User(user).isAdmin()) return;

    return {
        find: function() {
            return Swarms.find({});
        },
        children: [
            {find: Images.findForSwarm},
            {find: function(swarm) {
                return Meteor.users.findSinglePublicProfile(swarm.admin_id);
            }, children: [
                {find: Images.findForUser}
            ]}
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/contentblocks.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publishComposite('contentblocks.by_network_slug', function(networkSlug) {
    check(networkSlug, String);

    this.unblock();

    return {
        find: function() {
            return Networks.guardedFind(this.userId, {slug: networkSlug}, {limit: 1});
        },
        children: [
            {
                find: function(network) {
                    return ContentBlocks.find({_id: {$in: network.contentblocks || []}});
                },
                children: [
                    {find: Images.findForContentBlock}
                ]
            }
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/publications/chats.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.publishComposite('chats.for_loggedin_user', function(options) {
    this.unblock();

    options = options || {};
    check(options, {
        limit: Match.Optional(Number),
        skip: Match.Optional(Number)
    });

    return {
        find: function() {
            return Meteor.users.find(this.userId, {fields: {chats: 1}});
        },
        children: [
            {
                find: function(user) {
                    return Chats.findForUser(user._id, options);
                },
                children: [
                    {
                        find: function(chat) {
                            return Meteor.users.findMultiplePublicProfiles([], {}, {hackyReplaceSelectorWithChatId: chat._id});
                        },
                        children: [
                            {find: Images.findForUser}
                        ]
                    },
                    {find: function(chat) {
                        return ChatMessages.find({chat_id: chat._id}, {sort: {created_at: -1}, limit: 1});
                    }}
                ]
            }
        ]
    };
});

Meteor.publishComposite('chats.by_id', function(chatId, chatMessagesOptions) {
    this.unblock();
    check(chatId, String);
    chatMessagesOptions = chatMessagesOptions || {};
    check(chatMessagesOptions, {
        limit: Match.Optional(Number),
        skip: Match.Optional(Number)
    });

    return {
        find: function() {
            return Meteor.users.find({_id: this.userId});
        },
        children: [
            {
                find: function(user) {
                    if (user.chats.indexOf(chatId) === -1) return;
                    return Chats.findForUser(this.userId);
                },
                children: [
                    {
                        find: function(chat) {
                            return Meteor.users.findMultiplePublicProfiles([], {}, {hackyReplaceSelectorWithChatId: chat._id});
                        },
                        children: [
                            {find: Images.findForUser}
                        ]
                    },
                    {
                        find: function(chat) {
                            chatMessagesOptions.sort = {created_at: -1};
                            return ChatMessages.find({chat_id: chat._id}, chatMessagesOptions);
                        }
                    }
                ]
            }
        ]
    };
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/routes/hooks.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var respondWithError = function(response, statusCode, reason) {
    response.statusCode = statusCode;
    response.end(JSON.stringify({error: {reason: reason}}));
};

/**
 * Find the user and set it on the request
 */
Router.onBeforeAction(function(request, response, next) {
    var token = request.query.token;

    if (token) {
        var user = Meteor.users.findOne({
            $or: [
                {'services.resume.loginTokens.hashedToken': Accounts._hashLoginToken(token)},
                {'services.resume.loginTokens.token': token}
            ]
        });

        if (user) request.user = user;
    }

    next();
}, {where: 'server'});

/**
 * Require authentication for certain server-side routes
 */
Router.onBeforeAction(function(request, response, next) {
    if (!request.user) return respondWithError(response, 401, 'error-http-unauthorized');

    next();
}, {where: 'server', except: [
    'ping',
    'partups.discover',
    'partups.discover.count',
    'networks.:slug.partups.count',
    'networks.:slug.uppers.count',
    'users.count',
    'users.:id.upperpartups.count',
    'users.:id.supporterpartups.count',
    'users.:id.upperpartups',
    'users.:id.supporterpartups',
    'users.:id.networks',
    'users.:id.partners',
    'users.:id.partners.count',
]});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/routes/middleware.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// Disable all default response headers (we want to control them manually)
JsonRoutes.setResponseHeaders({});

// Enable caching for a couple of different endpoints
JsonRoutes.Middleware.use(function(request, response, next) {
    var urlRegexesToCache = [
        /\/networks\/[a-zA-Z0-9-]+$/, // /networks/lifely-open
        /\/networks\/featured\/[a-zA-Z]+$/, // /networks/featured/en
        /\/partups\/by_ids\/[a-zA-Z0-9,]+$/, // /partups/by_ids/vGaxNojSerdizDPjb
        /\/partups\/discover??((?!userId).)*$/, // /partups/discover?query (only if userId is not present)
        /\/partups\/discover\/count??((?!userId).)*$/, // /partups/discover/count?query (only if userId is not present)
        /\/partups\/home\/[a-zA-Z]+$/, // /partups/home/en
        /\/partups\/featured_one_random\/[a-zA-Z]+$/, // /partups/featured_one_random/en
        /\/users\/count$/, // /users/count
    ];

    var shouldCache = false;

    urlRegexesToCache.forEach(function(regex) {
        if (regex.test(request.url)) shouldCache = true;
    });

    response.setHeader('Cache-Control', shouldCache ? 'public, max-age=3600' : 'no-store, max-age=0');

    next();
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/routes/csv/csv_routes.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var path = Npm.require('path');
var Busboy = Npm.require('busboy');

var MAX_FILE_SIZE = 1000 * 1000 * 10; // 10 MB

Router.route('/csv/parse', {where: 'server'}).post(function() {
    var request = this.request;
    var response = this.response;

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    var busboy = new Busboy({'headers': request.headers});

    busboy.on('file', Meteor.bindEnvironment(function(fieldname, file, filename, encoding, mimetype) {
        var extension = path.extname(filename);

        if (!(/\.(csv)$/i).test(extension)) {
            response.statusCode = 400;
            // TODO: Improve error message (i18n)
            response.end(JSON.stringify({error: {reason: 'error-csvupload-invalidcsv'}}));
            return;
        }

        var baseFilename = path.basename(filename, extension);

        var size = 0;
        var buffers = [];

        file.on('data', Meteor.bindEnvironment(function(data) {
            size += data.length;
            buffers.push(new Buffer(data));
        }));

        file.on('end', Meteor.bindEnvironment(function() {
            if (size > MAX_FILE_SIZE) {
                response.statusCode = 400;
                // TODO: Improve error message (i18n)
                response.end(JSON.stringify({error: {reason: 'error-csvupload-toolarge'}}));
                return;
            }

            var body = Buffer.concat(buffers);

            CSV()
                .from.string(body, {
                        delimiter: ';', // Set the field delimiter. One character only, defaults to comma.
                        skip_empty_lines: true, // Don't generate empty values for empty lines.
                        trim: true // Ignore whitespace immediately around the delimiter.
                    })
                .to.array(Meteor.bindEnvironment(function(array) {
                    var list = lodash.chain(array)
                        .map(function(row) {
                            if (!Partup.services.validators.email.test(row[1])) return false;

                            return {
                                name: row[0],
                                email: row[1]
                            };
                        })
                        .compact()
                        .uniq(function(row) {
                            return row.email;
                        })
                        .value();

                    // Limit to 200 email addresses
                    if (list.length > 200) {
                        response.statusCode = 400;
                        // TODO: Improve error message (i18n)
                        response.end(JSON.stringify({error: {reason: 'error-csvupload-toolarge'}}));
                        return;
                    }

                    response.end(JSON.stringify({error: false, result: list}));
                }))
                .on('error', function(error) {
                    response.statusCode = 400;
                    // TODO: Improve error message (i18n)
                    response.end(JSON.stringify({error: {reason: 'error-csvupload-invalidcsv'}}));
                    return;
                });
        }));
    }));

    request.pipe(busboy);
});

Router.route('/csv/admin/users', {where: 'server'}).get(function() {
    var request = this.request;
    var response = this.response;

    if(!request.user) {
        response.statusCode = 403;
        response.end(JSON.stringify({error: {reason: 'error-unauthorized'}}));
        return;
    }

    if(!User(request.user).isAdmin()) {
        response.statusCode = 403;
        response.end(JSON.stringify({error: {reason: 'error-unauthorized'}}));
        return;
    }
    response.setHeader('Content-disposition', 'attachment; filename=userdump.csv');
    response.setHeader('Content-type', 'text/csv');

    return exportCSV(response);
});

Router.route('/csv/tribe/uppers', {where: 'server'}).get(function() {
    var request = this.request;
    var response = this.response;

    if (!request.query.id || !request.user) {
        response.statusCode = 403;
        response.end(JSON.stringify({error: {reason: 'error-unauthorized'}}));
        return;
    }

    var network = Networks.findOneOrFail(request.query.id);
    if (!network.isAdmin(request.user._id)) {
        response.statusCode = 403;
        response.end(JSON.stringify({error: {reason: 'error-unauthorized'}}));
        return;
    }

    response.setHeader('Content-disposition', 'attachment; filename=tribe-uppers.csv');
    response.setHeader('Content-type', 'text/csv');

    return exportCSV(response, network.uppers, true);
});

var exportCSV = function(responseStream, userIds, ignoreDeactivatedUsers) {
    userIds = userIds || [];
    var userStream = createStream();
    var Future = Npm.require('fibers/future');
    var fut = new Future();
    var users = {};
    var userSelector = userIds.length > 0 ? {_id: {$in: userIds}} : {};

    if (ignoreDeactivatedUsers) {
        userSelector.deactivatedAt = {$exists: false};
    };

    CSV()
        .from(userStream)
        .to(responseStream, {delimiter:';'})
        .on('error', function(error){
            console.error('Error streaming CSV export: ', error.message);
        })
        .on('end', function(count){
            responseStream.end();
            fut.return();
        });
    if (ignoreDeactivatedUsers) {
        userStream.write(['user id','name','phonenumber','e-mail','member since']);
    } else {
        userStream.write(['_id','profile.name','profile.phonenumber','registered_emails','createdAt','deactivatedAt']);
    }
    users = Meteor.users.findForAdminList(userSelector, {}).fetch();

    var count = 0;
    users.forEach(function(user) {
        var objectUser = User(user);
        var createdAt = user.createdAt ? moment(new Date(user.createdAt)).format('DD-MM-YYYY') : undefined;
        if (ignoreDeactivatedUsers) {
            userStream.write([
                user._id,
                user.profile.name,
                user.profile.phonenumber,
                objectUser.getEmail(),
                createdAt
            ]);
        } else {
            var deactivatedAt = user.deactivatedAt ? moment(new Date(user.deactivatedAt)).format('DD-MM-YYYY') : undefined;
            userStream.write([
                user._id,
                user.profile.name,
                user.profile.phonenumber,
                objectUser.getEmail(),
                createdAt,
                deactivatedAt
            ]);
        }
        count++;
        if (count >= users.length) {
            userStream.end()
        }
    });

    return fut.wait();
};

//Creates and returns a Duplex(Read/Write) Node stream
//Used to pipe users from .find() Cursor into our CSV stream parser.
var createStream = function(){
    var stream = Npm.require('stream');
    var myStream = new stream.Stream();
    myStream.readable = true;
    myStream.writable = true;

    myStream.write = function (data) {
        myStream.emit('data', data);
        return true; // true means 'yes i am ready for more data now'
        // OR return false and emit('drain') when ready later
    };

    myStream.end = function (data) {
        //Node convention to emit last data with end
        if (arguments.length)
            myStream.write(data);

        // no more writes after end
        myStream.writable = false;
        myStream.emit('end');
    };

    myStream.destroy = function () {
        myStream.writable = false;
    };

    return myStream;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/routes/images/images_routes.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var path = Npm.require('path');
var Busboy = Npm.require('busboy');

AWS.config.accessKeyId = process.env.AWS_ACCESS_KEY_ID;
AWS.config.secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
AWS.config.region = process.env.AWS_BUCKET_REGION;

var MAX_FILE_SIZE = 1000 * 1000 * 10; // 10 MB

Router.route('/images/upload', {where: 'server'}).post(function() {
    var request = this.request;
    var response = this.response;
    // console.log(request)

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    var busboy = new Busboy({'headers': request.headers});

    busboy.on('file', Meteor.bindEnvironment(function(fieldname, file, filename, encoding, mimetype) {
        var extension = path.extname(filename);
        var imageExtension = (/\.(jpg|jpeg|png)$/i).test(extension);
        var imageMimetype = (/\/(jpg|jpeg|png)$/i).test(mimetype);

        if (!imageExtension && imageMimetype) {
            filename = filename + '.jpg';
        }

        // Validate that the file is a valid image
        if (!imageExtension && !imageMimetype) {
            response.statusCode = 400;
            // TODO: Improve error message (i18n)
            response.end(JSON.stringify({error: {reason:'error-imageupload-invalidimage'}}));
            return;
        }
        var size = 0;
        var buffers = [];

        file.on('data', Meteor.bindEnvironment(function(data) {
            size += data.length;
            buffers.push(new Buffer(data));
        }));

        file.on('end', Meteor.bindEnvironment(function() {
            if (size > MAX_FILE_SIZE) {
                response.statusCode = 400;
                // TODO: Improve error message (i18n)
                response.end(JSON.stringify({error: {reason: 'error-imageupload-toolarge'}}));
                return;
            }
            var body = Buffer.concat(buffers);
            var image = Partup.server.services.images.upload(filename, body, mimetype);

            return response.end(JSON.stringify({error: false, image: image._id}));
        }));
    }));

    request.pipe(busboy);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/routes/partups/partups_routes.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*
 * Count route for /partups/discover
 */
Router.route('/partups/discover/count', {where: 'server'}).get(function() {
    var request = this.request;
    var response = this.response;

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    var parameters = {
        networkId: request.query.networkId,
        locationId: request.query.locationId,
        sort: request.query.sort,
        textSearch: request.query.textSearch,
        limit: request.query.limit,
        skip: request.query.skip,
        language: (request.query.language === 'all') ? undefined : request.query.language
    };

    var userId = request.user ? request.user._id : null;
    var partups = Partups.findForDiscover(userId, {}, parameters);

    return response.end(JSON.stringify({error: false, count: partups.count()}));
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/routes/networks/networks_routes.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*
 * Count route for /networks/:0/partups
 */
Router.route('/networks/:slug/partups/count', {where: 'server'}).get(function() {
    var request = this.request;
    var response = this.response;
    var params = this.params;

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    var options = {
        limit: request.query.limit || 0,
        skip: request.query.skip
    };

    var userId = request.user ? request.user._id : null;

    var parameters = {
        archived: (request.query.archived) ? JSON.parse(request.query.archived) : false
    };

    var network = Networks.guardedFind(userId, {slug: params.slug}).fetch().pop();
    if (!network) {
        response.statusCode = 404;
        return response.end(JSON.stringify({error: {reason: 'error-network-notfound'}}));
    }

    var partups = Partups.findForNetwork(network, parameters, options, userId);

    return response.end(JSON.stringify({error: false, count: partups.count()}));
});

/*
 * Count route for /networks/:0/uppers
 */
Router.route('/networks/:slug/uppers/count', {where: 'server'}).get(function() {
    var request = this.request;
    var response = this.response;
    var params = this.params;

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    var userId = request.user ? request.user._id : null;

    var network = Networks.guardedFind(userId, {slug: params.slug}, {}).fetch().pop();
    if (!network) {
        response.statusCode = 404;
        response.end(JSON.stringify({error: {reason: 'error-network-notfound'}}));
    }

    var uppers = Meteor.users.findMultiplePublicProfiles(network.uppers, {}, {
        count: true
    });

    return response.end(JSON.stringify({error: false, count: uppers.count()}));
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/routes/users/users_routes.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*
 * Count route for /users
 */
Router.route('/users/count', {where: 'server'}).get(function() {
    var request = this.request;
    var response = this.response;

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    return response.end(JSON.stringify({error: false, count: Meteor.users.find().count()}));
});

/*
 * Count route for /users/:id/upperpartups
 */
Router.route('/users/:id/upperpartups/count', {where: 'server'}).get(function() {
    var request = this.request;
    var response = this.response;
    var params = this.params;

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    var parameters = {
        limit: request.query.limit,
        skip: request.query.skip,
        archived: request.query.archived || false
    };

    parameters.archived = (request.query.archived) ? JSON.parse(request.query.archived) : false;

    var userId = request.user ? request.user._id : null;

    var user = Meteor.users.findOne(params.id);
    if (!user) {
        response.statusCode = 404;
        return response.end(JSON.stringify({error: {reason: 'error-user-notfound'}}));
    }

    var partups = Partups.findUpperPartupsForUser(user, parameters, userId);

    return response.end(JSON.stringify({error: false, count: partups.count()}));
});

/*
 * Count route for /users/:id/supporterpartups
 */
Router.route('/users/:id/supporterpartups/count', {where: 'server'}).get(function() {
    var request = this.request;
    var response = this.response;
    var params = this.params;

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    var parameters = {
        limit: request.query.limit,
        skip: request.query.skip,
        archived: request.query.archived || false
    };

    parameters.archived = (request.query.archived) ? JSON.parse(request.query.archived) : false;

    var userId = request.user ? request.user._id : null;

    var user = Meteor.users.findOne(params.id);
    if (!user) {
        response.statusCode = 404;
        return response.end(JSON.stringify({error: {reason: 'error-user-notfound'}}));
    }

    var partups = Partups.findSupporterPartupsForUser(user, parameters, userId);

    return response.end(JSON.stringify({error: false, count: partups.count()}));
});

/*
 * Count route for /users/:id/partners
 */
Router.route('/users/:id/partners/count', {where: 'server'}).get(function() {
    var response = this.response;
    var params = this.params;

    // We are going to respond in JSON format
    response.setHeader('Content-Type', 'application/json');

    var user = Meteor.users.findOne(params.id);
    if (!user) {
        response.statusCode = 404;
        return response.end(JSON.stringify({error: {reason: 'error-user-notfound'}}));
    }

    var partners = Meteor.users.findPartnersForUpper(user);

    return response.end(JSON.stringify({error: false, count: partners.count()}));
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/updates/updates_comments_methods.js                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert a Comment on an Update
     *
     * @param {string} updateId
     * @param {mixed[]} fields
     */
    'updates.comments.insert': function(updateId, fields) {
        check(updateId, String);
        check(fields, Partup.schemas.forms.updateComment);

        this.unblock();

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        var update = Updates.findOneOrFail(updateId);

        if (!!update.system) throw new Meteor.Error(403, 'comment_is_not_allowed_on_a_system_update');

        var comment = {
            _id: Random.id(),
            content: fields.content,
            type: fields.type,
            creator: {
                _id: upper._id,
                name: upper.profile.name,
                image: upper.profile.image
            },
            created_at: new Date(),
            updated_at: new Date()
        };

        check(comment, Partup.schemas.entities.updateComment);

        var comments = update.comments || [];

        try {
            // Check if the comment is made on an activity or contribution to change update title,
            // or leave it as it is. Also leave the upper_id to the original user if it's not
            var updateFields = {
                updated_at: new Date(),
                type: update.type
            };

            if (update.type_data.activity_id && update.type_data.contribution_id) {
                updateFields.type = 'partups_contributions_comments_added';
                updateFields.upper_id = upper._id;
            } else if (update.type_data.activity_id) {
                updateFields.type = 'partups_activities_comments_added';
                updateFields.upper_id = upper._id;
            }

            Updates.update(updateId, {
                $set: updateFields,
                $push: {
                    comments: comment
                },
                $inc: {
                    comments_count: 1
                }
            });

            // Make user Supporter if its not yet an Upper or Supporter of the Partup
            var partup = Partups.findOneOrFail(update.partup_id);
            if (!partup.hasUpper(upper._id) && !partup.hasSupporter(upper._id)) {
                partup.makeSupporter(upper._id);

                Event.emit('partups.supporters.inserted', partup, upper);
            }

            // Update the new update status for all uppers
            partup.addNewUpdateToUpperData(update, Meteor.userId());

            Event.emit('updates.comments.inserted', upper, partup, update, comment);
            var mentionsWarning = Partup.helpers.mentions.exceedsLimit(fields.content);
            return {
                _id: comment._id,
                warning: mentionsWarning || undefined
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'comment_could_not_be_inserted');
        }
    },

    /**
     * Edit a comment
     *
     * @param {string} updateId
     * @param {string} commentId
     * @param {mixed[]} fields
     */
    'updates.comments.update': function(updateId, commentId, fields) {
        check(updateId, String);
        check(commentId, String);
        check(fields, Partup.schemas.forms.updateComment);

        this.unblock();

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        try {
            var comment = Updates.findOne({
                _id: updateId,
                'comments._id': commentId,
                'comments.creator._id': upper._id
            });
            if (comment) {
                Updates.update({_id: updateId, 'comments._id': commentId}, {
                    $set: {
                        'comments.$.content': fields.content,
                        'comments.$.updated_at': new Date()
                    }
                });
            }
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_comment_could_not_be_updated');
        }
    },

    /**
     * Remove a comment
     *
     * @param {string} updateId
     * @param {string} commentId
     */
    'updates.comments.remove': function(updateId, commentId) {
        check(updateId, String);
        check(commentId, String);

        this.unblock();

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        try {
            var update = Updates.findOne({_id: updateId, 'comments._id': commentId, 'comments.creator._id': upper._id});
            if (update) {
                Updates.update({
                    _id: updateId, 'comments._id': commentId
                }, {
                    $pull: {comments: {_id: commentId}},
                    $inc: {comments_count: -1}
                });
            }
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_comment_could_not_be_removed');
        }
    },

    /**
     * Reset new comments
     *
     * @param {String} updateId
     */
    'updates.reset_new_comments': function(updateId) {
        check(updateId, String);

        try {
            var update = Updates.findOne({_id: updateId, 'upper_data._id': Meteor.userId()});
            if (update && update._id) {
                Updates.update({
                    _id: updateId,
                    'upper_data._id': Meteor.userId()
                }, {$set: {'upper_data.$.new_comments': []}});
            }
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_new_comments_could_not_be_reset');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/updates/updates_messages_methods.js                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert a Message
     *
     * @param {string} partupId
     * @param {mixed[]} fields
     */
    'updates.messages.insert': function(partupId, fields) {
        check(partupId, String);
        check(fields, Partup.schemas.forms.newMessage);

        this.unblock();

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        var partup = Partups.findOneOrFail(partupId);
        var newMessage = Partup.transformers.update.fromFormNewMessage(fields, upper, partup._id);
        newMessage.type = 'partups_message_added';

        try {
            newMessage._id = Updates.insert(newMessage);

            // Make user Supporter if it's not yet an Upper or Supporter of the Partup
            if (!partup.hasUpper(upper._id) && !partup.hasSupporter(upper._id)) {
                partup.makeSupporter(upper._id);

                Event.emit('partups.supporters.inserted', partup, upper);
            }

            Event.emit('partups.messages.insert', upper, partup, newMessage, fields.text);
            var mentionsWarning = Partup.helpers.mentions.exceedsLimit(fields.text);
            return {
                _id: newMessage._id,
                warning: mentionsWarning || undefined
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'message_could_not_be_inserted');
        }
    },

    /**
     * Update a Message
     *
     * @param {string} updateId
     * @param {mixed[]} fields
     */
    'updates.messages.update': function(updateId, fields) {
        check(updateId, String);
        check(fields, Partup.schemas.forms.newMessage);

        this.unblock();

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        try {
            var message = Updates.findOne({_id: updateId, upper_id: upper._id});
            if (message) {
                Updates.update({_id: message._id}, {$set: {
                    type_data: {
                        old_value: message.type_data.new_value,
                        new_value: fields.text,
                        images: fields.images,
                        documents: fields.documents
                    },
                    updated_at: new Date()
                }});
            }
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_message_could_not_be_updated');
        }
    },

    /**
     * Remove a message
     *
     * @param {string} messageId
     */
    'updates.messages.remove': function(messageId) {
        check(messageId, String);

        this.unblock();

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        try {
            var message = Updates.findOne({_id: messageId, upper_id: upper._id});
            if (message) {
                // Don't remove when message has comments
                if (message.comments && message.comments.length > 0) throw new Meteor.Error(400, 'partup_message_already_has_comments');

                Updates.remove({_id: message._id});
            }
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_message_could_not_be_removed');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/activities/activities_methods.js                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert an Activity
     *
     * @param {string} partupId
     * @param {mixed[]} fields
     */
    'activities.insert': function(partupId, fields) {
        check(partupId, String);
        check(fields, Partup.schemas.forms.startActivities);
        var upper = Meteor.user();
        var partup = Partups.findOneOrFail({_id: partupId});

        if (!upper || !partup.hasUpper(upper._id)) throw new Meteor.Error(401, 'unauthorized');

        try {
            var activity = Partup.transformers.activity.fromForm(fields, upper._id, partupId);

            activity._id = Activities.insert(activity);

            // Update the activity count of the Partup
            Partups.update(partupId, {
                $inc: {
                    activity_count: 1
                }
            });

            return {
                _id: activity._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'activity_could_not_be_inserted');
        }
    },

    /**
     * Update an Activity
     *
     * @param {string} activityId
     * @param {mixed[]} fields
     */
    'activities.update': function(activityId, fields) {
        check(activityId, String);
        check(fields, Partup.schemas.forms.startActivities);
        var upper = Meteor.user();
        var activity = Activities.findOneOrFail(activityId);

        if (activity.isRemoved()) throw new Meteor.Error(404, 'activity_could_not_be_found');

        var partup = Partups.findOneOrFail(activity.partup_id);

        if (!upper || !partup.hasUpper(upper._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var updatedActivity = Partup.transformers.activity.fromForm(fields, activity.creator_id, activity.partup_id);
            updatedActivity.updated_at = new Date();

            Activities.update(activityId, {$set: updatedActivity});

            // Post system message
            Partup.server.services.system_messages.send(upper, activity.update_id, 'system_activities_updated');

            return {
                _id: activity._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'activity_could_not_be_updated');
        }
    },

    /**
     * Remove an Activity
     *
     * @param {string} activityId
     */
    'activities.remove': function(activityId) {
        check(activityId, String);

        var upper = Meteor.user();
        var activity = Activities.findOneOrFail(activityId);

        if (activity.isRemoved()) throw new Meteor.Error(404, 'activity_could_not_be_found');

        var partup = Partups.findOneOrFail({_id: activity.partup_id});

        if (!upper || !partup.hasUpper(upper._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            activity.remove();

            // Post system message
            Partup.server.services.system_messages.send(upper, activity.update_id, 'system_activities_removed');

            return {
                _id: activity._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'activity_could_not_be_removed');
        }
    },

    /**
     * Unarchive an Activity
     *
     * @param  {string} activityId
     */
    'activities.unarchive': function(activityId) {
        check(activityId, String);

        var upper = Meteor.user();
        var activity = Activities.findOneOrFail(activityId);

        if (activity.isRemoved()) throw new Meteor.Error(404, 'activity_could_not_be_found');

        var partup = Partups.findOneOrFail({_id: activity.partup_id});

        if (!upper || !partup.hasUpper(upper._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            Activities.update(activityId, {$set: {archived: false}});
            Partups.update(partup._id, {$inc: {activity_count: 1}});

            // Post system message
            Partup.server.services.system_messages.send(upper, activity.update_id, 'system_activities_unarchived');

            Event.emit('partups.activities.unarchived', upper._id, activity);

            return {
                _id: activity._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'activity_could_not_be_unarchived');
        }
    },

    /**
     * Archive an Activity
     *
     * @param  {string} activityId
     */
    'activities.archive': function(activityId) {
        check(activityId, String);

        var upper = Meteor.user();
        var activity = Activities.findOneOrFail(activityId);

        if (activity.isRemoved()) throw new Meteor.Error(404, 'activity_could_not_be_found');

        var partup = Partups.findOneOrFail({_id: activity.partup_id});

        if (!upper || !partup.hasUpper(upper._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            Activities.update(activityId, {$set: {archived: true}});
            Partups.update(partup._id, {$inc: {activity_count: -1}});

            // Post system message
            Partup.server.services.system_messages.send(upper, activity.update_id, 'system_activities_archived');

            Event.emit('partups.activities.archived', upper._id, activity);

            return {
                _id: activity._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'activity_could_not_be_archived');
        }
    },

    /**
     * Copy activities from one Partup to another
     *
     * @param  {String} fromPartupId
     * @param  {String} toPartupId
     */
    'activities.copy': function(fromPartupId, toPartupId) {
        check(fromPartupId, String);
        check(toPartupId, String);

        var upper = Meteor.user();
        if (!upper) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        // Check if both Partup IDs are valid
        Partups.findOneOrFail(fromPartupId);
        Partups.findOneOrFail(toPartupId);

        try {
            var existingActivities = Activities.find({partup_id: fromPartupId}).fetch();
            existingActivities.forEach(function(activity) {
                var newActivity = {
                    name: activity.name,
                    description: activity.description,
                    end_date: activity.end_date,
                    created_at: new Date(),
                    updated_at: new Date(),
                    creator_id: upper._id,
                    partup_id: toPartupId,
                    archived: false
                };

                Activities.insert(newActivity);
            });

            // Add number of activities to the Part-up's activity_count
            var activityCount = existingActivities.length;
            Partups.update(toPartupId, {$inc: {activity_count: activityCount}});

            return true;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'activities_could_not_be_copied_from_partup');
        }
    },

    /**
     * Get user suggestions for a given activity
     *
     * @param {string} activityId
     * @param {Object} options
     * @param {string} options.query
     * @param {Number} options.limit
     * @param {Number} options.skip
     *
     * @return {[string]}
     */
    'activities.user_suggestions': function(activityId, options) {
        check(activityId, String);
        check(options, {
            query: Match.Optional(String),
            limit: Match.Optional(Number),
            skip: Match.Optional(Number)
        });

        this.unblock();

        var upper = Meteor.user();

        if (!upper) {
            throw new Meteor.Error(401, 'Unauthorized');
        }

        var users = Partup.server.services.matching.matchUppersForActivity(activityId, options);

        // We are returning an array of IDs instead of an object
        return users.map(function(user) {
            return user._id;
        });
    },

    /**
     * Invite someone to an activity
     *
     * @param {string} activityId
     * @param {Object} fields
     * @param {[Object]} fields.invitees
     * @param {String} fields.invitees.name
     * @param {String} fields.invitees.email
     * @param {String} fields.message
     */
    'activities.invite_by_email': function(activityId, fields) {
        check(activityId, String);
        check(fields, Partup.schemas.forms.inviteUpper);

        var inviter = Meteor.user();

        if (!inviter) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var activity = Activities.findOneOrFail(activityId);

        if (activity.isRemoved()) throw new Meteor.Error(404, 'activity_could_not_be_found');

        var partup = Partups.findOneOrFail(activity.partup_id);

        var isAllowedToAccessPartup = !!Partups.guardedFind(inviter._id, {_id: activity.partup_id}).count() > 0;
        if (!isAllowedToAccessPartup) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var invitees = fields.invitees || [];

        invitees.forEach(function(invitee) {
            var isAlreadyInvited = !!Invites.findOne({
                activity_id: activityId,
                invitee_email: invitee.email,
                type: Invites.INVITE_TYPE_ACTIVITY_EMAIL
            });

            if (isAlreadyInvited) {
                //@TODO How to handle this scenario? Because now, we just skip to the next invitee
                //throw new Meteor.Error(403, 'email_is_already_invited_to_network');
                return;
            }

            var accessToken = Random.secret();

            var invite = {
                type: Invites.INVITE_TYPE_ACTIVITY_EMAIL,
                activity_id: activity._id,
                inviter_id: inviter._id,
                invitee_name: invitee.name,
                invitee_email: invitee.email,
                message: fields.message,
                access_token: accessToken,
                created_at: new Date
            };

            Invites.insert(invite);

            Event.emit('invites.inserted.activity.by_email', inviter, partup, activity, invitee.email, invitee.name, fields.message, accessToken);
        });
    },

    /**
     * Invite an existing upper to an activity
     *
     * @param {string} activityId
     * @param {string} inviteeId
     * @param {string} searchQuery
     */
    'activities.invite_existing_upper': function(activityId, inviteeId, searchQuery) {
        check(activityId, String);
        check(inviteeId, String);
        check(searchQuery, Match.Optional(String));

        var inviter = Meteor.user();
        if (!inviter) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var activity = Activities.findOneOrFail(activityId);

        if (activity.isRemoved()) throw new Meteor.Error(404, 'activity_could_not_be_found');

        var invitee = Meteor.users.findOneOrFail(inviteeId);

        var isAllowedToAccessPartup = !!Partups.guardedFind(inviter._id, {_id: activity.partup_id}).count() > 0;
        if (!isAllowedToAccessPartup) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var isAlreadyInvited = !!Invites.findOne({
            activity_id: activityId,
            invitee_id: invitee._id,
            inviter_id: inviter._id,
            type: Invites.INVITE_TYPE_ACTIVITY_EXISTING_UPPER
        });
        if (isAlreadyInvited) {
            throw new Meteor.Error(403, 'user_is_already_invited_to_activity');
        }

        var invite = {
            type: Invites.INVITE_TYPE_ACTIVITY_EXISTING_UPPER,
            activity_id: activity._id,
            inviter_id: inviter._id,
            invitee_id: invitee._id,
            created_at: new Date
        };

        Invites.insert(invite);

        // Add to the invite list of the partup
        var partup = Partups.findOneOrFail(activity.partup_id);
        if (!partup.hasInvitedUpper(invitee._id)) {
            Partups.update(partup._id, {$addToSet: {invites: invitee._id}});
        }

        Event.emit('invites.inserted.activity', inviter, partup, activity, invitee, searchQuery);
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/contributions/contributions_methods.js                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Add current user contribution to activity
     *
     * @param {string} activityId
     * @param {mixed[]} fields
     */
    'contributions.update': function(activityId, fields) {
        check(activityId, String);
        check(fields, Partup.schemas.forms.contribution);

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        var activity = Activities.findOneOrFail(activityId);
        var contribution = Contributions.findOne({activity_id: activityId, upper_id: upper._id});
        var isUpperInPartup = User(upper).isPartnerInPartup(activity.partup_id);

        try {
            var newContribution = Partup.transformers.contribution.fromFormContribution(fields);

            if (contribution) {
                // Update contribution
                newContribution.updated_at = new Date();
                newContribution.verified = isUpperInPartup;

                // Unarchive contribution if it was archived
                if (contribution.archived) {
                    newContribution.archived = false;
                }

                Contributions.update(contribution._id, {$set: newContribution});

                if (newContribution.motivation) {
                    Meteor.call('updates.comments.insert', activity.update_id, newContribution.motivation);
                }

                // Post system message
                var cause = false;

                if (contribution.archived && !newContribution.archived) {
                    cause = 'archived';
                }

                // When there's a cause, it means that the system_message will be created somewhere else
                if (!cause) {
                    Partup.server.services.system_messages.send(upper, activity.update_id, 'system_contributions_updated', {update_timestamp: false});
                }
            } else {
                // Insert contribution
                newContribution.created_at = new Date();
                newContribution.activity_id = activityId;
                newContribution.upper_id = upper._id;
                newContribution.partup_id = activity.partup_id;
                newContribution.verified = isUpperInPartup;

                newContribution._id = Contributions.insert(newContribution);

                if (newContribution.motivation) {
                    Meteor.call('updates.comments.insert', activity.update_id, newContribution.motivation);
                }
            }

            return newContribution;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'contribution_could_not_be_updated');
        }
    },

    /**
     * Accept a contribution from non partupper and make that user a partupper
     *
     * @param {string} contributionId
     * */
    'contributions.accept': function(contributionId) {
        check(contributionId, String);

        var upper = Meteor.user();
        var contribution = Contributions.findOneOrFail(contributionId);
        var activity = Activities.findOne({_id: contribution.activity_id});
        var partup = Partups.findOne(contribution.partup_id);

        if (!partup.hasUpper(upper._id)) throw new Meteor.Error(401, 'unauthorized');

        try {
            // Allowing contribution means that all concept contributions by this user will be allowed
            var conceptContributions = Contributions.find({
                partup_id: activity.partup_id,
                upper_id: contribution.upper_id,
                verified: false
            }, {fields: {_id: 1, update_id: 1}}).fetch();
            var conceptContributionsIdArray = _.pluck(conceptContributions, '_id');

            Contributions.update({_id: {$in: conceptContributionsIdArray}}, {$set: {verified: true}}, {multi: true});

            // Update the update
            var set = {
                upper_id: upper._id,
                type: 'partups_contributions_accepted',
                updated_at: new Date()
            };
            Updates.update({_id: contribution.update_id}, {$set: set});

            // Promote the user from Supporter to Upper and remove any activity invites sent to user
            partup.makeSupporterPartner(contribution.upper_id);
            activity.removeAllUpperInvites(contribution.upper_id);

            Event.emit('partups.uppers.inserted', contribution.partup_id, contribution.upper_id);
            Event.emit('contributions.accepted', upper._id, contribution.activity_id, contribution.upper_id);

            // Post system message for each accepted contribution
            conceptContributions.forEach(function(contribution) {
                if (contribution.update_id) {
                    Partup.server.services.system_messages.send(upper, activity.update_id, 'system_contributions_accepted', {update_timestamp: false});
                }
            });
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'contribution_could_not_be_accepted');
        }
    },

    /**
     * Reject a concept contribution
     *
     * @param {string} contributionId
     */
    'contributions.reject': function(contributionId) {
        check(contributionId, String);

        var upper = Meteor.user();
        var contribution = Contributions.findOneOrFail(contributionId);
        var activity = Activities.findOneOrFail(contribution.activity_id);

        if (!User(upper).isPartnerInPartup(contribution.partup_id)) throw new Meteor.Error(401, 'unauthorized');

        try {
            // Archive contribution instead of removing
            Contributions.update(contribution._id, {$set: {archived: true}});

            // Post system message
            Partup.server.services.system_messages.send(upper, activity.update_id, 'system_contributions_rejected', {update_timestamp: false});

            Event.emit('contributions.rejected', upper._id, contribution.activity_id, contribution.upper_id);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'contribution_could_not_be_rejected');
        }
    },

    /**
     * Archive a Contribution
     *
     * @param {string} contributionId
     */
    'contributions.archive': function(contributionId) {
        check(contributionId, String);

        var upper = Meteor.user();
        var contribution = Contributions.findOneOrFail(contributionId);
        var activity = Activities.findOneOrFail(contribution.activity_id);

        if (!upper || contribution.upper_id !== upper._id) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            Contributions.update(contribution._id, {$set: {archived: true}});

            // Check if this was the user's last contribution to this Partup. If so, remove from partner list and add as supporter.
            var contributionsLeft = Contributions.find({
                partup_id: contribution.partup_id,
                upper_id: upper._id,
                verified: true,
                archived: {$ne: true}
            }).count();
            if (!contributionsLeft) {
                var partup = Partups.findOneOrFail(contribution.partup_id);
                if (!partup.isCreatedBy(upper)) {
                    partup.makePartnerSupporter(upper._id);
                }
            }

            // Post system message
            Partup.server.services.system_messages.send(upper, activity.update_id, 'system_contributions_removed', {update_timestamp: false});

            Event.emit('partups.contributions.archived', upper._id, contribution);

            return {
                _id: contribution._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'contribution_could_not_be_archived');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/ratings/ratings_methods.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert a rating for a specific contribution
     *
     * @param {string} contributionId
     * @param {mixed[]} fields
     */
    'ratings.insert': function(contributionId, fields) {
        check(contributionId, String);
        check(fields, Partup.schemas.forms.rating);

        var upper = Meteor.user();

        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        var contribution = Contributions.findOneOrFail(contributionId);
        var activity = Activities.findOneOrFail(contribution.activity_id);

        if (!User(upper).isPartnerInPartup(contribution.partup_id)) throw new Meteor.Error(401, 'unauthorized');

        try {
            // Insert rating
            var newRating = {
                _id: Random.id(),
                created_at: new Date(),
                partup_id: contribution.partup_id,
                activity_id: contribution.activity_id,
                contribution_id: contributionId,
                rating: fields.rating,
                feedback: fields.feedback,
                upper_id: upper._id,
                rated_upper_id: contribution.upper_id
            };

            newRating = Ratings.insert(newRating);

            // Post system message
            Partup.server.services.system_messages.send(upper, activity.update_id, 'system_ratings_inserted', {update_timestamp: false});

            return newRating;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'rating_could_not_be_inserted');
        }
    },

    /**
     * Update a rating
     *
     * @param {string} ratingId
     * @param {mixed[]} fields
     */
    'ratings.update': function(ratingId, fields) {
        check(ratingId, String);
        check(fields, Partup.schemas.forms.rating);

        var upper = Meteor.user();
        var rating = Ratings.findOneOrFail(ratingId);

        if (!upper || upper._id !== rating.upper_id) throw new Meteor.Error(401, 'unauthorized');

        try {
            var newRating = {};

            if (rating) {
                // Update rating
                newRating.rating = fields.rating;
                newRating.feedback = fields.feedback;
                newRating.updated_at = new Date();

                Ratings.update(rating, {$set: newRating});

                //NOTE: no system message is being sent to reduce number of system messages
            }

            return newRating;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'rating_could_not_be_updated');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/partups/partups_methods.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Cache = Partup.server.services.cache;

Meteor.methods({
    /**
     * Insert a Partup
     *
     * @param {mixed[]} fields
     */
    'partups.insert': function(fields) {
        check(fields, Partup.schemas.forms.partupCreate);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            var newPartup = Partup.transformers.partup.fromFormStartPartup(fields);
            newPartup._id = Random.id();
            newPartup.uppers = [user._id];
            newPartup.creator_id = user._id;
            newPartup.created_at = new Date();
            newPartup.slug = Partup.server.services.slugify.slugifyDocument(newPartup, 'name');
            newPartup.upper_data = [];
            newPartup.shared_count = {
                facebook: 0,
                twitter: 0,
                linkedin: 0,
                email: 0
            };
            newPartup.refreshed_at = new Date();

            //check(newPartup, Partup.schemas.entities.partup);

            Partups.insert(newPartup);
            Meteor.users.update(user._id, {$addToSet: {'upperOf': newPartup._id}});

            return {
                _id: newPartup._id,
                slug: newPartup.slug
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_could_not_be_inserted');
        }
    },

    /**
     * Update a Partup
     *
     * @param {string} partupId
     * @param {mixed[]} fields
     */
    'partups.update': function(partupId, fields) {
        check(partupId, String);
        check(fields, Partup.schemas.forms.partupUpdate);

        var user = Meteor.user();
        var partup = Partups.findOneOrFail(partupId);
        var oldLanguage = partup.language;

        var uppers = partup.uppers || [];

        if (!partup.isEditableBy(user)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var newPartupFields = Partup.transformers.partup.fromFormStartPartup(fields);

            // update the slug when the name has changed
            if (fields.name) {
                var document = {
                    _id: partup._id,
                    name: newPartupFields.name
                };
                newPartupFields.slug = Partup.server.services.slugify.slugifyDocument(document, 'name');
            }

            Partups.update(partupId, {$set: newPartupFields});

            Event.emit('partups.language.updated', oldLanguage, newPartupFields.language);

            return {
                _id: partup._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_could_not_be_updated');
        }
    },

    /**
     * Remove a Partup
     *
     * @param {string} partupId
     */
    'partups.remove': function(partupId) {
        check(partupId, String);

        var user = Meteor.user();
        var partup = Partups.findOneOrFail(partupId);

        if (!partup.isRemovableBy(user)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            partup.remove();

            return {
                _id: partup._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_could_not_be_removed');
        }
    },

    /**
     * Discover partups based on provided filters
     *
     * @param {Object} parameters
     * @param {string} options.networkId
     * @param {string} options.locationId
     * @param {string} options.sort
     * @param {string} options.textSearch
     * @param {number} options.limit
     * @param {string} options.language
     */
    'partups.discover': function(parameters) {
        check(parameters, {
            networkId: Match.Optional(String),
            locationId: Match.Optional(String),
            sort: Match.Optional(String),
            textSearch: Match.Optional(String),
            limit: Match.Optional(Number),
            language: Match.Optional(String)
        });

        var userId = Meteor.userId();

        var cacheId = 'discover_partupids_' + JSON.stringify(parameters);
        if (!userId && Cache.has(cacheId)) {
            return Cache.get(cacheId) || [];
        }

        var options = {};
        parameters = parameters || {};

        if (parameters.limit) options.limit = parseInt(parameters.limit);

        parameters = {
            networkId: parameters.networkId,
            locationId: parameters.locationId,
            sort: parameters.sort,
            textSearch: parameters.textSearch,
            limit: parameters.limit,
            language: (parameters.language === 'all') ? undefined : parameters.language
        };

        var partupIds = Partups.findForDiscover(userId, options, parameters).map(function(partup) {
            return partup._id;
        });

        if (!userId) Cache.set(cacheId, partupIds, 3600);

        return partupIds;
    },

    /**
     * Return a list of partups based on search query
     *
     * @param {string} searchString
     * @param {string} exceptPartupId
     * @param {boolean} onlyPublic When this is true, only public partups will be returned
     */
    'partups.autocomplete': function(searchString, exceptPartupId, onlyPublic) {
        check(searchString, String);
        check(exceptPartupId, Match.Optional(String));
        check(onlyPublic, Match.Optional(Boolean));

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');
        onlyPublic = onlyPublic || false;

        var selector = {};

        selector.name = new RegExp('.*' + searchString + '.*', 'i');
        selector._id = {$ne: exceptPartupId};

        if (onlyPublic) {
            selector.privacy_type = {'$in': [Partups.PUBLIC, Partups.NETWORK_PUBLIC]};
        }

        try {
            return Partups.guardedFind(Meteor.userId(), selector, {limit: 30}).fetch();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partups_could_not_be_autocompleted');
        }
    },

    /**
     * Feature a specific partup (superadmin only)
     *
     * @param {string} partupId
     * @param {mixed[]} fields
     */
    'partups.feature': function(partupId, fields) {
        check(partupId, String);
        check(fields, Partup.schemas.forms.featurePartup);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');
        if (!User(user).isAdmin()) throw new Meteor.Error(401, 'unauthorized');

        try {
            var author = Meteor.users.findOne(fields.author_id);
            featured = {
                'active': true,
                'by_upper': {
                    '_id': author._id,
                    'title': fields.job_title
                },
                'comment': fields.comment
            };

            Partups.update(partupId, {$set: {'featured': featured}});

        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_could_not_be_featured');
        }
    },

    /**
     * Unfeature a specific partup (superadmin only)
     *
     * @param {string} kId
     * @param {mixed[]} fields
     */
    'partups.unfeature': function(partupId) {
        check(partupId, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');
        if (!User(user).isAdmin()) throw new Meteor.Error(401, 'unauthorized');

        try {
            Partups.update(partupId, {$unset: {'featured': ''}});
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_could_not_be_unfeatured');
        }
    },

    /**
    * Returns partup stats to superadmins only
    */
    'partups.admin_all': function() {
        var user = Meteor.users.findOne(this.userId);
        if (!User(user).isAdmin()) {
            return;
        }
        return Partups.findStatsForAdmin();
    },

    /**
     * Consume an access token and add the user to the invites
     */
    'partups.convert_access_token_to_invite': function(partupId, accessToken) {
        check(partupId, String);
        check(accessToken, String);

        var user = Meteor.user();
        var partup = Partups.findOneOrFail(partupId);

        try {
            partup.convertAccessTokenToInvite(user._id, accessToken);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_access_token_could_not_be_converted_to_invite');
        }
    },

    /**
     * Reset new updates count
     *
     * @param {String} partupId
     */
    'partups.reset_new_updates': function(partupId) {
        check(partupId, String);

        try {
            var partup = Partups.findOne({_id: partupId, 'upper_data._id': Meteor.userId()});
            if (partup) {
                Partups.update({_id: partupId, 'upper_data._id': Meteor.userId()}, {$set: {'upper_data.$.new_updates': []}});
            }
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_new_updates_could_not_be_reset');
        }
    },

    /**
     * Increase email share count
     *
     * @param {String} partupId
     */
    'partups.increase_email_share_count': function(partupId) {
        check(partupId, String);

        try {
            var partup = Partups.findOneOrFail(partupId);
            partup.increaseEmailShareCount();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'partup_email_share_count_could_not_be_updated');
        }
    },

    /**
     * Invite an existing upper to a partup
     *
     * @param {string} partupId
     * @param {string} inviteeId
     * @param {string} searchQuery
     */
    'partups.invite_existing_upper': function(partupId, inviteeId, searchQuery) {
        check(partupId, String);
        check(inviteeId, String);
        check(searchQuery, Match.Optional(String));

        var inviter = Meteor.user();
        if (!inviter) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var partup = Partups.findOneOrFail(partupId);
        var isAllowedToAccessPartup = !!Partups.guardedFind(inviter._id, {_id: partup._id}).count() > 0;
        if (!isAllowedToAccessPartup) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        if (partup.isRemoved()) throw new Meteor.Error(404, 'partup_could_not_be_found');

        var invitee = Meteor.users.findOneOrFail(inviteeId);

        var isAlreadyInvited = !!Invites.findOne({
            partup_id: partup._id,
            invitee_id: invitee._id,
            inviter_id: inviter._id,
            type: Invites.INVITE_TYPE_PARTUP_EXISTING_UPPER
        });
        if (isAlreadyInvited) {
            throw new Meteor.Error(403, 'user_is_already_invited_to_partup');
        }

        var invite = {
            type: Invites.INVITE_TYPE_PARTUP_EXISTING_UPPER,
            partup_id: partup._id,
            inviter_id: inviter._id,
            invitee_id: invitee._id,
            created_at: new Date
        };

        Invites.insert(invite);

        // Add to the invite list of the partup
        if (!partup.hasInvitedUpper(invitee._id)) {
            Partups.update(partup._id, {$addToSet: {invites: invitee._id}});
        }

        Event.emit('invites.inserted.partup', inviter, partup, invitee, searchQuery);
    },

    /**
     * Invite someone to an partup
     *
     * @param {string} partupId
     * @param {Object} fields
     * @param {[Object]} fields.invitees
     * @param {String} fields.invitees.name
     * @param {String} fields.invitees.email
     * @param {String} fields.message
     */
    'partups.invite_by_email': function(partupId, fields) {
        check(partupId, String);
        check(fields, Partup.schemas.forms.inviteUpper);

        var inviter = Meteor.user();

        if (!inviter) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var partup = Partups.findOneOrFail(partupId);

        if (partup.isRemoved()) throw new Meteor.Error(404, 'partup_could_not_be_found');

        var isAllowedToAccessPartup = !!Partups.guardedFind(inviter._id, {_id: partup._id}).count() > 0;
        if (!isAllowedToAccessPartup) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var invitees = fields.invitees || [];

        invitees.forEach(function(invitee) {
            var isAlreadyInvited = !!Invites.findOne({
                partup_id: partupId,
                invitee_email: invitee.email,
                type: Invites.INVITE_TYPE_PARTUP_EMAIL
            });

            if (isAlreadyInvited) {
                //@TODO How to handle this scenario? Because now, we just skip to the next invitee
                //throw new Meteor.Error(403, 'email_is_already_invited_to_network');
                return;
            }

            var accessToken = Random.secret();

            var invite = {
                type: Invites.INVITE_TYPE_PARTUP_EMAIL,
                partup_id: partup._id,
                inviter_id: inviter._id,
                invitee_name: invitee.name,
                invitee_email: invitee.email,
                message: fields.message,
                access_token: accessToken,
                created_at: new Date
            };

            Invites.insert(invite);

            Event.emit('invites.inserted.partup.by_email', inviter, partup, invitee.email, invitee.name, fields.message, accessToken);
        });
    },

    /**
     * Get user suggestions for a given partup
     *
     * @param {string} partupId
     * @param {Object} options
     * @param {string} options.query
     * @param {Number} options.limit
     * @param {Number} options.skip
     *
     * @return {[string]}
     */
    'partups.user_suggestions': function(partupId, options) {
        check(partupId, String);
        check(options, {
            query: Match.Optional(String),
            limit: Match.Optional(Number),
            skip: Match.Optional(Number)
        });

        this.unblock();

        var upper = Meteor.user();

        if (!upper) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var users = Partup.server.services.matching.matchUppersForPartup(partupId, options);

        // We are returning an array of IDs instead of an object
        return users.map(function(user) {
            return user._id;
        });
    },

    /**
     * Archive a partup
     *
     * @param {String} partupId
     */
    'partups.archive': function(partupId) {
        check(partupId, String);

        var upper = Meteor.user();
        var partup = Partups.findOneOrFail(partupId);

        if (!upper || (!User(upper).isAdmin() && !partup.hasUpper(upper._id))) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            Partups.update(partup._id, {$set: {archived_at: new Date()}});

            Event.emit('partups.archived', upper._id, partup);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'partup_could_not_be_archived');
        }
    },

    /**
     * Unarchive a partup
     *
     * @param {String} partupId
     */
    'partups.unarchive': function(partupId) {
        check(partupId, String);

        var upper = Meteor.user();
        var partup = Partups.findOneOrFail(partupId);

        if (!upper || (!User(upper).isAdmin() && !partup.hasUpper(upper._id))) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            Partups.update(partup._id, {$unset: {archived_at: ''}});

            Event.emit('partups.unarchived', upper._id, partup);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'partup_could_not_be_unarchived');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/partups/partups_analytics_methods.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({

    /**
     * Register a click on a Partup
     *
     * @param {string} partupId
     */
    'partups.analytics.click': function(partupId) {
        check(partupId, String);

        var partup = Partups.findOneOrFail(partupId);
        var hour = (new Date).getHours();

        var user = Meteor.user();

        var ip = this.connection.clientAddress;
        var last_ip = mout.object.get(partup, 'analytics.last_ip');

        if (user) {
            Event.emit('partups.analytics.click', partup._id, user._id);
        }

        if (ip === last_ip) return;

        var clicks_per_hour = mout.object.get(partup, 'analytics.clicks_per_hour') || (new Array(25).join('0').split('').map(parseFloat));
        var clicks_total = mout.object.get(partup, 'analytics.clicks_total') || 0;
        var clicks_per_day = mout.object.get(partup, 'analytics.clicks_per_day') || 0;

        clicks_per_hour[hour] = parseInt(clicks_per_hour[hour] + 1);
        clicks_total++;

        if (!clicks_per_hour.length) return;

        clicks_per_day = clicks_per_hour.reduce(function(result, clicks) { return result + clicks; });

        Partups.update({_id: partupId}, {$set: {
            'analytics.clicks_total': clicks_total,
            'analytics.clicks_per_day': clicks_per_day,
            'analytics.clicks_per_hour': clicks_per_hour,
            'analytics.last_ip': ip
        }});
    }

});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/partups/partups_supporters_methods.js                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Add a Supporter to a Partup
     *
     * @param {string} partupId
     */
    'partups.supporters.insert': function(partupId) {
        check(partupId, String);

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        var partup = Partups.findOneOrFail(partupId);

        try {
            partup.makeSupporter(upper._id);
            Event.emit('partups.supporters.inserted', partup, upper);

            return true;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'user_could_not_be_marked_as_a_supporter');
        }
    },

    /**
     * Remove a Supporter from a Partup
     *
     * @param {string} partupId
     */
    'partups.supporters.remove': function(partupId) {
        check(partupId, String);

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        var partup = Partups.findOneOrFail(partupId);

        try {
            var supporters = partup.supporters || [];
            var isSupporter = !!(supporters.indexOf(upper._id) > -1);

            if (isSupporter) {
                Partups.update(partupId, {$pull: {'supporters': upper._id}});
                Meteor.users.update(upper._id, {$pull: {'supporterOf': partupId}});

                // Also remove upper_data object from partup
                partup.removeUpperDataObject(upper._id);

                Event.emit('partups.supporters.removed', partup, upper);

                return true;
            }

            return false;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'user_could_not_be_unmarked_as_a_supporter');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/users/users_methods.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Update a user
     *
     * @param {mixed[]} fields
     */
    'users.update': function(fields) {
        check(fields, Partup.schemas.forms.profileSettings);

        var upper = Meteor.user();

        if (!upper) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var userFields = Partup.transformers.profile.fromFormProfileSettings(fields);
            userFields.profile.normalized_name = Partup.helpers.normalize(userFields.profile.name);

            // Merge the old profile so empty fields do not get overwritten
            var mergedProfile = _.extend(upper.profile, userFields.profile);

            Meteor.users.update(upper._id, {$set:{profile: mergedProfile}});
            Event.emit('users.updated', upper._id, userFields);

            return {
                _id: upper._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'user_could_not_be_updated');
        }
    },

    /**
     * Return a list of users in a specific partup based on search query
     *
     * @param {string} searchString
     * @param {string} group
     * @param {string} partupId
     * @param {object} options
     */
    'users.autocomplete': function(searchString, group, partupId, options) {
        options = options || {};

        check(searchString, String);
        if (group) check(group, String);
        if (partupId) check(partupId, String);
        if (options.chatSearch) check(options.chatSearch, Boolean);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            // Remove accents that might have been added to the query
            searchString = mout.string.replaceAccents(searchString.toLowerCase());
            var selector = {'profile.normalized_name': new RegExp('.*' + searchString + '.*', 'i')};
            if (options.chatSearch) selector._id = {$ne: user._id};
            var suggestions = Meteor.users.findActiveUsers(selector, {limit: 30}).fetch();
            switch (group) {
                case 'partners':
                    var partners = Meteor.users.findActiveUsers({upperOf: {$in: [partupId]}}).fetch();
                    suggestions.unshift({
                        type: 'partners',
                        name: 'Partners',
                        users: partners
                    });

                    break;
                case 'supporters':
                    var supporters = Meteor.users.findActiveUsers({supporterOf: {$in: [partupId]}}).fetch();
                    suggestions.unshift({
                        type: 'supporters',
                        name: 'Supporters',
                        users: supporters
                    });
                    break;
            }

            return suggestions.map(function(user) {
                if (options.chatSearch) {
                    user.embeddedImage = Images.findForUser(user).fetch().pop();
                }

                return user;
            });
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'users_could_not_be_autocompleted');
        }
    },

    /**
     * Return a list of users based on search query
     *
     * @param {string} searchString
     */
    'users.upper_autocomplete': function(searchString) {
        check(searchString, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            // Remove accents that might have been added to the query
            searchString = mout.string.replaceAccents(searchString.toLowerCase());
            return Meteor.users.findActiveUsers({'profile.normalized_name': new RegExp('.*' + searchString + '.*', 'i')}, {limit: 30}).fetch();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'users_could_not_be_autocompleted');
        }
    },

    /**
     * Deactivate user
     *
     * @param  {string} userId
     */
    'users.deactivate': function(userId) {
        check(userId, String);

        var user = Meteor.user();
        if (!User(user).isAdmin()) {
            return;
        }

        var subject = Meteor.users.findOne(userId);
        if (!subject) throw new Meteor.Error(401, 'unauthorized');
        if (!User(subject).isActive()) throw new Meteor.Error(400, 'user_is_inactive');

        try {
            Meteor.users.update(subject._id, {$set:{
                deactivatedAt: new Date()
            }});

            Event.emit('users.deactivated', subject._id);

            return {
                _id: subject._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'user_could_not_be_deactivated');
        }
    },

    /**
     * Reactivate user
     *
     * @param  {string} userId
     */
    'users.reactivate': function(userId) {
        check(userId, String);

        var user = Meteor.user();
        if (!User(user).isAdmin()) {
            return;
        }

        var subject = Meteor.users.findOne(userId);
        if (!subject) throw new Meteor.Error(401, 'unauthorized');
        if (User(subject).isActive()) throw new Meteor.Error(400, 'user_is_active');

        try {
            Meteor.users.update(subject._id, {$unset:{
                deactivatedAt: ''
            }});

            Event.emit('users.reactivated', subject._id);

            return {
                _id: subject._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(500, 'user_could_not_be_reactivated');
        }
    },

    /**
    * Returns user data to superadmins only
    */
    'users.admin_all': function(selector, options) {
        var user = Meteor.users.findOne(this.userId);
        if (!User(user).isAdmin()) {
            return;
        }
        var selector = selector || {};
        var option = options || {};
        return Meteor.users.findForAdminList(selector, options).fetch();
    },

    /**
    * Returns user stats to superadmins only
    */
    'users.admin_stats': function() {
        var user = Meteor.users.findOne(this.userId);
        if (!User(user).isAdmin()) {
            return;
        }
        return Meteor.users.findStatsForAdmin();
    },

    /**
    * Returns user stats to superadmins only
    */
    'users.admin_impersonate': function(userId) {
        check(userId, String);
        var currentUser = Meteor.users.findOne(this.userId);
        if (!User(currentUser).isAdmin()) {
            return;
        }

        var impersonateUser = Meteor.users.findOne(userId);
        if (!impersonateUser) throw new Meteor.Error(404, 'user_could_not_be_found');
        this.setUserId(userId);
    },

    /**
     * Returns the user's locale based on IP lookup
     */
    'users.get_locale': function() {
        this.unblock();

        var ipAddress = this.connection.clientAddress;
        return Partup.server.services.locale.get_locale(ipAddress);
    },

    /**
     * Returns the users membership of the provided network
     */
    'users.member_of_network': function(userId, networkSlug) {
        var network = Networks.findOne({slug: networkSlug});
        var response = network ? {
            has_member: network.hasMember(userId)
        } : false;
        return response;
    },

    /**
     * Register a device for push notifications
     */
    'users.register_pushnotifications_device': function(registrationId, device) {
        check(this.userId, String);
        check(registrationId, String);
        check(device.uuid, String);
        check(device.manufacturer, String);
        check(device.model, String);
        check(device.version, String);
        check(device.platform, String);

        // Remove old push notification device by uuid
        Meteor.users.update({
            _id: this.userId
        }, {
            $pull: {
                'push_notification_devices': {
                    uuid: device.uuid
                }
            }
        });

        // Insert new push notification device
        Meteor.users.update(this.userId, {
            $addToSet: {
                'push_notification_devices': {
                    registration_id: registrationId,
                    uuid: device.uuid,
                    manufacturer: device.manufacturer,
                    model: device.model,
                    platform: device.platform,
                    version: device.version,
                    createdAt: new Date()
                }
            }
        });
    },

    /**
     * Start a chat with the provided users
     */
    'users.start_chat': function(userIds) {
        check(userIds, [String]);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');
        userIds.unshift(user._id);

        try {
            var chatId = Meteor.call('chats.insert', fields);
            Chats.update(chatId, {$set: {creator_id: user._id}});
            Meteor.users.update({_id: {$in: userIds}}, {$addToSet: {chats: chatId}});

            return chatId;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_chat_could_not_be_inserted');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/services/flickr_methods.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Flickr = Npm.require('node-flickr');
var keys = {
    'api_key': process.env.FLICKR_API_KEY,
    'secret': process.env.FLICKR_SECRET_KEY
};

flickr = new Flickr(keys);

Meteor.methods({
    /**
     * Return Flickr images based on tag relevancy
     *
     * @param {String[]} tags
     * @param {Number} count Number of results to return
     */
    'partups.services.flickr.search': function(tags, count) {
        check(tags, [String]);
        check(count, Match.Optional(Number));

        this.unblock();

        if (!tags || !tags.length || !tags[0] || !tags[0].length) {
            var error = 'No tags given';
            Log.error(error);
            throw new Meteor.Error(400, error);
        }

        if (!flickr.apiKey) {
            var error = 'Error while getting photos from Flickr: No API Key defined';
            Log.error(error);
            throw new Meteor.Error(400, error);
        }

        // Set default values
        count = Math.min(count, 5) || 5;

        var lookupTags = Meteor.wrapAsync(function(tags, count, callback) {
            var searchByFallback = function(count, photos) {
                flickr.get('photos.search', {
                    'group_id': process.env.FLICKR_GROUP_ID || '2843088@N22', // Only search for images in group
                    'extras': 'url_l', // Only search for large images
                    'per_page': count * 5, // Get more results then needed because we will be filtering them
                    'sort': 'relevance',
                    'content_type': 1 // Photos only
                }, function(result, error) {
                    result.photos.photo.forEach(function(photo) {
                        if (!photo.url_l || (photo.height_l < photo.width_l)) return; // Only landscape photos
                        photos.push({
                            'imageUrl': photo.url_l,
                            'authorUrl': 'https://www.flickr.com/people/' + photo.owner
                        });
                    });

                    return callback(null, _.sample(photos, count));
                });
            };

            var searchByTags = function(tags, count, photos) {
                var searchableTags = tags.join(' ');

                flickr.get('photos.search', {
                    'text': encodeURIComponent(searchableTags), // Search for text instead of tags (huge difference)
                    'extras': 'url_l', // Only search for large images
                    'per_page': count * 5, // Get more results then needed because we will be filtering them
                    'sort': 'relevance',
                    'license': [9, 4], // CC0 & Attribution License
                    'content_type': 1 // Photos only
                }, function(result, error) {
                    if (error) {
                        Log.error(error);
                        throw new Meteor.Error(400, 'Error while getting photos from Flickr: ' + error);
                    }

                    result.photos.photo.forEach(function(photo) {
                        if (!photo.url_l || (photo.height_l < photo.width_l)) return; // Only landscape photos
                        photos.push({
                            'imageUrl': photo.url_l,
                            'authorUrl': 'https://www.flickr.com/people/' + photo.owner
                        });
                    });

                    // We don't want all photos to be from 1 Flickr user/album
                    photos = lodash.unique(photos, function(item, key, a) {
                        return item.authorUrl;
                    });

                    if (photos.length < count) {
                        tags.pop();

                        if (tags.length == 0) {
                            // Fallback to random partup group pictures
                            return searchByFallback(count, photos);
                        }

                        return searchByTags(tags, count, photos);
                    }

                    return callback(null, photos.slice(0, count));
                });
            };

            searchByTags(tags, count, []);
        });

        return lookupTags(tags, count);
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/services/splashbase_methods.js                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var d = Debug('methods:splashbase_methods');

Meteor.methods({
    /**
     * Return Splashbase images based on tags
     *
     * @param {string[]} tags
     * @param {number} count Number of results to return
     */
    'partups.services.splashbase.search': function(tags, count) {
        check(tags, [String]);
        check(count, Match.Optional(Number));

        this.unblock();

        if (!tags || !tags.length || !tags[0] || !tags[0].length) {
            var error = 'No tags given';
            Log.error(error);
            throw new Meteor.Error(400, error);
        }

        // Set default values
        count = Math.min(count, 5) || 5;

        var lookupTags = Meteor.wrapAsync(function(tags, count, callback) {

            var searchByTags = function(tags, count, photos) {
                // Splashbase doesn't handle comma's
                tags = tags.join(' ');

                HTTP.get('http://www.splashbase.co/api/v1/images/search?query=' + encodeURIComponent(tags), null, function(error, result) {
                    if (error || result.statusCode !== 200) {
                        Log.error(error);
                        throw new Meteor.Error(400, 'Error while getting photos from Splashbase: ' + error);
                    }

                    var images = result.data.images;
                    var pictureData = [];

                    images.forEach(function(image) {
                        pictureData.push({
                            'imageUrl': image.url,
                            'authorUrl': image.site
                        });
                    });

                    d('Image URLs downloaded from Splashbase:', pictureData);

                    // Randomize array a little and slice off the count before returning
                    return callback(null, pictureData.sort(function() {
                        return .5 - Math.random();
                    }).slice(0, count));
                });
            };

            searchByTags(tags, count);
        });

        return lookupTags(tags, count);
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/services/google_methods.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({

    /**
     * Get an autocompletion of cities
     *
     * @param {String} term
     */
    'google.cities.autocomplete': function(term) {
        check(term, String);

        this.unblock();

        var results = Partup.server.services.google.searchCities(term);

        return results.map(function(result) {
            return {
                id: result.place_id,
                city: result.description
            };
        });
    }

});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/services/meurs_methods.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Retrieve an authentication token
     */
    'meurs.create_test': function() {
        this.unblock();

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        // Set loading state
        Meteor.users.update(upper._id, {$set: {'profile.meurs.initiating_test': true}});

        // Declare vars
        var portal = '';
        var q4youId = '';

        // Define portal
        if (upper.profile.meurs && upper.profile.meurs.portal) {
            portal = upper.profile.meurs.portal;
        } else if (upper.profile.settings.locale) {
            portal = upper.profile.settings.locale;
        } else {
            portal = 'en';
        }

        if (!upper.profile.meurs || !upper.profile.meurs.portal) {
            Meteor.users.update(upper._id, {$set: {'profile.meurs.portal': portal}});
        }

        // Define q4youId
        if (upper.profile.meurs && (portal === 'en' && upper.profile.meurs.en_id)) {
            q4youId = upper.profile.meurs.en_id;
        } else if (upper.profile.meurs && (portal === 'nl' && upper.profile.meurs.nl_id)) {
            q4youId = upper.profile.meurs.nl_id;
        } else {
            q4youId = null;
        }

        // Authenticate
        var token = Partup.server.services.meurs.getToken(portal);

        // Create user if needed
        if (!upper.profile.meurs ||
            (portal === 'en' && !upper.profile.meurs.en_id) ||
            (portal === 'nl' && !upper.profile.meurs.nl_id)
        ) {
            // Add user
            q4youId = Partup.server.services.meurs.addUser(token, upper._id, User(upper).getEmail());

            // Activate user
            var isUserActivated = Partup.server.services.meurs.activateUser(token, q4youId);
            if (!isUserActivated) return false;

            // Update user
            if (portal === 'en') {
                Meteor.users.update(upper._id, {$set: {'profile.meurs.en_id': q4youId}});
            } else if (portal === 'nl') {
                Meteor.users.update(upper._id, {$set: {'profile.meurs.nl_id': q4youId}});
            }
        }

        // Create Program Session if needed
        if (!upper.profile.meurs || !upper.profile.meurs.program_session_id) {
            // Create session
            var programSessionId = Partup.server.services.meurs.createProgramSessionId(portal, token, q4youId);

            // Activate Program Session
            var isProgramSessionActivated = Partup.server.services.meurs.setActiveProgramSession(token, q4youId, programSessionId);
            if (!isProgramSessionActivated) return false;

            // Update user
            Meteor.users.update(upper._id, {$set: {'profile.meurs.program_session_id': programSessionId}});
        }

        // Create return URL
        var returnUrl = Meteor.absoluteUrl() + 'profile/' + upper._id + '/?results_ready=true';

        // Generate browser token and return generated URL to FE
        var testUrl = Partup.server.services.meurs.getBrowserToken(portal, token, q4youId, returnUrl);

        // Unset loading state
        Meteor.users.update(upper._id, {$unset: {'profile.meurs.initiating_test': ''}});

        return testUrl;
    },

    'meurs.get_results': function(upperId) {
        this.unblock();

        // Get Upper
        var upper = Meteor.users.findOne({_id: upperId});
        if (!upper) throw new Meteor.Error(404, 'user not found');

        // Check needed data
        if (!upper.profile.meurs ||
            (!upper.profile.meurs.en_id && !upper.profile.meurs.nl_id) ||
            !upper.profile.meurs.portal ||
            !upper.profile.meurs.program_session_id ||
            upper.profile.meurs.fetched_results
        ) {
            throw new Meteor.Error(400, 'incomplete_meurs_data');
        }

        var q4youId = '';
        if (upper.profile.meurs.portal === 'en' && upper.profile.meurs.en_id) {
            q4youId = upper.profile.meurs.en_id;
        } else if (upper.profile.meurs.portal === 'nl' && upper.profile.meurs.nl_id) {
            q4youId = upper.profile.meurs.nl_id;
        }

        // Authenticate
        var token = Partup.server.services.meurs.getToken(upper.profile.meurs.portal);

        // Get service session ID
        var serviceSessionData = Partup.server.services.meurs.getServiceSessionData(token, q4youId, upper.profile.meurs.program_session_id);

        // Return null when results are not finalized
        if (!serviceSessionData || serviceSessionData.serviceSessionStatus !== 2) return false;

        // Get results
        var results = Partup.server.services.meurs.getResults(token, serviceSessionData.serviceSessionId);
        // Order results by score and only store the best 2
        var orderedResults = lodash.sortBy(results, function(category) {
            return category.zscore;
        }).reverse().slice(0, 2);

        // Save to user
        Meteor.users.update({_id: upper._id}, {$set: {'profile.meurs.results': orderedResults, 'profile.meurs.fetched_results': true}});

        // Update profile completion percentage
        Partup.server.services.profile_completeness.updateScore();

        return true;
    },

    'meurs.reset': function() {
        this.unblock();

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        // Reset test related data
        Meteor.users.update({_id: upper._id}, {
            $unset: {
                'profile.meurs.portal': '',
                'profile.meurs.program_session_id': '',
                'profile.meurs.fetched_results': ''
            }
        });

        // Update profile completion percentage
        Partup.server.services.profile_completeness.updateScore();
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/settings/settings_methods.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Update a user's settings
     *
     * @param {object} data
     */
    'settings.update': function(data) {
        check(data, Partup.schemas.entities.settings);

        var upper = Meteor.user();
        if (!upper) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var settings = _.extend(upper.profile.settings, data);

            Meteor.users.update(upper._id, {$set: {'profile.settings': settings}});
            Event.emit('settings.updated', upper._id, settings);

            return {_id: upper._id};
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'settings_could_not_be_updated');
        }
    },

    /**
     * (Un)subscribe user from/to subscriptions
     *
     * @param {String} subscriptionKey The name of the subscription/notification type
     * @param {Boolean} newValue To set the notification on or off
     */
    'settings.update_email_notifications': function(subscriptionKey, newValue) {
        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        var emailSubscriptions = user.profile.settings.email;
        if (!emailSubscriptions.hasOwnProperty(subscriptionKey)) throw new Meteor.Error(400, 'invalid_subscription');

        // Set the new value
        emailSubscriptions[subscriptionKey] = newValue;

        Meteor.users.update(user._id, {$set:{'profile.settings.email': emailSubscriptions}});
    },

    /**
     * Unsubscribe user from one email type
     *
     * @param {String} token The authentication
     * @param {String} subscriptionKey The name of the subscription/notification type
     */
    'settings.email_unsubscribe_one': function(token, subscriptionKey) {
        var user = Meteor.users.findByUnsubscribeEmailToken(token).fetch()[0];
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        var emailSubscriptions = user.profile.settings.email;
        if (!emailSubscriptions) Log.debug('No subscriptions for user ' + user._id);
        if (!emailSubscriptions.hasOwnProperty(subscriptionKey)) throw new Meteor.Error(400, 'invalid_subscription');

        // Disable the requested notification
        emailSubscriptions[subscriptionKey] = false;

        Meteor.users.update(user._id, {$set:{'profile.settings.email': emailSubscriptions}});
    },

    /**
     * Unsubscribe user from all email types
     *
     * @param {String} token The authentication
     */
    'settings.email_unsubscribe_all': function(token) {
        var user = Meteor.users.findByUnsubscribeEmailToken(token).fetch()[0];
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        var emailSubscriptions = user.profile.settings.email;
        if (!emailSubscriptions) Log.debug('No subscriptions for user ' + user._id);

        // Just disable all the existing notification types
        for (var key in emailSubscriptions) {
            emailSubscriptions[key] = false;
        }

        Meteor.users.update(user._id, {$set:{'profile.settings.email': emailSubscriptions}});
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/images/images_methods.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var path = Npm.require('path');

Meteor.methods({

    /**
     * Insert an image by url
     *
     * @param {String} url
     *
     * @return {String} imageId
     */
    'images.insertByUrl': function(url) {
        check(url, String);

        this.unblock();

        var result = HTTP.get(url, {'npmRequestOptions': {'encoding': null}});

        var filename = Random.id() + '.jpg';
        var body = new Buffer(result.content, 'binary');
        var mimetype = 'image/jpeg';

        var image = Partup.server.services.images.upload(filename, body, mimetype);

        return {
            _id: image._id
        };
    }

});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/networks/networks_methods.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({

    /**
     * Insert a Network
     *
     * @param {mixed[]} fields
     */
    'networks.insert': function(fields) {
        check(fields, Partup.schemas.forms.networkCreate);

        var user = Meteor.user();
        if (!user || !User(user).isAdmin()) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var network = {};
            network.name = fields.name;
            network.privacy_type = fields.privacy_type;
            network.slug = Partup.server.services.slugify.slugify(fields.name);
            network.uppers = [user._id];
            network.admins = [user._id];
            network.created_at = new Date();
            network.updated_at = new Date();
            network.stats = {
                'activity_count' : 0,
                'partner_count' : 0,
                'partup_count' : 0,
                'supporter_count' : 0,
                'upper_count' : 1
            },
            network.most_active_uppers = [
                user._id
            ];
            network.most_active_partups = [];
            network.common_tags = [];
            network.contentblocks = [];

            network._id = Networks.insert(network);

            Meteor.users.update(user._id, {$addToSet: {networks: network._id}});

            return {
                _id: network._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_could_not_be_inserted');
        }
    },

    /**
     * Update a Network
     *
     * @param {String} networkId
     * @param {mixed[]} fields
     */
    'networks.update': function(networkId, fields) {
        check(networkId, String);
        check(fields, Partup.schemas.forms.network);

        var user = Meteor.user();
        var network = Networks.findOneOrFail(networkId);

        if (!user || !network.isAdmin(user._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var newNetworkFields = Partup.transformers.network.fromFormNetwork(fields);

            Networks.update(networkId, {$set: newNetworkFields});

            return {
                _id: network._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_could_not_be_updated');
        }
    },

    /**
     * Invite someone to a network
     *
     * @param {String} networkId
     * @param {Object} fields
     * @param {[Object]} fields.invitees
     * @param {String} fields.invitees.name
     * @param {String} fields.invitees.email
     * @param {String} fields.message
     */
    'networks.invite_by_email': function(networkId, fields) {
        check(networkId, String);
        check(fields, Partup.schemas.forms.inviteUpper);

        var inviter = Meteor.user();

        if (!inviter) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var network = Networks.findOneOrFail(networkId);

        if (!network.hasMember(inviter._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var invitees = fields.invitees || [];

        invitees.forEach(function(invitee) {
            var isAlreadyInvited = !!Invites.findOne({
                network_id: networkId,
                invitee_email: invitee.email,
                type: Invites.INVITE_TYPE_NETWORK_EMAIL
            });

            if (isAlreadyInvited) {
                //@TODO How to handle this scenario? Because now, we just skip to the next invitee
                //throw new Meteor.Error(403, 'email_is_already_invited_to_network');
                return;
            }

            var accessToken = Random.secret();

            var invite = {
                type: Invites.INVITE_TYPE_NETWORK_EMAIL,
                network_id: network._id,
                inviter_id: inviter._id,
                invitee_name: invitee.name,
                invitee_email: invitee.email,
                message: fields.message,
                access_token: accessToken,
                created_at: new Date
            };

            Invites.insert(invite);

            // Save the access token to the network to allow access
            Networks.update(network._id, {$addToSet: {access_tokens: accessToken}});

            Event.emit('invites.inserted.network.by_email', inviter, network, invitee.email, invitee.name, fields.message, accessToken);
        });
    },

    /**
     * Invite multple uppers to a network
     *
     * @param {String} networkId
     * @param {Object} fields
     * @param {String} fields.csv
     * @param {String} fields.message
     * @param {Object[]} invitees
     */
    'networks.invite_by_email_bulk': function(networkId, fields, invitees) {
        check(networkId, String);
        check(fields, Partup.schemas.forms.networkBulkinvite);

        if (!invitees || (invitees.length < 1 || invitees.length > 200)) {
            throw new Meteor.Error(400, 'invalid_invitees');
        }

        var inviter = Meteor.user();

        if (!inviter) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var network = Networks.findOneOrFail(networkId);

        if (!network.hasMember(inviter._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        // Create invites array
        var invites = invitees.map(function(invitee) {
            var isAlreadyInvited = !!Invites.findOne({
                network_id: network._id,
                invitee_email: invitee.email,
                type: Invites.INVITE_TYPE_NETWORK_EMAIL
            });

            if (isAlreadyInvited) return false;

            var accessToken = Random.secret();

            Networks.update(network._id, {$addToSet: {access_tokens: accessToken}});

            Event.emit('invites.inserted.network.by_email', inviter, network, invitee.email, invitee.name, fields.message, accessToken);

            return {
                type: Invites.INVITE_TYPE_NETWORK_EMAIL,
                network_id: network._id,
                inviter_id: inviter._id,
                invitee_name: invitee.name,
                invitee_email: invitee.email,
                message: fields.message,
                access_token: accessToken,
                created_at: new Date
            };
        });

        // Remove falsy values
        invites = lodash.compact(invites);

        // Insert all invites
        invites.forEach(function(invite) {
            Invites.insert(invite);
        });

        // Return the total count of successful invites
        return invites.length;
    },

    /**
     * Invite an existing upper to an network
     *
     * @param {String} networkId
     * @param {String} inviteeId
     * @param {String} searchQuery
     */
    'networks.invite_existing_upper': function(networkId, inviteeId, searchQuery) {
        check(networkId, String);
        check(inviteeId, String);
        check(searchQuery, Match.Optional(String));

        var inviter = Meteor.user();
        var network = Networks.findOneOrFail(networkId);

        if (!inviter || !network.hasMember(inviter._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        if (network.hasMember(inviteeId)) {
            throw new Meteor.Error(409, 'user_is_already_member_of_network');
        }

        var invitee = Meteor.users.findOneOrFail(inviteeId);
        var isAlreadyInvited = !!Invites.findOne({
            network_id: networkId,
            invitee_id: invitee._id,
            inviter_id: inviter._id,
            type: Invites.INVITE_TYPE_NETWORK_EXISTING_UPPER
        });
        if (isAlreadyInvited) {
            throw new Meteor.Error(403, 'user_is_already_invited_to_network');
        }

        // Store invite
        var invite = {
            type: Invites.INVITE_TYPE_NETWORK_EXISTING_UPPER,
            network_id: network._id,
            inviter_id: inviter._id,
            invitee_id: invitee._id,
            created_at: new Date
        };

        Invites.insert(invite);

        Event.emit('invites.inserted.network', inviter, network, invitee, searchQuery);
    },

    /**
     * Join a Network
     *
     * @param {String} networkId
     */
    'networks.join': function(networkId) {
        check(networkId, String);

        var user = Meteor.user();
        var network = Networks.findOneOrFail(networkId);

        if (!user) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        if (network.hasMember(user._id)) {
            throw new Meteor.Error(409, 'user_is_already_member_of_network');
        }

        try {
            if (network.isClosed()) {
                // Instantly add user when invited by an admin
                if (network.isUpperInvitedByAdmin(user._id)) {
                    network.addUpper(user._id);
                    Event.emit('networks.uppers.inserted', user, network);
                    return Log.debug('User added to closed network due to admin invite.');
                }

                // Add user to pending if it's a closed network
                network.addPendingUpper(user._id);

                // Send notification to admin
                Event.emit('networks.new_pending_upper', network, user);
                return Log.debug('User (already) added to waiting list');
            }

            if (network.isInvitational()) {
                // Check if the user is invited
                if (network.isUpperInvited(user._id)) {
                    network.addUpper(user._id);
                    Event.emit('networks.uppers.inserted', user, network);
                    return Log.debug('User added to invitational network.');
                } else {
                    if (!network.isUpperPending(user._id)) {
                        // It's an invitational network, so add user as pending at this point to let the admin decide
                        network.addPendingUpper(user._id);

                        // Send notification to admin
                        Event.emit('networks.new_pending_upper', network, user);
                        return Log.debug('User added to waiting list');
                    }

                    return Log.debug('User already added to waiting list');
                }
            }

            if (network.isPublic()) {
                // Allow user instantly
                network.addUpper(user._id);
                Event.emit('networks.uppers.inserted', user, network);
                return Log.debug('User added to public network.');
            }

            return Log.debug('Unknown access level for this network: ' + network.privacy_type);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'user_could_not_join_network');
        }
    },

    /**
     * Accept a request to join network
     *
     * @param {String} networkId
     * @param {String} upperId
     */
    'networks.accept': function(networkId, upperId) {
        check(networkId, String);
        check(upperId, String);

        var user = Meteor.user();
        var network = Networks.findOneOrFail(networkId);

        if (!network.isNetworkAdmin(user._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        if (network.hasMember(upperId)) {
            throw new Meteor.Error(409, 'user_is_already_member_of_network');
        }

        try {
            network.acceptPendingUpper(upperId);
            network.removeAllUpperInvites(upperId);

            Event.emit('networks.accepted', user._id, networkId, upperId);

            return {
                network_id: network._id,
                upper_id: upperId
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'user_could_not_be_accepted_from_network');
        }
    },

    /**
     * Reject a request to join network
     *
     * @param {String} networkId
     * @param {String} upperId
     */
    'networks.reject': function(networkId, upperId) {
        check(networkId, String);
        check(upperId, String);

        var user = Meteor.user();
        var network = Networks.findOneOrFail(networkId);

        if (!network.isNetworkAdmin(user._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            network.rejectPendingUpper(upperId);

            return {
                network_id: network._id,
                upper_id: upperId
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'user_could_not_be_rejected_from_network');
        }
    },

    /**
     * Leave a Network
     *
     * @param {String} networkId
     */
    'networks.leave': function(networkId) {
        check(networkId, String);

        var user = Meteor.user();
        var network = Networks.findOneOrFail(networkId);

        if (!network.hasMember(user._id)) {
            throw new Meteor.Error(400, 'user_is_not_a_member_of_network');
        }

        if (network.isNetworkAdmin(user._id)) {
            throw new Meteor.Error(400, 'network_admin_cant_leave_network');
        }

        try {
            network.leave(user._id);
            Event.emit('networks.uppers.removed', user, network);

            return {
                network_id: network._id,
                upper_id: user._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'user_could_not_be_removed_from_network');
        }
    },

    /**
     * Remove an upper from a network as admin
     *
     * @param {String} networkId
     * @param {String} upperId
     */
    'networks.remove_upper': function(networkId, upperId) {
        check(networkId, String);
        check(upperId, String);

        var user = Meteor.user();
        var network = Networks.findOneOrFail(networkId);

        if (!network.isAdmin(user._id) || network.isNetworkAdmin(upperId)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            // Remove user from admin list (if admin)
            if (network.isNetworkAdmin(upperId)) {
                network.removeAdmin(upperId);
            }

            network.leave(upperId);
            Event.emit('networks.uppers.removed', user._id, network._id);

            return {
                network_id: network._id,
                upper_id: upperId
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'user_could_not_be_removed_from_network');
        }
    },

    /**
     * Return a list of networks based on search query
     *
     * @param {String} query
     */
    'networks.autocomplete': function(query) {
        check(query, String);

        this.unblock();

        var user = Meteor.user();
        if (!user) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            query = query.replace(/-/g, ' '); // Replace dashes with spaces
            return Networks.guardedMetaFind({slug: new RegExp('.*' + query + '.*', 'i')}, {limit: 30}).fetch();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'networks_could_not_be_autocompleted');
        }
    },

    /**
     * Return a list of networks based on search query and swarm
     *
     * @param {String} query
     * @param {String} swarmSlug
     */
    'networks.autocomplete_swarm': function(query, swarmSlug) {
        check(query, String);

        this.unblock();

        var user = Meteor.user();
        if (!user) {
            throw new Meteor.Error(401, 'unauthorized');
        }
        var swarm = Swarms.guardedMetaFind({slug: swarmSlug}, {limit: 1}).fetch().pop();
        try {
            query = query.replace(/-/g, ' '); // Replace dashes with spaces
            return Networks.guardedMetaFind({
                slug: new RegExp('.*' + query + '.*', 'i'),
                swarms: {$nin: [swarm._id]}
            }, {limit: 30}).fetch();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'networks_could_not_be_autocompleted');
        }
    },

    /**
     * Get user suggestions for a given network
     *
     * @param {String} networkSlug
     * @param {Object} options
     * @param {String} options.query
     * @param {Number} options.limit
     * @param {Number} options.skip
     *
     * @return {Array}
     */
    'networks.user_suggestions': function(networkSlug, options) {
        check(networkSlug, String);
        check(options, {
            query: Match.Optional(String),
            limit: Match.Optional(Number),
            skip: Match.Optional(Number)
        });

        this.unblock();

        var upper = Meteor.user();

        if (!upper) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var users = Partup.server.services.matching.matchUppersForNetwork(networkSlug, options);

        // We are returning an array of IDs instead of an object
        return users.map(function(user) {
            return user._id;
        });
    },

    /**
     * Remove a Network
     *
     * @param {String} networkId
     */
    'networks.remove': function(networkId) {
        check(networkId, String);

        var user = Meteor.user();
        if (!user || !User(user).isAdmin()) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var network = Networks.findOneOrFail(networkId);
        if (network.uppers.length > 1) {
            throw new Meteor.Error(400, 'network_contains_uppers');
        }

        var networkPartups = Partups.find({network_id: networkId});
        if (networkPartups.count() > 0) {
            throw new Meteor.Error(400, 'network_contains_partups');
        }

        try {
            Networks.remove(networkId);
            Meteor.users.update(user._id, {$pull: {networks: network._id}});
            var network_swarms = Swarms.find({networks: {$in: [networkId]}}).fetch();
            network_swarms.forEach(function(swarm) {
                Swarms.update(swarm._id, {$pull: {networks: networkId}});
            });

            return {
                _id: networkId
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_could_not_be_removed');
        }
    },

    /**
     * Feature a specific network (superadmin only)
     *
     * @param {String} networkId
     * @param {mixed[]} fields
     */
    'networks.feature': function(networkId, fields) {
        check(networkId, String);
        check(fields, Partup.schemas.forms.featureNetwork);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');
        if (!User(user).isAdmin()) throw new Meteor.Error(401, 'unauthorized');

        var author = Meteor.users.findOne(fields.author_id);
        if (!author) throw new Meteor.Error(400, 'user_could_not_be_found');

        var featured = {
            'active': true,
            'by_upper': {
                '_id': author._id,
                'title': fields.job_title
            },
            'comment': fields.comment,
            'logo': fields.logo
        };

        try {
            Networks.update(networkId, {
                $set: {
                    'featured': featured,
                    'language': fields.language
                }
            });
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_could_not_be_featured');
        }
    },

    /**
     * Unfeature a specific network (superadmin only)
     *
     * @param {String} networkId
     */
    'networks.unfeature': function(networkId) {
        check(networkId, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');
        if (!User(user).isAdmin()) throw new Meteor.Error(401, 'unauthorized');

        try {
            Networks.update(networkId, {$unset: {'featured': ''}});
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_could_not_be_unfeatured');
        }
    },

    /**
     * Update privileged network fields (superadmin only)
     *
     * @param {String} networkSlug
     * @param {mixed[]} fields
     */
    'networks.admin_update': function(networkSlug, fields) {
        check(networkSlug, String);
        check(fields, Partup.schemas.forms.networkEdit);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');
        if (!User(user).isAdmin()) throw new Meteor.Error(401, 'unauthorized');

        var network = Networks.findOneOrFail({slug: networkSlug});

        try {
            Networks.update(network._id, {$set: fields});
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_could_not_be_updated');
        }
    },

    /**
     * Consume an access token and add the user to the invites
     *
     * @param {String} networkSlug
     * @param {String} accessToken
     * */
    'networks.convert_access_token_to_invite': function(networkSlug, accessToken) {
        check(networkSlug, String);
        check(accessToken, String);

        var user = Meteor.user();
        var network = Networks.findOne({slug: networkSlug});

        try {
            network.convertAccessTokenToInvite(user._id, accessToken);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_access_token_could_not_be_converted_to_invite');
        }
    },

    /**
     * Give a user admin rights
     *
     * @param {String} networkSlug
     * @param {String} userId
     * */
    'networks.make_admin': function(networkSlug, userId) {
        check(networkSlug, String);
        check(userId, String);

        var user = Meteor.user();
        var network = Networks.findOne({slug: networkSlug});

        if (!user || !(network.isNetworkAdmin(user._id) || User(user).isAdmin())) throw new Meteor.Error(401, 'unauthorized');

        try {
            if (network.hasMember(userId)) {
                if (network.admins.length > 10) throw new Meteor.Error(400, 'network_admin_limit_reached');
                network.addAdmin(userId);
            }
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_user_could_not_be_made_admin');
        }
    },

    /**
     * Remove admin rights from user
     *
     * @param {String} networkSlug
     * @param {String} userId
     * */
    'networks.remove_admin': function(networkSlug, userId) {
        check(networkSlug, String);
        check(userId, String);

        var user = Meteor.user();
        var network = Networks.findOne({slug: networkSlug});

        if (!user || !(network.isNetworkAdmin(user._id) || User(user).isAdmin())) throw new Meteor.Error(401, 'unauthorized');

        try {
            if (network.hasMember(userId) && network.admins.length > 1) {
                network.removeAdmin(userId);
            }
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_user_could_not_be_removed_as_admin');
        }
    },

    /**
     * Insert a ContentBlock
     *
     * @param {String} networkSlug
     * @param {mixed[]} fields
     */
    'networks.contentblock_insert': function(networkSlug, fields) {
        check(networkSlug, String);
        check(fields, Partup.schemas.forms.contentBlock);

        var user = Meteor.user();
        var network = Networks.findOneOrFail({slug: networkSlug});

        if (!user || !(network.isNetworkAdmin(user._id) || User(user).isAdmin())) throw new Meteor.Error(401, 'unauthorized');

        // Only 1 'intro' type allowed
        if (fields.type === 'intro') {
            var introBlock = ContentBlocks.findOne({_id: {$in: network.contentblocks || []}, type: 'intro'});
            if (introBlock) throw new Meteor.Error(400, 'network_contentblocks_intro_already_exists');
        }

        try {
            var contentBlockFields = Partup.transformers.contentBlock.fromFormContentBlock(fields);
            var contentBlock = Meteor.call('contentblocks.insert', contentBlockFields);
            Networks.update(network._id, {$addToSet: {contentblocks: contentBlock._id}});

            return contentBlock._id;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_contentblocks_could_not_be_inserted');
        }
    },

    /**
     * Update a ContentBlock
     *
     * @param {String} networkSlug
     * @param {String} contentBlockId
     * @param {mixed[]} fields
     */
    'networks.contentblock_update': function(networkSlug, contentBlockId, fields) {
        check(networkSlug, String);
        check(fields, Partup.schemas.forms.contentBlock);

        var user = Meteor.user();
        var network = Networks.findOneOrFail({slug: networkSlug});

        if (!user || !network.isNetworkAdmin(user._id) || !network.hasContentBlock(contentBlockId)) throw new Meteor.Error(401, 'unauthorized');

        try {
            Meteor.call('contentblocks.update', contentBlockId, fields);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_contentblocks_could_not_be_updated');
        }
    },

    /**
     * Remove a ContentBlock
     *
     * @param {String} networkSlug
     * @param {String} contentBlockId
     */
    'networks.contentblock_remove': function(networkSlug, contentBlockId) {
        check(networkSlug, String);
        check(contentBlockId, String);

        var user = Meteor.user();
        var network = Networks.findOneOrFail({slug: networkSlug});

        if (!user || !network.isNetworkAdmin(user._id) || !network.hasContentBlock(contentBlockId)) throw new Meteor.Error(401, 'unauthorized');

        try {
            Networks.update(network._id, {$pull: {contentblocks: contentBlockId}});
            ContentBlocks.remove(contentBlockId);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_contentblocks_could_not_be_removed');
        }
    },

    /**
     * Update a ContentBlock sequence
     *
     * @param {String} networkSlug
     * @param {[String]} contentBlockSequence
     */
    'networks.contentblock_sequence': function(networkSlug, contentBlockSequence) {
        check(networkSlug, String);
        check(contentBlockSequence, [String]);

        var user = Meteor.user();
        var network = Networks.findOneOrFail({slug: networkSlug});

        if (!user || !network.isNetworkAdmin(user._id)) throw new Meteor.Error(401, 'unauthorized');

        // Check if length of new array is the same as the current length
        if (network.contentblocks.length !== contentBlockSequence.length) throw new Meteor.Error(400, 'network_contentblocks_not_matching');

        // Check if given IDs are legit
        contentBlockSequence.forEach(function(contentBlockId) {
            if (!network.hasContentBlock(contentBlockId)) throw new Meteor.Error(401, 'unauthorized');
        });

        try {
            Networks.update(network._id, {$set: {contentblocks: contentBlockSequence}});
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_contentblocks_could_not_be_updated');
        }
    },

    /**
     * Insert a ContentBlock
     *
     * @param {String} networkSlug
     * @param {mixed[]} fields
     */
    'networks.chat_insert': function(networkSlug, fields) {
        // Temp disable
        return;

        check(networkSlug, String);
        check(fields, Partup.schemas.forms.chat);

        var user = Meteor.user();
        var network = Networks.findOneOrFail({slug: networkSlug});

        if (!user) throw new Meteor.Error(401, 'unauthorized');

        // Only 1 chat per network allowed
        if (network.chat_id) return network.chat_id;

        try {
            var chatId = Meteor.call('chats.insert', fields);
            Networks.update(network._id, {$set: {chat_id: chatId}});

            return chatId;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_chat_could_not_be_inserted');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/tags/tags_methods.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Return a list of tags based on search query
     *
     * @param {string} searchString
     */
    'tags.autocomplete': function(searchString) {
        check(searchString, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            return Tags.find({_id: new RegExp('.*' + searchString + '.*', 'i')}, {limit: 30}).fetch();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'tags_could_not_be_autocompleted');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/notifications/notifications_methods.js                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({

    /**
     * Mark a notification as read
     *
     * @param {String} notificationId
     */
    'notifications.read': function(notificationId) {
        check(notificationId, String);

        this.unblock();

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        Notifications.update({'_id': notificationId, 'for_upper_id': user._id}, {'$set': {'new': false}});
    },

    /**
     * Mark all notifications as read
     */
    'notifications.all_read': function() {
        this.unblock();

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        Notifications.update({'for_upper_id': user._id}, {'$set': {'new': false}}, {'multi':true});
        Meteor.users.update(user._id, {'$set': {'flags.dailyDigestEmailHasBeenSent': false}});
    },

    /**
     * Mark a notification as clicked
     *
     * @param {String} notificationId
     */
    'notifications.clicked': function(notificationId) {
        check(notificationId, String);

        this.unblock();

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        Notifications.update({'_id': notificationId, 'for_upper_id': user._id}, {'$set': {'clicked': true}});
    }

});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/uploads/uploads_methods.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Parse a CSV file and return the containing email addresses
     *
     * @param {String} fileId
     *
     * @return {Array} emailAddresses
     */
    'uploads.parse_csv': function(fileId) {
        check(fileId, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        this.unblock();

        var file = Temp.findOne({_id: fileId});
        var filePath = process.env.TEMP_DIR + '/temp-' + file._id + '-' + file.original.name;

        var fs = Npm.require('fs');

        var emailAddresses = Meteor.wrapAsync(function(filePath, done) {
            fs.readFile(filePath, 'utf8', Meteor.bindEnvironment(function(err, fileContent) {
                if (err) {
                    return done(new Meteor.Error(400, 'could_not_read_uploaded_file'));
                }

                CSV()
                .from.string(fileContent, {
                        delimiter: ';', // Set the field delimiter. One character only, defaults to comma.
                        skip_empty_lines: true, // Don't generate empty values for empty lines.
                        trim: true // Ignore whitespace immediately around the delimiter.
                    })
                .to.array(Meteor.bindEnvironment(function(array) {
                    var list = lodash.chain(array)
                        .map(function(row) {
                            if (!Partup.services.validators.email.test(row[1])) return false;

                            return {
                                name: row[0],
                                email: row[1]
                            };
                        })
                        .compact()
                        .uniq(function(row) {
                            return row.email;
                        })
                        .value();

                    // Temp file is not needed anymore since we got the needed data.
                    file.remove();

                    // Limit to 200 email addresses
                    if (list.length > 200) {
                        done(new Meteor.Error(400, 'too_many_email_addresses'));
                        return;
                    }

                    done(null, list);
                }))
                .on('error', function(error) {
                    done(error);
                });
            }));

        });

        return emailAddresses(filePath);
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/tiles/tiles_methods.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert a tile
     *
     * @param {mixed[]} fields
     */
    'tiles.insert': function(fields) {
        check(fields, Partup.schemas.forms.tile);

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        // Validate video url
        if (fields.video_url && !Partup.services.validators.isVideoUrl(fields.video_url)) {
            throw new Meteor.Error(400, 'video_url_invalid');
        }

        try {
            var latestUpperTile = Tiles.findOne({upper_id: upper._id, sort: {position: -1}});
            if (latestUpperTile) {
                var position = latestUpperTile.position + 1;
            } else {
                var position = 0;
            }
            var tile = {
                _id: Random.id(),
                upper_id: upper._id,
                type: fields.type,
                description: fields.description,
                position: position
            };

            if (fields.type === 'image') {
                tile.image_id = fields.image_id;
            } else if (fields.type === 'video') {
                tile.video_url = fields.video_url;
            }

            Tiles.insert(tile);
            Meteor.users.update(upper._id, {$addToSet: {'profile.tiles': tile._id}});

            // Update profile completion percentage
            Partup.server.services.profile_completeness.updateScore();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'tile_could_not_be_inserted');
        }
    },

    /**
     * Remove a tile
     *
     * @param {String} tileId
     */
    'tiles.remove': function(tileId) {
        check(tileId, String);

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        try {
            Tiles.remove({_id: tileId});
            Meteor.users.update(upper._id, {$pull: {'profile.tiles': tileId}});

            // Update profile completion percentage
            Partup.server.services.profile_completeness.updateScore();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'tile_could_not_be_removed');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/swarms/swarms_methods.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert a Swarm
     *
     * @param {mixed[]} fields
     */
    'swarms.insert': function(fields) {
        check(fields, Partup.schemas.forms.swarmCreate);

        var user = Meteor.user();
        if (!user || !User(user).isAdmin()) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var swarm = {};
            swarm.name = sanitizeHtml(fields.name);
            swarm.slug = Partup.server.services.slugify.slugify(fields.name);
            swarm.networks = [];
            swarm.admin_id = user._id;
            swarm.quotes = [];
            swarm.stats = {
                activity_count: 0,
                network_count: 0,
                partup_count: 0,
                supporter_count: 0,
                upper_count: 0
            };
            swarm.shared_count = {
                facebook: 0,
                twitter: 0,
                linkedin: 0,
                email: 0
            };
            swarm.created_at = new Date();
            swarm.updated_at = new Date();
            swarm.refreshed_at = new Date(); // For the shared_count cron job

            swarm._id = Swarms.insert(swarm);

            return {
                _id: swarm._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'swarm_could_not_be_inserted');
        }
    },

    /**
     * Update a Swarm
     *
     * @param {String} swarmId
     * @param {mixed[]} fields
     */
    'swarms.update': function(swarmId, fields) {
        check(swarmId, String);
        check(fields, Partup.schemas.forms.swarmUpdate);

        var user = Meteor.user();
        var swarm = Swarms.findOneOrFail(swarmId);

        if (!user || !swarm.isAdmin(user._id)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var newSwarmFields = Partup.transformers.swarm.fromFormSwarm(fields);

            Swarms.update(swarmId, {$set: newSwarmFields});

            return {
                _id: swarm._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'swarm_could_not_be_updated');
        }
    },

    /**
     * Update privileged swarm fields (superadmin only)
     *
     * @param {String} swarmSlug
     * @param {mixed[]} fields
     */
    'swarms.admin_update': function(swarmSlug, fields) {
        check(swarmSlug, String);
        check(fields, Partup.schemas.forms.swarmEditAdmin);

        var user = Meteor.user();
        if (!user || !User(user).isAdmin()) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var swarm = Swarms.findOneOrFail({slug: swarmSlug});

        if (fields.admin_id) {
            var adminUser = Meteor.users.findOneOrFail(fields.admin_id);
        }

        try {
            Swarms.update(swarm._id, {$set: {admin_id: adminUser._id}});
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'swarm_could_not_be_updated');
        }
    },

    /**
     * Add a network to the swarm
     *
     * @param {String} swarmId
     * @param {String} networkId
     */
    'swarms.add_network': function(swarmId, networkId) {
        check(swarmId, String);
        check(networkId, String);

        var user = Meteor.user();
        if (!User(user).isSwarmAdmin(swarmId) || !User(user).isAdmin()) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            // Make sure the swarm and network exist
            var swarm = Swarms.findOneOrFail({_id: swarmId});
            var network = Networks.findOneOrFail({_id: networkId});

            // They do, so let's add
            swarm.addNetwork(network._id);

            // All done, now all we need to do is to update the stats
            Event.emit('partups.swarms.networks.updated', user._id, swarm);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_could_not_be_added_to_swarm');
        }
    },

    /**
     * Remove a network from the swarm
     *
     * @param {String} swarmId
     * @param {String} networkId
     */
    'swarms.remove_network': function(swarmId, networkId) {
        check(swarmId, String);
        check(networkId, String);

        var user = Meteor.user();
        if (!User(user).isSwarmAdmin(swarmId) || !User(user).isAdmin()) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            // Make sure the swarm and network exist
            var swarm = Swarms.findOneOrFail({_id: swarmId});
            var network = Networks.findOneOrFail({_id: networkId});

            // They do, so let's remove
            swarm.removeNetwork(network._id);

            // All done, now all we need to do is to update the stats
            Event.emit('partups.swarms.networks.updated', user._id, swarm);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'network_could_not_be_removed_from_swarm');
        }
    },

    /**
     * Remove a Swarm
     *
     * @param {String} swarmId
     */
    'swarms.remove': function(swarmId) {
        check(swarmId, String);

        var user = Meteor.user();
        if (!user || !User(user).isAdmin()) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var swarm = Swarms.findOneOrFail(swarmId);
        if (swarm.networks.length > 1) {
            throw new Meteor.Error(400, 'swarm_contains_networks');
        }

        try {
            Swarms.remove(swarmId);

            return {
                _id: swarmId
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'swarm_could_not_be_removed');
        }
    },

    /**
     * Increase email share count
     *
     * @param {String} swarmId
     */
    'swarms.increase_email_share_count': function(swarmId) {
        check(swarmId, String);

        try {
            var swarm = Swarms.findOneOrFail(swarmId);
            swarm.increaseEmailShareCount();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'swarm_email_share_count_could_not_be_updated');
        }
    },

    /**
     * Add a quote to a swarm
     *
     * @param {String} swarmId
     * @param {mixed[]} fields
     */
    'swarms.add_quote': function(swarmId, fields) {
        check(swarmId, String);
        check(fields, Partup.schemas.forms.swarmQuote);

        var user = Meteor.user();
        if (!user || !User(user).isAdmin() || !User(user).isSwarmAdmin(swarmId)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        var swarm = Swarms.findOneOrFail(swarmId, {fields: {quotes: 1}});
        if (swarm.quotes.length >= 3) {
            throw new Meteor.Error(400, 'swarm_quote_limit_reached');
        }

        try {
            var upper = Meteor.users.findOne(fields.author_id);
            var quote = {
                _id: Random.id(),
                content: sanitizeHtml(fields.content),
                author: {
                    _id: upper._id,
                    name: upper.profile.name,
                    image: upper.profile.image
                },
                created_at: new Date(),
                updated_at: new Date()
            };

            Swarms.update(swarmId, {$push: {quotes: quote}});
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'swarm_quote_could_not_be_added');
        }
    },

    /**
     * Update a quote in a swarm
     *
     * @param {String} swarmId
     * @param {String} quoteId
     * @param {mixed[]} fields
     */
    'swarms.update_quote': function(swarmId, quoteId, fields) {
        check(swarmId, String);
        check(quoteId, String);
        check(fields, Partup.schemas.forms.swarmQuote);

        var user = Meteor.user();
        if (!user || !User(user).isAdmin() || !User(user).isSwarmAdmin(swarmId)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            var upper = Meteor.users.findOne(fields.author_id);

            Swarms.update({_id: swarmId, 'quotes._id': quoteId}, {
                $set: {
                    'quotes.$.author': {
                        _id: upper._id,
                        name: upper.profile.name,
                        image: upper.profile.image
                    },
                    'quotes.$.content': sanitizeHtml(fields.content),
                    'quotes.$.updated_at': new Date()
                }
            });
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'swarm_quote_could_not_be_updated');
        }
    },

    /**
     * Remove a quote from a swarm
     *
     * @param {String} swarmId
     * @param {String} quoteId
     */
    'swarms.remove_quote': function(swarmId, quoteId) {
        check(swarmId, String);
        check(quoteId, String);

        var user = Meteor.user();
        if (!user || !User(user).isAdmin() || !User(user).isSwarmAdmin(swarmId)) {
            throw new Meteor.Error(401, 'unauthorized');
        }

        try {
            Swarms.update({_id: swarmId, 'quotes._id': quoteId}, {$pull: {quotes: {_id: quoteId}}});
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'swarm_quote_could_not_be_removed');
        }
    },

    /**
     * Find related uppers for a specific user
     *
     * @param {String} swarmSlug
     * @param {Number} amount
     */
    'swarms.get_related_uppers': function(swarmSlug, amount) {
        check(swarmSlug, String);

        amount = amount || 16;

        try {
            var swarm = Swarms.findOneOrFail({slug: swarmSlug}, {fields: {networks: 1}});
            var swarm_networks = swarm.networks || [];
            var swarm_uppers = [];

            // Get all the uppers of the swarm in one array
            swarm_networks.forEach(function(networkId) {
                var network = Networks.findOne(networkId, {fields: {uppers: 1}});
                var network_uppers = network.uppers || [];
                swarm_uppers.push.apply(swarm_uppers, network_uppers);
            });

            // Create empty list for the following actions
            var upper_list = [];

            // Now do something with the uppers depending if the current user is logged in or not
            var upper = Meteor.user();

            if (!upper) {
                // User is not logged in, so return random uppers from swarm
                upper_list = swarm_uppers;
            } else {
                // User is logged in, so get a list of all uppers of the current user's partups
                var upper_partup_uppers = [];
                var upper_partups = upper.upperOf || [];
                upper_partups.forEach(function(partupId) {
                    var partup = Partups.findOne(partupId, {fields: {uppers: 1}});
                    var partup_uppers = partup.uppers || [];
                    upper_partup_uppers.push.apply(upper_partup_uppers, partup_uppers);
                });

                // We now have a list of all 'known' uppers and a list of all swarm uppers, so we need to match them
                upper_list = lodash.intersection(swarm_uppers, upper_partup_uppers);

                // Check if we have enough uppers
                if (upper_list.length < amount) {
                    // Append swarm uppers list
                    upper_list.push.apply(upper_list, swarm_uppers);
                }
            }

            // Shorten the list if there are not enough uppers
            if (upper_list.length < amount) amount = upper_list.length;

            // Initialize response
            var related_uppers = [];

            // Randomize the list
            for (var i = 0; i < amount; i++) {
                var random_index = Math.floor(Math.random() * upper_list.length);
                // Store the random upper
                related_uppers.push(upper_list[random_index]);

                // We don't want duplicate uppers in our list, so remove them from source
                upper_list.splice(random_index, 1);
            }

            // Remove duplicates
            related_uppers = lodash.unique(related_uppers);

            // Create response
            var response = [];
            Meteor.users.find({_id: {$in: related_uppers}}).fetch().forEach(function(upper) {
                response.push({
                    _id: upper._id,
                    image: upper.profile.image
                });
            });

            // And there we have it
            return response;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'related_uppers_could_not_be_given');
        }
    },

    /**
     * Find related uppers for a specific user
     *
     * @param {String} swarmSlug
     */
    'swarms.get_related_networks': function(swarmSlug) {
        check(swarmSlug, String);

        try {
            var swarm = Swarms.findOneOrFail({slug: swarmSlug});
            var swarm_networks = swarm.networks || [];

            var upper = Meteor.user();
            if (!upper) return swarm_networks;
            var upper_tags = upper.tags || [];

            // Loop through networks to sort by common tags
            return swarm_networks
                .sort(function(networkId) {
                    var network = Networks.findOne(networkId);
                    var network_tags = network.tags || [];
                    return lodash.intersection(upper_tags, network_tags).length;
                });
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'related_networks_could_not_be_given');
        }
    },

    /**
     * Check to see if a swarm with the swarmSlug parameter exists
     *
     * @param {String} slug
     */
    'swarms.slug_is_swarm_or_network': function(slug) {
        check(slug, String);
        var swarm = Swarms.findOne({slug: slug});
        var network = Networks.findOne({slug: slug});
        return {
            is_swarm: swarm ? true : false,
            is_network: network ? true : false
        };
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/contentblocks/contentblocks_methods.js                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert a contentBlock
     *
     * @param {mixed[]} fields
     */
    'contentblocks.insert': function(fields) {
        check(fields, Partup.schemas.forms.contentBlock);

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        try {
            var contentBlockData = Partup.transformers.contentBlock.fromFormContentBlock(fields);
            contentBlockData._id = Random.id();

            ContentBlocks.insert(contentBlockData);

            return {
                _id: contentBlockData._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'contentblock_could_not_be_inserted');
        }
    },

    /**
     * Update a contentBlock
     *
     * @param {String} contentBlockId
     * @param {mixed[]} fields
     */
    'contentblocks.update': function(contentBlockId, fields) {
        check(contentBlockId, String);
        check(fields, Partup.schemas.forms.contentBlock);

        var upper = Meteor.user();
        if (!upper) throw new Meteor.Error(401, 'unauthorized');

        try {
            var contentBlockData = Partup.transformers.contentBlock.fromFormContentBlock(fields);

            ContentBlocks.update(contentBlockId, {$set: contentBlockData});

            return {
                _id: contentBlockData._id
            };
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'contentblock_could_not_be_updated');
        }
    },

    /**
     * Remove a contentBlock
     *
     * @param {String} contentBlockId
     */
    'contentblocks.remove': function(contentBlockId) {
        check(contentBlockId, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            ContentBlocks.remove({_id: contentBlockId});
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'contentblock_could_not_be_removed');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/chats/chats_methods.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert a chat
     *
     * @param {mixed[]} fields
     */
    'chats.insert': function(fields) {
        check(fields, Partup.schemas.forms.chat);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            var chat = {
                _id: Random.id(),
                created_at: new Date(),
                started_typing: [],
                updated_at: new Date()
            };

            Chats.insert(chat);

            return chat._id;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'chat_could_not_be_inserted');
        }
    },

    /**
     * Set current user as started typing
     *
     * @param {String} chatId
     * @param {Date} typingDate
     */
    'chats.started_typing': function(chatId, typingDate) {
        check(chatId, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            var chat = Chats.findOneOrFail(chatId);
            chat.startedTyping(user._id, typingDate);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'chats_started_typing_could_not_be_updated');
        }
    },

    /**
     * Set current user as started typing
     *
     * @param {String} chatId
     */
    'chats.stopped_typing': function(chatId) {
        check(chatId, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            var chat = Chats.findOneOrFail(chatId);
            chat.stoppedTyping(user._id);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'chats_started_typing_could_not_be_updated');
        }
    },

    /**
     * Start a chat with the provided users
     */
    'chats.start_with_users': function(userIds) {
        check(userIds, [String]);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');
        var chatId = undefined;

        // Don't allow chat's with yourself
        if (userIds.indexOf(user._id) > -1) throw new Meteor.Error(400, 'chat_could_not_be_started');

        try {
            // If the chat is with 1 user then check if there is already a chat going on
            if (userIds.length < 2) {
                var userChats = user.chats || [];
                var recipient = Meteor.users.findOne({chats: {$in: userChats}, _id: {$in: userIds, $ne: user._id}});
                if (recipient) {
                    return lodash.intersection(userChats, recipient.chats)[0];
                }
            }

            chatId = Meteor.call('chats.insert', {});
            Chats.update(chatId, {$set: {creator_id: user._id}});
            userIds.unshift(user._id);
            Meteor.users.update({_id: {$in: userIds}}, {$push: {chats: chatId}}, {multi: true});

            return chatId;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'chat_could_not_be_started');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/methods/chatmessages/chatmessages_methods.js                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Meteor.methods({
    /**
     * Insert a chat message in the chat
     *
     * @param {mixed[]} fields
     */
    'chatmessages.insert': function(fields) {
        check(fields, Partup.schemas.forms.chatMessage);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            var chatMessage = {
                _id: Random.id(),
                chat_id: fields.chat_id,
                content: fields.content,
                created_at: new Date(),
                creator_id: user._id,
                read_by: [],
                seen_by: [],
                updated_at: new Date()
            };

            // Insert message
            ChatMessages.insert(chatMessage);

            // Update the chat
            Chats.update(fields.chat_id, {$set: {updated_at: new Date()}});

            return chatMessage._id;
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'chatmessage_could_not_be_inserted');
        }
    },

    /**
     * Remove a chat message from the chat
     *
     * @param {String} chatMessageId
     */
    'chatmessages.remove': function(chatMessageId) {
        check(chatMessageId, String);

        var user = Meteor.user();
        var chatMessage = ChatMessages.findOne(chatMessageId);
        if (!user || !chatMessage || chatMessage.creator_id !== user._id) throw new Meteor.Error(401, 'unauthorized');

        try {
            ChatMessages.remove(chatMessage._id);
        } catch (error) {
            throw new Meteor.Error(400, 'chatmessage_could_not_be_deleted');
        }
    },

    /**
     * Add upper to seen list
     *
     * @param {String} chatMessageId
     */
    'chatmessages.seen': function(chatMessageId) {
        check(chatMessageId, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            var chatMessage = ChatMessages.findOne(chatMessageId);
            chatMessage.addToSeen(user._id);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'chatmessage_could_not_be_inserted');
        }
    },

    /**
     * Add upper to read list (and automatically to seen)
     *
     * @param {String} chatMessageId
     */
    'chatmessages.read': function(chatMessageId) {
        check(chatMessageId, String);

        var user = Meteor.user();
        if (!user) throw new Meteor.Error(401, 'unauthorized');

        try {
            var chatMessage = ChatMessages.findOne(chatMessageId);
            chatMessage.addToSeen(user._id);
            chatMessage.addToRead(user._id);
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'chatmessage_could_not_be_inserted');
        }
    },

    /**
     * Search chatmessages in a network
     *
     * @param {String} networkSlug
     * @param {String} query
     * @param {Object} options
     */
    'chatmessages.search_in_network': function(networkSlug, query, options) {
        // Temp disable
        return;

        check(networkSlug, String);
        check(query, String);
        check(options, {
            limit: Match.Optional(Number),
            skip: Match.Optional(Number)
        });

        var user = Meteor.user();
        var network = Networks.findOneOrFail({slug: networkSlug});
        if (!user || !network.hasMember(user._id)) throw new Meteor.Error(401, 'unauthorized');

        try {
            return ChatMessages.find({content: new RegExp('.*' + query + '.*', 'i')}, options).fetch();
        } catch (error) {
            Log.error(error);
            throw new Meteor.Error(400, 'chatmessages_could_not_be_searched');
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/reset_clicks_per_hour.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if(process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Reset the clicks per hour on partups',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_RESET_CLICKS);
        },
        job: function() {
            var hour = (new Date).getHours();

            var data = {};
            data['analytics.clicks_per_hour.' + hour] = 0;

            Partups.update({}, {$set: data}, {multi: true});
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/calculate_partup_participation_score_for_users.js                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if(process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Calculate the Part-up participation score for users',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_PARTICIPATION);
        },
        job: function() {
            // TODO: Smarter way to do this, most likely not everyone
            // needs a Part-up participation score calculation
            Meteor.users.find({}).forEach(function(user) {
                var score = Partup.server.services.participation_calculator.calculateParticipationScoreForUpper(user._id);
                Meteor.users.update(user._id, {'$set': {participation_score: score}});
            });
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/calculate_partup_progress_score_for_partups.js                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if(process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Calculate the Part-up progress score for partups',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_PROGRESS);
        },
        job: function() {
            // TODO: Smarter way to do this, most likely not all
            // partups need a progress score calculation
            Partups.find({}).forEach(function(partup) {
                var score = Partup.server.services.partup_progress_calculator.calculatePartupProgressScore(partup._id);
                Partups.update(partup._id, {'$set': {progress: score}});
            });
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/send_ratings_reminder_notification.js                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if(process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Send a notification to partners when the partup is nearing the end date to remind them to rate contributions in the partup',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_ENDDATE_REMINDER);
        },
        job: function() {
            var selector = {
                'flags.ratingReminderNotificationHasBeenSend': {$exists: false},
                'end_date': {'$gt': new Date}
            };

            Partups.find(selector).forEach(function(partup) {
                var flags = partup.flags || {};

                var day = 1000 * 60 * 60 * 24;

                var now = new Date();
                var endsAt = new Date(partup.end_date);
                var createdAt = new Date(partup.created_at);

                var daysTotal = (endsAt - createdAt) / day;
                var daysExists = (now - createdAt) / day;

                var percentage = (daysExists / daysTotal) * 100;

                if (percentage > 75) {
                    var notificationOptions = {
                        type: 'partups_ratings_reminder',
                        typeData: {
                            partup: {
                                _id: partup._id,
                                name: partup.name,
                                slug: partup.slug
                            }
                        }
                    };

                    // Send a notification to each partner of the partup
                    var uppers = partup.uppers || [];
                    uppers.forEach(function(partnerId) {
                        notificationOptions.userId = partnerId;
                        Partup.server.services.notifications.send(notificationOptions);
                    });

                    // Set a flag that the reminders have been send
                    flags.ratingReminderNotificationHasBeenSend = true;
                    Partups.update(partup._id, {'$set': {'flags': flags}});
                }
            });
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/send_daily_digest_users.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if(process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Send daily notification email digest',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_DIGEST);
        },
        job: function() {
            var counter = 0;
            Meteor.users.find({
                'flags.dailyDigestEmailHasBeenSent': false,
                'profile.settings.email.dailydigest': true
            }).forEach(function(user) {
                // This cronjob fails if a mail address doesn't exist. So check on this first.
                if (!User(user).getEmail()) {
                    Log.debug('DailyDigest job: no email found for user ' + user._id);
                    return;
                }

                var newNotifications = Notifications.findForUser(user, {'new': true}).fetch();
                if (newNotifications.length > 0) {

                    // Set the email details
                    var emailOptions = {
                        type: 'dailydigest',
                        toAddress: User(user).getEmail(),
                        subject: TAPi18n.__('emails-dailydigest-subject', {}, User(user).getLocale()),
                        locale: User(user).getLocale(),
                        typeData: {
                            name: User(user).getFirstname(),
                            notificationCount: newNotifications.length,
                            url: Meteor.absoluteUrl(),
                            unsubscribeOneUrl: Meteor.absoluteUrl() + 'unsubscribe-email-one/dailydigest/' + user.profile.settings.unsubscribe_email_token,
                            unsubscribeAllUrl: Meteor.absoluteUrl() + 'unsubscribe-email-all/' + user.profile.settings.unsubscribe_email_token
                        },
                        userEmailPreferences: user.profile.settings.email
                    };

                    // Send the email
                    Partup.server.services.emails.send(emailOptions);

                    Meteor.users.update(user._id, {'$set': {'flags.dailyDigestEmailHasBeenSent': true}});
                    counter++;
                }
            });
            console.log(counter + ' users were mailed with notification digest');
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/update_shared_count.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if(process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Update the shared counts of a partup from different socials',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_SHARED_COUNTS);
        },
        job: function() {
            if (!process.env.NODE_ENV.match(/development/)) {
                Partups.find({}, {sort: {refreshed_at: 1}, limit: 10}).forEach(function(partup) {
                    var counts = {
                        facebook: Partup.server.services.shared_count.facebook(Meteor.absoluteUrl() + 'partups/' + partup.slug),
                        twitter: Partup.server.services.shared_count.twitter(Meteor.absoluteUrl() + 'partups/' + partup.slug),
                        linkedin: Partup.server.services.shared_count.linkedin(Meteor.absoluteUrl() + 'partups/' + partup.slug)
                    };

                    Partups.update(partup._id, {
                        $set: {
                            'shared_count.facebook': counts.facebook,
                            'shared_count.twitter': counts.twitter,
                            'shared_count.linkedin': counts.linkedin,
                            refreshed_at: new Date()
                        }
                    });
                });
            }
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/calculate_partup_popularity_score_for_partups.js                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if(process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Calculate the Part-up popularity score for partups',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_POPULARITY);
        },
        job: function() {
            Partups.find({}).forEach(function(partup) {
                var score = Partup.server.services.partup_popularity_calculator.calculatePartupPopularityScore(partup._id);
                Partups.update(partup._id, {'$set': {popularity: score}});
            });
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/update_swarm_shared_count.js                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if(process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Update the shared counts of a swarm from different socials',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_SWARM_SHARED_COUNTS);
        },
        job: function() {
            if (!process.env.NODE_ENV.match(/development/)) {
                Swarms.find({}, {sort: {refreshed_at: 1}, limit: 10}).forEach(function(swarm) {
                    var counts = {
                        facebook: Partup.server.services.shared_count.facebook(Meteor.absoluteUrl() + swarm.slug),
                        twitter: Partup.server.services.shared_count.twitter(Meteor.absoluteUrl() + swarm.slug),
                        linkedin: Partup.server.services.shared_count.linkedin(Meteor.absoluteUrl() + swarm.slug)
                    };

                    Swarms.update(swarm._id, {
                        $set: {
                            'shared_count.facebook': counts.facebook,
                            'shared_count.twitter': counts.twitter,
                            'shared_count.linkedin': counts.linkedin,
                            refreshed_at: new Date()
                        }
                    });
                });
            }
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/update_swarm_network_stats.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Update the swarm and network stats of Part-up',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_UPDATE_SWARM_NETWORK_STATS);
        },
        job: function() {
            var updated_networks = [];

            // Let's begin with the swarms
            Swarms.find().forEach(function(swarm) {
                var swarm_networks = Partup.server.services.swarms.updateStats(swarm);
                updated_networks.push.apply(updated_networks, swarm_networks);
            });

            // Now update the networks that aren't in a network
            Networks.find({_id: {$nin: updated_networks}}).forEach(function(networkId) {
                var network = Networks.findOne(networkId);
                Partup.server.services.networks.updateStats(network);
            });
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/calculate_active_network_uppers_partups.js                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Calculate the most active uppers and partups of all networks',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_CALCULATE_ACTIVE_NETWORK_UPPERS_PARTUPS);
        },
        job: function() {
            Networks.find().forEach(function(network) {
                Partup.server.services.networks.calculateActiveUppers(network);
                Partup.server.services.networks.calculateActivePartups(network);
            });
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/get_common_network_tags.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (process.env.PARTUP_CRON_ENABLED) {
    SyncedCron.add({
        name: 'Create tags that are common in the underlying partups of the network',
        schedule: function(parser) {
            return parser.text(Partup.constants.CRON_GET_COMMON_NETWORK_TAGS);
        },
        job: function() {
            Networks.find().forEach(function(network) {
                Partup.server.services.networks.getCommonTags(network);
            });
        }
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/cron/push_apple_cleanup_devices.js                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
'use strict';

var apn = Npm.require('apn');

if (process.env.PARTUP_CRON_ENABLED && process.env.PUSH_APPLE_APN_PFX) {
    var feedback = new apn.Feedback({
        pfx: new Buffer(process.env.PUSH_APPLE_APN_PFX, 'base64'),
        batchFeedback: true,
        interval: Partup.constants.PUSH_APPLE_APN_CLEANUP_INTERVAL
    });

    console.log('Listening to apple push notification feedback');

    feedback.on('feedback', Meteor.bindEnvironment(function(devices) {
        var ids = devices.map(function(item) {
            return item.device.token.toString('hex');
        });

        if (ids.length > 0) {
            Meteor.users.update({
                'push_notification_devices.registration_id': {$in: ids}
            }, {
                $pull: {
                    'push_notification_devices': {
                        registration_id: {$in: ids}
                    }
                }
            });
        }
    }));
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/migrations.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Migrations.add({
    version: 1,
    name: 'Copy all inserted user and partup tags to Tags collection.',
    up: function() {
        var tags = [];

        // Collect all tags from user profiles
        Meteor.users.find().fetch().forEach(function(user) {
            if (user.tags !== undefined) {
                user.tags.forEach(function(tag) {
                    tags.push(tag.toLocaleLowerCase());
                });
            }
        });

        // Collect all tags from partups
        Partups.find().fetch().forEach(function(partup) {
            if (partup.tags !== undefined) {
                partup.tags.forEach(function(tag) {
                    tags.push(tag.toLocaleLowerCase());
                });
            }
        });

        // Remove duplicates
        var uniqueTags = tags.filter(function(elem, pos) {
            return tags.indexOf(elem) == pos;
        });

        // Now insert all collected tags into the database
        uniqueTags.forEach(function(tag) {
            var trimmedTag = tag.trim(); // Some tags had leading or trailing spaces
            if (!Tags.findOne({_id: trimmedTag})) {
                Tags.insert({_id: trimmedTag});
            }
        });

        Log.debug(uniqueTags.length + ' tags inserted in Tags collection.');
    },
    down: function() {
        // Code to migrate to previous version
    }
});

Migrations.add({
    version: 2,
    name: 'Save old images to new image stores',
    up: function() {
        console.log('Save old images to new image stores');
        Images.find().fetch().forEach(function(image) {
            if (image.copies['32x32'].size === 0) {
                console.log('creating 32x32 image: ' + image.name());
                var readStream = image.createReadStream('original');
                var writeStream = image.createWriteStream('32x32');
                gm(readStream, image.name()).resize(32, 32).stream().pipe(writeStream);
            }
            if (image.copies['80x80'].size === 0) {
                console.log('creating 80x80 image: ' + image.name());
                var readStream = image.createReadStream('original');
                var writeStream = image.createWriteStream('80x80');
                gm(readStream, image.name()).resize(80, 80).stream().pipe(writeStream);
            }
        });
    },
    down: function() {
    }
});

Migrations.add({
    version: 3,
    name: 'Add a slug to the existing Partups',
    up: function() {
        var partups = Partups.find({slug: {$exists: false}});

        partups.forEach(function(partup) {
            var slug = Partup.server.services.slugify.slugifyDocument(partup, 'name');
            Partups.update({_id:partup._id}, {$set: {slug: slug}});
        });
    },
    down: function() {
        Partups.update({slug: {$exists: true}}, {$unset: {slug: ''}}, {multi: true});
    }
});

Migrations.add({
    version: 4,
    name: 'Add a slug to the existing Networks',
    up: function() {
        var networks = Networks.find({slug: {$exists: false}});

        networks.forEach(function(network) {
            var slug = Partup.server.services.slugify.slugify(network.name);
            Networks.update({_id:network._id}, {$set: {slug: slug}});
        });
    },
    down: function() {
        Networks.update({slug: {$exists: true}}, {$unset: {slug: ''}}, {multi: true});
    }
});

Migrations.add({
    version: 5,
    name: 'Rename the user.profile.<social> fields to user.profile.<social>_url and prefix their values with i.e. https://facebook.com/. Also delete all linkedin_id fields.',
    up: function() {
        Meteor.users.find().forEach(function(user) {
            if (!user || !user.profile) return;

            if (user.profile.facebook) {
                user.profile.facebook_url = 'https://facebook.com/' + user.profile.facebook;
            }

            if (user.profile.instagram) {
                user.profile.instagram_url = 'https://instagram.com/' + user.profile.instagram;
            }

            if (user.profile.twitter) {
                user.profile.twitter_url = 'https://twitter.com/' + user.profile.twitter;
            }

            if (user.profile.linkedin) {
                user.profile.linkedin_url = 'https://linkedin.com/in/' + user.profile.linkedin;
            }

            if (user.profile.linkedin_id) {
                delete user.profile.linkedin_id;
            }

            Meteor.users.update({_id: user._id}, {$set: {'profile': user.profile}});
        });
    },
    down: function() {
        Meteor.users.find().forEach(function(user) {
            if (!user || !user.profile) return;

            if (user.profile.facebook_url) {
                delete user.profile.facebook_url;
            }

            if (user.profile.instagram_url) {
                delete user.profile.instagram_url;
            }

            if (user.profile.twitter_url) {
                delete user.profile.twitter_url;
            }

            if (user.profile.linkedin_url) {
                delete user.profile.linkedin_url;
            }

            Meteor.users.update({_id: user._id}, {$set: {'profile': user.profile}});
        });
    }
});

Migrations.add({
    version: 6,
    name: 'Calculate the Part-up participation score for users',
    up: function() {
        // TODO: Smarter way to do this, most likely not everyone
        // needs a Part-up participation score calculation
        Meteor.users.find({participation_score: {$exists: false}}).forEach(function(user) {
            var score = Partup.server.services.participation_calculator.calculateParticipationScoreForUpper(user._id);
            Meteor.users.update(user._id, {$set: {participation_score: score}});
        });
    },
    down: function() {
        Meteor.users.update({participation_score: {$exists: true}}, {$unset: {participation_score: ''}}, {multi: true});
    }
});

Migrations.add({
    version: 7,
    name: 'Calculate the Part-up progress score for partups',
    up: function() {
        // TODO: Smarter way to do this, most likely not all
        // partups need a progress score calculation
        Partups.find({progress: {$exists: false}}).forEach(function(partup) {
            var score = Partup.server.services.partup_progress_calculator.calculatePartupProgressScore(partup._id);
            Partups.update(partup._id, {'$set': {progress: score}});
        });
    },
    down: function() {
        Partups.update({progress: {$exists: true}}, {$unset: {progress: ''}}, {multi: true});
    }
});

Migrations.add({
    version: 8,
    name: 'Remove all notifications because they are incompatible at this point',
    up: function() {
        Notifications.remove({});
    },
    down: function() {
        // Nothing to do
    }
});

Migrations.add({
    version: 9,
    name: 'Remove duplicate IDs in user/partup/network arrays',
    up: function() {
        // Define the names of the user properties that contain arrays
        var arrayLists = ['supporterOf', 'upperOf', 'networks', 'pending_networks'];
        // Now go through all users and remove duplicate entries
        Meteor.users.find().fetch().forEach(function(user) {
            arrayLists.forEach(function(arrayList) {
                if (user[arrayList]) {
                    var uniqueValues = lodash.unique(user[arrayList]);
                    var setModifier = {$set: {}};
                    setModifier.$set[arrayList] = uniqueValues;
                    Meteor.users.update({_id: user._id}, setModifier);
                }
            });
        });

        // Repeat the above steps for partups and networks
        arrayLists = ['supporters', 'uppers', 'invites'];
        Partups.find().fetch().forEach(function(partup) {
            arrayLists.forEach(function(arrayList) {
                if (partup[arrayList]) {
                    var uniqueValues = lodash.unique(partup[arrayList]);
                    var setModifier = {$set: {}};
                    setModifier.$set[arrayList] = uniqueValues;
                    Partups.update({_id: partup._id}, setModifier);
                }
            });
        });

        arrayLists = ['uppers', 'pending_uppers'];
        Networks.find().fetch().forEach(function(network) {
            arrayLists.forEach(function(arrayList) {
                if (network[arrayList]) {
                    var uniqueValues = lodash.unique(network[arrayList]);
                    var setModifier = {$set: {}};
                    setModifier.$set[arrayList] = uniqueValues;
                    Networks.update({_id: network._id}, setModifier);
                }
            });
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 10,
    name: 'Add flags and email settings to existing users',
    up: function() {
        Meteor.users.update({}, {
            '$set': {
                'flags.dailyDigestEmailHasBeenSent': false,
                'profile.settings.email.dailydigest': true
            }
        }, {multi:true});
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 11,
    name: 'Set language on all current partups and networks',
    up: function() {
        Partups.find().fetch().forEach(function(partup) {
            if (!partup.language) {
                var language = Partup.server.services.google.detectLanguage(partup.description);
                Log.debug('Setting language *' + language + '* for Partup "' + partup.name + '"');
                Partups.update({_id: partup._id}, {$set: {language: language}});
            }
        });
        Networks.find().fetch().forEach(function(network) {
            if (!network.language) {
                var language = Partup.server.services.google.detectLanguage(network.description);
                Log.debug('Setting language *' + language + '* for Network "' + network.name + '"');
                Networks.update({_id: network._id}, {$set: {language: language}});
            }
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 12,
    name: 'Set unsubscribe email token for all users',
    up: function() {
        Meteor.users.find().forEach(function(user) {
            var token = Random.secret();
            Meteor.users.update(user._id, {$set: {'profile.settings.unsubscribe_email_token': token}});
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 13,
    name: 'Set default email notification setting',
    up: function() {
        Meteor.users.find().forEach(function(user) {
            Meteor.users.update(user._id, {$set: {
                'profile.settings.email.upper_mentioned_in_partup': true,
                'profile.settings.email.invite_upper_to_partup_activity': true,
                'profile.settings.email.invite_upper_to_network': true,
                'profile.settings.email.partup_created_in_network': true
            }});
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 14,
    name: 'Download profile pictures for facebook and linkedin users',
    up: function() {
        var setRandomUserImage = function(user) {
            var images = Images.find({'meta.default_profile_picture': true}).fetch();
            image = mout.random.choice(images);
            Meteor.users.update(user._id, {$set:{'profile.image': image._id}});
        };

        var downloadAndSetUserImage = function(user, imageUrl) {
            if (!imageUrl) return setRandomUserImage(user);

            try {
                var result = HTTP.get(imageUrl, {'npmRequestOptions': {'encoding': null}});
                var body = new Buffer(result.content, 'binary');

                var image = Partup.server.services.images.upload(user._id + '.jpg', body, 'image/jpeg');

                return Meteor.users.update(user._id, {$set:{'profile.image': image._id}});
            } catch (error) {
                console.log(error);
                setRandomUserImage(user);
            }
        };

        // Username + password users
        Meteor.users.find({'services.password': {$exists: true}}).forEach(function(user) {
            setRandomUserImage(user);
        });

        // Facebook users
        Meteor.users.find({'services.facebook': {$exists: true}}).forEach(function(user) {
            var url = 'https://graph.facebook.com/' + user.services.facebook.id + '/picture?width=750';
            downloadAndSetUserImage(user, url);
        });

        // LinkedIn users
        Meteor.users.find({'services.linkedin': {$exists: true}}).forEach(function(user) {
            var url = user.services.linkedin.pictureUrl;
            downloadAndSetUserImage(user, url);
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 15,
    name: 'Set default partup picture on all partups',
    up: function() {
        Partups.find({}).forEach(function(partup) {
            var images = Images.find({'meta.default_partup_picture': true}).fetch();
            image = mout.random.choice(images);
            Partups.update(partup._id, {$set:{'image': image._id}});
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 16,
    name: 'Re-added migration 11 for language errors, and update the indices',
    up: function() {
        // Fix the indices
        Partups._dropIndex('name_text_description_text');
        Partups._ensureIndex({'name': 'text', 'description': 'text'}, {language_override: 'idioma'});

        Partups.find().fetch().forEach(function(partup) {
            if (!partup.language) {
                var language = Partup.server.services.google.detectLanguage(partup.description);
                Log.debug('Setting language *' + language + '* for Partup "' + partup.name + '"');
                Partups.update({_id: partup._id}, {$set: {language: language}});
            }
        });
        Networks.find().fetch().forEach(function(network) {
            if (!network.language) {
                var language = Partup.server.services.google.detectLanguage(network.description);
                Log.debug('Setting language *' + language + '* for Network "' + network.name + '"');
                Networks.update({_id: network._id}, {$set: {language: language}});
            }
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 17,
    name: 'Set new email notification setting',
    up: function() {
        Meteor.users.find().forEach(function(user) {
            Meteor.users.update(user._id, {$set: {
                'profile.settings.email.partups_networks_new_pending_upper': true,
                'profile.settings.email.partups_networks_accepted': true
            }});
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 18,
    name: 'Update hard-coded images in notifications',
    up: function() {
        Notifications.find().forEach(function(notification) {
            var set = {};

            if (!notification.type_data) return;

            // Creator
            if (notification.type_data.creator) {
                var creator = Meteor.users.findOne({_id: notification.type_data.creator._id});
                if (creator) {
                    set['type_data.creator.image'] = creator.profile.image;
                }
            }

            // Inviter
            if (notification.type_data.inviter) {
                var inviter = Meteor.users.findOne({_id: notification.type_data.inviter._id});
                if (inviter) {
                    set['type_data.inviter.image'] = inviter.profile.image;
                }
            }

            // Accepter
            if (notification.type_data.accepter) {
                var accepter = Meteor.users.findOne({_id: notification.type_data.accepter._id});
                if (accepter) {
                    set['type_data.accepter.image'] = accepter.profile.image;
                }
            }

            // Rejecter
            if (notification.type_data.rejecter) {
                var rejecter = Meteor.users.findOne({_id: notification.type_data.rejecter._id});
                if (rejecter) {
                    set['type_data.rejecter.image'] = rejecter.profile.image;
                }
            }

            // Supporter
            if (notification.type_data.supporter) {
                var supporter = Meteor.users.findOne({_id: notification.type_data.supporter._id});
                if (supporter) {
                    set['type_data.supporter.image'] = supporter.profile.image;
                }
            }

            // Pending upper
            if (notification.type_data.pending_upper) {
                var pending_upper = Meteor.users.findOne({_id: notification.type_data.pending_upper._id});
                if (pending_upper) {
                    set['type_data.pending_upper.image'] = pending_upper.profile.image;
                }
            }

            // Rater
            if (notification.type_data.rater) {
                var rater = Meteor.users.findOne({_id: notification.type_data.rater._id});
                if (rater) {
                    set['type_data.rater.image'] = rater.profile.image;
                }
            }

            // Commenter
            if (notification.type_data.commenter) {
                var commenter = Meteor.users.findOne({_id: notification.type_data.commenter._id});
                if (commenter) {
                    set['type_data.commenter.image'] = commenter.profile.image;
                }
            }

            // Mentioning upper
            if (notification.type_data.mentioning_upper) {
                var mentioning_upper = Meteor.users.findOne({_id: notification.type_data.mentioning_upper._id});
                if (mentioning_upper) {
                    set['type_data.mentioning_upper.image'] = mentioning_upper.profile.image;
                }
            }

            // Partup
            if (notification.type_data.partup) {
                var partup = Partups.findOne({_id: notification.type_data.partup._id});
                if (partup) {
                    set['type_data.partup.image'] = partup.image;
                }
            }

            // Network
            if (notification.type_data.network) {
                var network = Networks.findOne({_id: notification.type_data.network._id});
                if (network) {
                    set['type_data.network.image'] = network.image;
                }
            }

            if (Object.keys(set).length > 0) {
                Notifications.update(notification._id, {$set: set});
            }

        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 19,
    name: 'Set a normalized name for each user to also show accented names in search query',
    up: function() {
        Meteor.users.find().forEach(function(user) {
            Meteor.users.update(user._id, {$set: {
                'profile.normalized_name': Partup.helpers.normalize(user.profile.name)
            }});
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 20,
    name: 'Make an upper_data object for all partners/supporters of a partup',
    up: function() {
        Partups.find({}).forEach(function(partup) {
            partup.getUsers().forEach(function(upperId) {
                // Set data object for new partners/supporters
                partup.createUpperDataObject(upperId);
            });
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 21,
    name: 'Convert old partup budget types to new ones',
    up: function() {
        Partups.find({}).forEach(function(partup) {
            if (partup.budget_type && partup.budget_type === 'money') {
                Partups.update({_id: partup._id}, {$set: {
                    type: Partups.TYPE.COMMERCIAL,
                    type_commercial_budget: partup.budget_money,
                    type_organization_budget: null
                }, $unset: {
                    budget_type: '',
                    budget_money: '',
                    budget_hours: ''
                }});
            } else if (partup.budget_type && partup.budget_type === 'hours') {
                Partups.update({_id: partup._id}, {$set: {
                    type: Partups.TYPE.ORGANIZATION,
                    type_commercial_budget: null,
                    type_organization_budget: partup.budget_hours
                }, $unset: {
                    budget_type: '',
                    budget_money: '',
                    budget_hours: ''
                }});
            } else if (partup.budget_type === null) {
                Partups.update({_id: partup._id}, {$set: {
                    type: Partups.TYPE.CHARITY,
                    type_commercial_budget: null,
                    type_organization_budget: null
                }, $unset: {
                    budget_type: '',
                    budget_money: '',
                    budget_hours: ''
                }});
            }
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 22,
    name: 'Add new email settings to existing users',
    up: function() {
        Meteor.users.update({}, {
            '$set': {
                'profile.settings.email.invite_upper_to_partup': true
            }
        }, {multi:true});
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 23,
    name: 'Add refreshed_at property to partups',
    up: function() {
        Partups.update({}, {
            $set: {
                refreshed_at: new Date()
            }
        }, {multi:true});
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 24,
    name: 'Gather and store all part-up languages so far',
    up: function() {
        var languages = [];
        Partups.find({}).forEach(function(partup) {
            languages.push(partup.language);
        });

        var uniqueLanguages = lodash.unique(languages);
        uniqueLanguages.forEach(function(languageCode) {
            Partup.server.services.language.addNewLanguage(languageCode);
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 25,
    name: 'Default all contributions and commercial partups to EUR currency',
    up: function() {
        Partups.find({type: Partups.TYPE.COMMERCIAL, currency: {$exists: false}}).forEach(function(partup) {
            Partups.update({_id: partup._id}, {$set: {currency: 'EUR'}});
        });
        Contributions.find({rate: {$ne: null}}, {currency: {$exists: false}}).forEach(function(contribution) {
            Contributions.update({_id: contribution._id}, {$set: {currency: 'EUR'}});
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 26,
    name: 'Update all profiles that have NaN or 0 as completeness score',
    up: function() {
        Meteor.users.find().fetch().forEach(function(user) {
            if (user.completeness > 0 && user.completeness <= 100) return;

            // Update profile completion percentage on users that don't have a valid score
            Partup.server.services.profile_completeness.updateScore(user);
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 27,
    name: 'Move the tiles array from user root object to user.profile',
    up: function() {
        Meteor.users.find().fetch().forEach(function(user) {
            var tiles = user.tiles;
            if (!tiles) return;

            // Update user
            Meteor.users.update(user._id, {$unset: {tiles: ''}, $set: {'profile.tiles': tiles}});
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 28,
    name: 'Add upper_count to network',
    up: function() {
        Networks.find().fetch().forEach(function(network) {
            Networks.update(network._id, {
                $set: {
                    upper_count: (network.uppers || []).length
                }
            });
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 29,
    name: 'Set new email notification setting',
    up: function() {
        Meteor.users.find().forEach(function(user) {
            Meteor.users.update(user._id, {$set: {
                'profile.settings.email.partups_new_comment_in_involved_conversation': true,
                'profile.settings.email.partups_networks_new_upper': true,
                'profile.settings.email.partups_networks_upper_left': true
            }});
        });
    },
    down: function() {
        //
    }
});

Migrations.add({
    version: 30,
    name: 'Convert admin_id string to admins array for all networks',
    up: function() {
        Networks.find().fetch().forEach(function(network) {
            if (!network.admin_id) return;
            Networks.update(network._id, {
                $set: {
                    admins: [network.admin_id]
                },
                $unset: {
                    admin_id: ''
                }
            });
        });
    },
    down: function() {
        //
    }
});

Meteor.startup(function() {
    Migrations.migrateTo(30);
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_server/package-i18n.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
TAPi18n.packages["partup:server"] = {"translation_function_name":"__","helper_name":"_","namespace":"partup:server"};

// define package's translation function (proxy to the i18next)
__ = TAPi18n._getPackageI18nextProxy("partup:server");

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['partup:server'] = {}, {
  Log: Log
});

})();

//# sourceMappingURL=partup_server.js.map
