(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['partup:client-column-tiles-layout'] = {};

})();
