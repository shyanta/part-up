(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var meteorInstall = Package['modules-runtime'].meteorInstall;

/* Package-scope variables */
var Buffer, process;

var require = meteorInstall({"node_modules":{"meteor":{"modules":{"server.js":["./install-packages.js","./buffer.js","./process.js",function(require){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/server.js                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
require("./install-packages.js");
require("./buffer.js");
require("./process.js");

////////////////////////////////////////////////////////////////////////////

}],"buffer.js":["buffer",function(require){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/buffer.js                                             //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
try {
  Buffer = global.Buffer || require("buffer").Buffer;
} catch (noBuffer) {}

////////////////////////////////////////////////////////////////////////////

}],"install-packages.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/install-packages.js                                   //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
function install(name) {
  var meteorDir = {};

  // Given a package name <name>, install a stub module in the
  // /node_modules/meteor directory called <name>.js, so that
  // require.resolve("meteor/<name>") will always return
  // /node_modules/meteor/<name>.js instead of something like
  // /node_modules/meteor/<name>/index.js, in the rare but possible event
  // that the package contains a file called index.js (#6590).
  meteorDir[name + ".js"] = function (r, e, module) {
    module.exports = Package[name];
  };

  meteorInstall({
    node_modules: {
      meteor: meteorDir
    }
  });
}

// This file will be modified during computeJsOutputFilesMap to include
// install(<name>) calls for every Meteor package.

install("underscore");
install("meteor");
install("babel-compiler");
install("ecmascript");
install("modules-runtime");
install("modules");
install("es5-shim");
install("promise");
install("ecmascript-runtime");
install("babel-runtime");
install("random");
install("rate-limit");
install("ddp-rate-limiter");
install("base64");
install("ejson");
install("check");
install("callback-hook");
install("tracker");
install("retry");
install("id-map");
install("ddp-common");
install("diff-sequence");
install("mongo-id");
install("ddp-client");
install("logging");
install("routepolicy");
install("deps");
install("htmljs");
install("html-tools");
install("blaze-tools");
install("spacebars-compiler");
install("jquery");
install("observe-sequence");
install("reactive-var");
install("blaze");
install("spacebars");
install("ui");
install("boilerplate-generator");
install("webapp-hashing");
install("webapp");
install("ordered-dict");
install("geojson-utils");
install("minimongo");
install("ddp-server");
install("ddp");
install("npm-mongo");
install("allow-deny");
install("binary-heap");
install("mongo");
install("accounts-base");
install("service-configuration");
install("localstorage");
install("url");
install("oauth");
install("accounts-oauth");
install("oauth2");
install("http");
install("facebook");
install("accounts-facebook");
install("npm-bcrypt");
install("sha");
install("srp");
install("email");
install("accounts-password");
install("templating");
install("aldeed:simple-schema");
install("aldeed:autoform");
install("aldeed:autoform-bs-datepicker");
install("aldeed:template-extension");
install("anti:fake");
install("browser-policy-common");
install("browser-policy-content");
install("browser-policy-framing");
install("browser-policy");
install("chrismbeckett:toastr");
install("cwaring:modernizr");
install("deepwell:bootstrap-datepicker2");
install("djedi:sanitize-html");
install("dsyko:meteor-node-csv");
install("fastclick");
install("fourseven:scss");
install("coffeescript");
install("raix:eventemitter");
install("meteorspark:util");
install("cfs:http-methods");
install("tap:i18n");
install("francocatena:status");
install("iron:core");
install("iron:dynamic-template");
install("iron:layout");
install("iron:url");
install("iron:middleware-stack");
install("iron:location");
install("reactive-dict");
install("iron:controller");
install("iron:router");
install("lifely:mout");
install("lifelynl:focuspoint");
install("lifelynl:intent");
install("matb33:collection-hooks");
install("meteorhacks:inject-data");
install("meteorhacks:picker");
install("meteorhacks:meteorx");
install("livedata");
install("meteorhacks:fast-render");
install("mongo-livedata");
install("meteorhacks:kadira");
install("meteorhacks:ssr");
install("meteorhacks:subs-manager");
install("meteorhacks:unblock");
install("mizzao:timesync");
install("mizzao:user-status");
install("momentjs:moment");
install("mrt:jquery-mousewheel");
install("okgrow:analytics");
install("pauli:linkedin");
install("pauli:accounts-linkedin");
install("peerlibrary:blocking");
install("peerlibrary:aws-sdk");
install("percolate:intercom");
install("percolate:migrations");
install("percolate:synced-cron");
install("reywood:publish-composite");
install("sergeyt:typeahead");
install("simple:json-routes");
install("simple:rest");
install("splendido:accounts-emails-field");
install("splendido:accounts-meld");
install("stevezhu:lodash");
install("tmeasday:publish-counts");
install("yogiben:autoform-tags");
install("zimme:active-route");
install("partup:newrelic");
install("partup:client-copy-to-clipboard");
install("partup:lib");
install("partup:server");
install("partup:client-base");
install("partup:client-pages");
install("partup:client-admin");
install("partup:client-admin-createtribe");
install("partup:client-admin-featured-networks");
install("partup:client-admin-featured-partups");
install("partup:client-admin-createswarm");
install("partup:client-autocomplete");
install("partup:client-comments");
install("partup:client-contribution");
install("partup:client-dropdown");
install("partup:client-dropdowns");
install("partup:client-focuspoint");
install("partup:client-footer");
install("partup:client-gallery");
install("partup:client-header");
install("partup:client-invite-to-activity");
install("partup:client-invite-to-network");
install("partup:client-loader");
install("partup:client-login");
install("partup:client-network-settings");
install("partup:client-network-settings-bulkinvite");
install("partup:client-network-settings-requests");
install("partup:client-network-settings-uppers");
install("partup:client-partupsettings");
install("partup:client-popup");
install("partup:client-profilesettings");
install("partup:client-prompt");
install("partup:client-rating");
install("partup:client-ratings");
install("partup:client-resetpassword");
install("partup:client-selectors");
install("partup:client-spinner");
install("partup:client-update");
install("partup:client-hover-container");
install("partup:client-upper-tile");
install("partup:meteor-bender");
install("partup:client-invite-to-partup");
install("partup:client-column-tiles-layout");
install("partup:client-forminputs");
install("standard-minifiers");
install("meteor-base");
install("mobile-experience");
install("blaze-html-templates");
install("session");
install("reload");
install("meteorhacks:kadira-binary-deps");
install("meteorhacks:kadira-profiler");
install("partup:client-network-tile");
install("partup:client-google-drive-picker");
install("partup:client-dropbox-chooser");
install("partup:cookie-law-bar");
install("partup:client-network-settings-about");
install("partup:client-network-chat");
install("standard-minifier-css");
install("standard-minifier-js");
install("hot-code-push");
install("launch-screen");
install("autoupdate");
install("mdg:validation-error");

////////////////////////////////////////////////////////////////////////////

},"process.js":["process",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/modules/process.js                                            //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
try {
  // The application can run `npm install process` to provide its own
  // process stub; otherwise this module will provide a partial stub.
  process = global.process || require("process");
} catch (noProcess) {
  process = {};
}

if (Meteor.isServer) {
  // Make require("process") work on the server in all versions of Node.
  meteorInstall({
    node_modules: {
      "process.js": function (r, e, module) {
        module.exports = process;
      }
    }
  });
} else {
  process.platform = "browser";
  process.nextTick = process.nextTick || Meteor._setImmediate;
}

if (typeof process.env !== "object") {
  process.env = {};
}

_.extend(process.env, meteorEnv);

////////////////////////////////////////////////////////////////////////////

}]}}}},{"extensions":[".js",".json"]});
var exports = require("./node_modules/meteor/modules/server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package.modules = exports, {
  meteorInstall: meteorInstall,
  Buffer: Buffer,
  process: process
});

})();

//# sourceMappingURL=modules.js.map
