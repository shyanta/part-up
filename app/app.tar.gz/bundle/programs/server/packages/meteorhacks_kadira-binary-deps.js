(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var KadiraBinaryDeps;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/meteorhacks_kadira-binary-deps/packages/meteorhacks_kadira-bi //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/meteorhacks:kadira-binary-deps/index.js                  //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
KadiraBinaryDeps = {};                                               // 1
KadiraBinaryDeps.require = function(module) {                        // 2
  return Npm.require(module);                                        // 3
};                                                                   // 4
///////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['meteorhacks:kadira-binary-deps'] = {}, {
  KadiraBinaryDeps: KadiraBinaryDeps
});

})();

//# sourceMappingURL=meteorhacks_kadira-binary-deps.js.map
