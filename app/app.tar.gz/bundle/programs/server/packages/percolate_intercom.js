(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;

/* Package-scope variables */
var IntercomClient, IntercomSettings, IntercomHash;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// packages/percolate_intercom/packages/percolate_intercom.js                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                           //
// packages/percolate:intercom/intercom_server.js                                                            //
//                                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                             //
// Generate an intercomHash for secure mode as outlined at                                                   // 1
// https://segment.io/docs/integrations/intercom/#secure-mode                                                // 2
var crypto = Npm.require('crypto');                                                                          // 3
var Intercom = Npm.require('intercom-client');                                                               // 4
                                                                                                             // 5
if (Meteor.settings                                                                                          // 6
   && Meteor.settings.public                                                                                 // 7
   && Meteor.settings.public.intercom                                                                        // 8
   && Meteor.settings.public.intercom.id                                                                     // 9
   && Meteor.settings.intercom                                                                               // 10
   && Meteor.settings.intercom.apikey) {                                                                     // 11
  IntercomClient = new Intercom.Client(Meteor.settings.public.intercom.id, Meteor.settings.intercom.apikey); // 12
}                                                                                                            // 13
                                                                                                             // 14
// returns undefined if there is no secret                                                                   // 15
var IntercomHash =  function(userId) {                                                                       // 16
  var secret = Meteor.settings &&                                                                            // 17
      Meteor.settings.intercom && Meteor.settings.intercom.secret;                                           // 18
                                                                                                             // 19
  if (secret) {                                                                                              // 20
    return crypto.createHmac('sha256', new Buffer(secret, 'utf8'))                                           // 21
      .update(userId).digest('hex');                                                                         // 22
  }                                                                                                          // 23
}                                                                                                            // 24
                                                                                                             // 25
Meteor.publish('currentUserIntercomHash', function() {                                                       // 26
  if (this.userId) {                                                                                         // 27
    var intercomHash = IntercomHash(this.userId);                                                            // 28
                                                                                                             // 29
    if (intercomHash)                                                                                        // 30
      this.added("users", this.userId, {intercomHash: intercomHash});                                        // 31
  }                                                                                                          // 32
  this.ready();                                                                                              // 33
});                                                                                                          // 34
                                                                                                             // 35
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['percolate:intercom'] = {}, {
  IntercomSettings: IntercomSettings,
  IntercomHash: IntercomHash,
  IntercomClient: IntercomClient
});

})();

//# sourceMappingURL=percolate_intercom.js.map
