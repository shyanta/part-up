(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var lodash = Package['stevezhu:lodash'].lodash;
var _ = Package['stevezhu:lodash']._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var moment = Package['momentjs:moment'].moment;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;
var mout = Package['lifely:mout'].mout;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var Iron = Package['iron:core'].Iron;

/* Package-scope variables */
var Partup, Version, get, set, Activities, Invites, Contributions, Update, Updates, Notifications, Partups, results, Images, Ratings, Networks, User, Tags, Places, PlacesAutocompletes, Languages, Tiles, Swarms, ContentBlocks, Chats, ChatMessages, Temp, Uploads;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/namespace.js                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// jscs:disable
/**
 * This package contains all the shared namespaces and polymorphic javascript
 *
 * @module lib
 */
// jscs:enable

/**
 * @namespace Partup
 */
Partup = {};

/**
 @namespace Helpers
 @name Partup.helpers
 @memberof Partup
 */
Partup.helpers = {};

/**
 @namespace Schemas
 @name partup.schemas
 */
Partup.schemas = {
    /**
     @namespace schema.forms namespace
     @name partup.schemas.forms
     */
    forms: {},
    /**
     @namespace schema.entities namespace
     @name partup.schemas.entities
     */
    entities: {}
};

/**
 @namespace partup.services
 */
Partup.services = {};

/**
 @namespace Factories
 @name partup.factories
 */
Partup.factories = {};

/**
 @namespace Transformers
 @name partup.transformers
 */
Partup.transformers = {};

/**
 @namespace Meteor
 */

/**
 @namespace Mongo
 */

/**
 @namespace Collection
 @memberof Mongo
 */

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/version.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @namespace Version
 */
Version = {
    get: function() {
        var now = new Date();
        HTTP.get(Meteor.absoluteUrl('VERSION') + '?' + now.getTime(), function(error, response) {
            if (error || !response) return;

            // Be sure the result is a binary file
            if (response.headers['content-type'] !== 'application/octet-stream') return;

            if (!response.content) return;

            // Parse data
            var parsed_versiondata = JSON.parse(response.content);

            // Log data
            console.info({
                version: parsed_versiondata.version,
                deploydate: parsed_versiondata.deploydate
            });
        });
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/globals.js                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
get = mout.object.get;
set = mout.object.set;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/routes.js                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * This namespace contains router helpers etc
 * @namespace Router
 */
/*************************************************************/
/* Configurations */
/*************************************************************/
Router.configure({
    layoutTemplate: 'main',
    state: function() {
        return {
            type: 'default'
        };
    }
});

/*************************************************************/
/* Home */
/*************************************************************/
Router.route('', {
    name: 'home',
    where: 'client',
    yieldRegions: {
        'app':      {to: 'main'},
        'app_home': {to: 'app'}
    }
});

/*************************************************************/
/* Discover */
/*************************************************************/
Router.route('/discover', {
    name: 'discover',
    where: 'client',
    yieldRegions: {
        'app':          {to: 'main'},
        'app_discover': {to: 'app'}
    }
});

/*************************************************************/
/* Profile */
/*************************************************************/
// this is the fallback profile route when a user changes the url to /profile without an _id
Router.route('/profile', {
    name: 'profile-fallback',
    where: 'client',
    yieldRegions: {
        'app': {to: 'main'},
        'app_profile': {to: 'app'},
        'app_profile_about': {to: 'app_profile'}
    },
    onBeforeAction: function() {
        if (!this.params._id) {
            this.params._id = Meteor.userId();
        }
        this.next();
    },
    data: function() {
        return {
            profileId: this.params._id
        };
    }
});

Router.route('/profile/:_id', {
    name: 'profile',
    where: 'client',
    yieldRegions: {
        'app': {to: 'main'},
        'app_profile': {to: 'app'},
        'app_profile_about': {to: 'app_profile'}
    },
    data: function() {
        return {
            profileId: this.params._id,
            resultsReady: this.params.query.results_ready || false
        };
    },
    onBeforeAction: function() {
        // when `?results_ready=true` this call must be made
        var resultsReady = this.params.query.results_ready || false;
        if (resultsReady) Meteor.call('meurs.get_results', this.params._id);
        this.next();
    }
});

Router.route('/profile/:_id/partner', {
    name: 'profile-upper-partups',
    where: 'client',
    yieldRegions: {
        'app': {to: 'main'},
        'app_profile': {to: 'app'},
        'app_profile_upper_partups': {to: 'app_profile'}
    },
    data: function() {
        return {
            profileId: this.params._id
        };
    }
});

Router.route('/profile/:_id/supporter', {
    name: 'profile-supporter-partups',
    where: 'client',
    yieldRegions: {
        'app': {to: 'main'},
        'app_profile': {to: 'app'},
        'app_profile_supporter_partups': {to: 'app_profile'}
    },
    data: function() {
        return {
            profileId: this.params._id
        };
    }
});

Router.route('/profile/:_id/partners', {
    name: 'profile-partners',
    where: 'client',
    yieldRegions: {
        'app': {to: 'main'},
        'app_profile': {to: 'app'},
        'app_profile_partners': {to: 'app_profile'}
    },
    data: function() {
        return {
            profileId: this.params._id
        };
    }
});

/*************************************************************/
/* Profile settings modal */
/*************************************************************/
Router.route('/profile/:_id/settings', {
    name: 'profile-settings',
    where: 'client',
    yieldRegions: {
        'modal':              {to: 'main'},
        'modal_profile_settings': {to: 'modal'},
        'modal_profile_settings_details': {to: 'modal_profile_settings'}
    },
    data: function() {
        return {
            profileId: this.params._id
        };
    }
});

Router.route('/profile/:_id/settings/general', {
    name: 'profile-settings-account',
    where: 'client',
    yieldRegions: {
        'modal':              {to: 'main'},
        'modal_profile_settings': {to: 'modal'},
        'modal_profile_settings_account': {to: 'modal_profile_settings'}
    },
    data: function() {
        return {
            profileId: this.params._id
        };
    }
});

Router.route('/profile/:_id/settings/email', {
    name: 'profile-settings-email',
    where: 'client',
    yieldRegions: {
        'modal':              {to: 'main'},
        'modal_profile_settings': {to: 'modal'},
        'modal_profile_settings_email': {to: 'modal_profile_settings'}
    },
    data: function() {
        return {
            profileId: this.params._id
        };
    }
});

/*************************************************************/
/* Create Partup */
/*************************************************************/
Router.route('/start', {
    name: 'create',
    where: 'client',
    yieldRegions: {
        'modal':              {to: 'main'},
        'modal_create_intro': {to: 'modal'}
    }
});

Router.route('/start/details', {
    name: 'create-details',
    where: 'client',
    yieldRegions: {
        'modal':                {to: 'main'},
        'modal_create':         {to: 'modal'},
        'modal_create_details': {to: 'modal_create'}
    }
});

Router.route('/start/:_id/activities', {
    name: 'create-activities',
    where: 'client',
    yieldRegions: {
        'modal':                   {to: 'main'},
        'modal_create':            {to: 'modal'},
        'modal_create_activities': {to: 'modal_create'}
    },
    data: function() {
        return {
            partupId: this.params._id
        };
    },
    action: function() {
        if (Meteor.isClient) {
            Session.set('partials.create-partup.current-partup', this.params._id);
        }
        this.render();
    }
});

Router.route('/start/:_id/promote', {
    name: 'create-promote',
    where: 'client',
    yieldRegions: {
        'modal':                {to: 'main'},
        'modal_create':         {to: 'modal'},
        'modal_create_promote': {to: 'modal_create'}
    },
    data: function() {
        return {
            partupId: this.params._id
        };
    },
    action: function() {
        if (Meteor.isClient) {
            Session.set('partials.create-partup.current-partup', this.params._id);
        }
        this.render();
    }
});

/*************************************************************/
/* Login flow */
/*************************************************************/
Router.route('/login', {
    name: 'login',
    where: 'client',
    yieldRegions: {
        'modal':       {to: 'main'},
        'modal_login': {to: 'modal'}
    }
});

/*************************************************************/
/* Password reset */
/*************************************************************/
Router.route('/forgot-password', {
    name: 'forgot-password',
    where: 'client',
    yieldRegions: {
        'modal':                {to: 'main'},
        'modal_forgotpassword': {to: 'modal'}
    }
});

Router.route('/reset-password/:token', {
    name: 'reset-password',
    where: 'client',
    yieldRegions: {
        'modal':               {to: 'main'},
        'modal_resetpassword': {to: 'modal'}
    },
    data: function() {
        return {
            token: this.params.token
        };
    }
});

/*************************************************************/
/* Verify Account */
/*************************************************************/
Router.route('/verify-email/:token', {
    name: 'verify-email',
    where: 'client',
    yieldRegions: {
        'app': {to: 'main'}
    },
    data: function() {
        return {
            token: this.params.token
        };
    },
    onBeforeAction: function() {
        Router.go('profile-fallback');

        Accounts.verifyEmail(this.data().token, function(error) {
            if (error) {
                Partup.client.notify.warning(TAPi18n.__('notification-verify-mail-warning'));
            } else {
                Partup.client.notify.success(TAPi18n.__('notification-verify-mail-success'));
            }
        });
    }
});

/*************************************************************/
/* Unsubscribe from mailings */
/*************************************************************/
Router.route('/unsubscribe-email-all/:token', {
    name: 'unsubscribe-email-all',
    where: 'client',
    yieldRegions: {
        'modal': {to: 'main'},
        'modal_profile_settings_email_unsubscribe_all': {to: 'modal'}
    },
    data: function() {
        return {
            token: this.params.token
        };
    }
});

Router.route('/unsubscribe-email-one/:subscriptionKey/:token', {
    name: 'unsubscribe-email-one',
    where: 'client',
    yieldRegions: {
        'modal': {to: 'main'},
        'modal_profile_settings_email_unsubscribe_one': {to: 'modal'}
    },
    data: function() {
        return {
            subscriptionKey: this.params.subscriptionKey,
            token: this.params.token
        };
    }
});

/*************************************************************/
/* Register flow */
/*************************************************************/
Router.route('/register', {
    name: 'register',
    where: 'client',
    yieldRegions: {
        'modal':                 {to: 'main'},
        'modal_register':        {to: 'modal'},
        'modal_register_signup': {to: 'modal_register'}
    }
});

Router.route('/register/details', {
    name: 'register-details',
    where: 'client',
    yieldRegions: {
        'modal':                  {to: 'main'},
        'modal_register':         {to: 'modal'},
        'modal_register_details': {to: 'modal_register'}
    }
});

/*************************************************************/
/* Partup detail */
/*************************************************************/
Router.route('/partups/:slug', {
    name: 'partup',
    where: 'client',
    yieldRegions: {
        'app':                {to: 'main'},
        'app_partup':         {to: 'app'},
        'app_partup_updates': {to: 'app_partup'}
    },
    data: function() {
        return {
            partupId: Partup.client.strings.partupSlugToId(this.params.slug),
            accessToken: this.params.query.token
        };
    },
    onRun: function() {
        Meteor.call('partups.analytics.click', this.data().partupId);
        this.next();
    },
    onBeforeAction: function() {
        var partupId = this.data().partupId;
        var accessToken = this.data().accessToken;

        if (partupId && accessToken) {
            Session.set('partup_access_token', accessToken);
            Session.set('partup_access_token_for_partup', partupId);
        }

        this.next();
    }
});

Router.route('/partups/:slug/updates/:update_id', {
    name: 'partup-update',
    where: 'client',
    yieldRegions: {
        'app':               {to: 'main'},
        'app_partup':        {to: 'app'},
        'app_partup_update': {to: 'app_partup'}
    },
    data: function() {
        return {
            partupId: Partup.client.strings.partupSlugToId(this.params.slug),
            updateId: this.params.update_id
        };
    }
});

Router.route('/partups/:slug/activities', {
    name: 'partup-activities',
    where: 'client',
    yieldRegions: {
        'app':                   {to: 'main'},
        'app_partup':            {to: 'app'},
        'app_partup_activities': {to: 'app_partup'}
    },
    data: function() {
        return {
            partupId: Partup.client.strings.partupSlugToId(this.params.slug)
        };
    }
});

Router.route('/partups/:slug/invite', {
    name: 'partup-invite',
    where: 'client',
    yieldRegions: {
        'modal':                    {to: 'main'},
        'modal_invite_to_partup': {to: 'modal'},
    },
    data: function() {
        return {
            partupId: Partup.client.strings.partupSlugToId(this.params.slug)
        };
    }
});

Router.route('/partups/:slug/invite-for-activity/:activity_id', {
    name: 'partup-activity-invite',
    where: 'client',
    yieldRegions: {
        'modal':                    {to: 'main'},
        'modal_invite_to_activity': {to: 'modal'},
    },
    data: function() {
        return {
            partupId: Partup.client.strings.partupSlugToId(this.params.slug),
            activityId: this.params.activity_id
        };
    }
});

Router.route('/partups/:slug/settings', {
    name: 'partup-settings',
    where: 'client',
    yieldRegions: {
        'modal':                  {to: 'main'},
        'modal_partup_settings': {to: 'modal'},
    },
    data: function() {
        return {
            partupId: Partup.client.strings.partupSlugToId(this.params.slug)
        };
    }
});

/*************************************************************/
/* Close window route */
/*************************************************************/
Router.route('/close', {
    name: 'close',
    where: 'client',
    onBeforeAction: function() {
        window.close();
    }
});

/*************************************************************/
/* Admin (super mega ultra admin) */
/*************************************************************/
Router.route('/admin', {
    name: 'admin-overview',
    where: 'client',
    yieldRegions: {
        'modal':                    {to: 'main'},
        'modal_admin':              {to: 'modal'},
        'modal_admin_overview':     {to: 'modal_admin'}
    }
});

Router.route('/admin/featured-partups', {
    name: 'admin-featured-partups',
    where: 'client',
    yieldRegions: {
        'modal':                            {to: 'main'},
        'modal_admin':                      {to: 'modal'},
        'modal_admin_featured_partups':     {to: 'modal_admin'}
    }
});

Router.route('/admin/tribes', {
    name: 'admin-createtribe',
    where: 'client',
    yieldRegions: {
        'modal':                   {to: 'main'},
        'modal_admin':             {to: 'modal'},
        'modal_create_tribe':      {to: 'modal_admin'}
    }
});

Router.route('/admin/featured-tribes', {
    name: 'admin-featured-networks',
    where: 'client',
    yieldRegions: {
        'modal':                            {to: 'main'},
        'modal_admin':                      {to: 'modal'},
        'modal_admin_featured_networks':    {to: 'modal_admin'}
    }
});

Router.route('/admin/swarms', {
    name: 'admin-createswarm',
    where: 'client',
    yieldRegions: {
        'modal':                 {to: 'main'},
        'modal_admin':           {to: 'modal'},
        'modal_create_swarm':    {to: 'modal_admin'}
    }
});

/*************************************************************/
/* Content pages */
/*************************************************************/
Router.route('/about', {
    name: 'about',
    where: 'client',
    yieldRegions: {
        'app':      {to: 'main'},
        'app_about': {to: 'app'}
    }
});

Router.route('/pricing', {
    name: 'pricing',
    where: 'client',
    yieldRegions: {
        'app':      {to: 'main'},
        'app_pricing': {to: 'app'}
    }
});

/*************************************************************/
/* Networks */
/*************************************************************/
Router.route('/tribes/:slug', {
    name: 'network',
    where: 'client',
    yieldRegions: {
        'app':                      {to: 'main'},
        'app_network_start':        {to: 'app'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug,
            accessToken: this.params.query.token
        };
    },
    onBeforeAction: function() {
        var route = this;
        var networkSlug = route.params.slug;
        var accessToken = route.params.query.token;
        var showStartpage = route.params.query.show;
        var userId = Meteor.userId();
        if (networkSlug && accessToken) {
            Session.set('network_access_token', accessToken);
            Session.set('network_access_token_for_network', networkSlug);
        }
        if (userId && networkSlug && accessToken) {
            Meteor.call('networks.convert_access_token_to_invite', networkSlug, accessToken);
        }
        if (showStartpage === 'true') {
            // console.log('showing startpage');
            route.next();
        } else if (showStartpage === 'false') {
            // console.log('redirecting to network-detail');
            route.renderRoute('network-detail');
        } else {
            // console.log('checking if user is a member');
            Meteor.call('users.member_of_network', userId, networkSlug, function(error, response) {
                var response = response || {};
                if (response.has_member) {
                    route.renderRoute('network-detail');
                } else {
                    route.render();
                }
            });
            route.stop();
        }
    }
});

Router.route('/tribes/:slug/partups', {
    name: 'network-detail',
    where: 'client',
    yieldRegions: {
        'app':                      {to: 'main'},
        'app_network':              {to: 'app'},
        'app_network_partups':      {to: 'app_network'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});

Router.route('/tribes/:slug/uppers', {
    name: 'network-uppers',
    where: 'client',
    yieldRegions: {
        'app':                  {to: 'main'},
        'app_network':          {to: 'app'},
        'app_network_uppers':   {to: 'app_network'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});


Router.route('/tribes/:slug/about', {
    name: 'network-about',
    where: 'client',
    yieldRegions: {
        'app':                  {to: 'main'},
        'app_network':          {to: 'app'},
        'app_network_about':   {to: 'app_network'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});

// Temporarily disabled for mobile chat release
// Router.route('/tribes/:slug/chat', {
//     name: 'network-chat',
//     where: 'client',
//     yieldRegions: {
//         'app':                  {to: 'main'},
//         'app_network':          {to: 'app'},
//         'app_network_chat':   {to: 'app_network'}
//     },
//     data: function() {
//         return {
//             networkSlug: this.params.slug
//         };
//     }
// });

Router.route('/tribes/:slug/invite', {
    name: 'network-invite',
    where: 'client',
    yieldRegions: {
        'modal':                   {to: 'main'},
        'modal_network_invite':    {to: 'modal'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});

/*************************************************************/
/* Network (admin) */
/*************************************************************/
Router.route('/tribes/:slug/settings', {
    name: 'network-settings',
    where: 'client',
    yieldRegions: {
        'modal':                          {to: 'main'},
        'modal_network_settings':         {to: 'modal'},
        'modal_network_settings_details': {to: 'modal_network_settings'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});

Router.route('/tribes/:slug/settings/uppers', {
    name: 'network-settings-uppers',
    where: 'client',
    yieldRegions: {
        'modal':                         {to: 'main'},
        'modal_network_settings':        {to: 'modal'},
        'modal_network_settings_uppers': {to: 'modal_network_settings'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});

Router.route('/tribes/:slug/settings/bulk-invite', {
    name: 'network-settings-bulkinvite',
    where: 'client',
    yieldRegions: {
        'modal':                         {to: 'main'},
        'modal_network_settings':        {to: 'modal'},
        'modal_network_settings_bulkinvite': {to: 'modal_network_settings'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});

Router.route('/tribes/:slug/settings/requests', {
    name: 'network-settings-requests',
    where: 'client',
    yieldRegions: {
        'modal':                           {to: 'main'},
        'modal_network_settings':          {to: 'modal'},
        'modal_network_settings_requests': {to: 'modal_network_settings'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});

Router.route('/tribes/:slug/settings/about', {
    name: 'network-settings-about',
    where: 'client',
    yieldRegions: {
        'modal':                         {to: 'main'},
        'modal_network_settings':        {to: 'modal'},
        'modal_network_settings_about': {to: 'modal_network_settings'}
    },
    data: function() {
        return {
            networkSlug: this.params.slug
        };
    }
});

/*************************************************************/
/* Swarm */
/*************************************************************/

Router.route('/:slug', {
    name: 'swarm',
    where: 'client',
    yieldRegions: {
        'swarm':            {to: 'main'}
    },
    data: function() {
        return {
            slug: this.params.slug
        };
    },
    onBeforeAction: function() {
        var self = this;

        //N.B. this param rewrite ensures case insensitive urls for swarms
        this.params.slug = Partup.client.strings.slugify(self.params.slug);

        var slug = this.params.slug;

        // this checks if the slug is a swarm or network and handles it accordingly
        Meteor.call('swarms.slug_is_swarm_or_network', slug, function(error, result) {
            var result = result || {};
            // if something goes wrong, just continue rendering
            if (error) self.render();

            // render the page if it's a swarm
            // swarm always has priority over a network
            if (result.is_swarm) {
                self.render();

            // redirect to the network detail if it isn't a swarm but is a network
            } else if (result.is_network) {
                self.redirect('network', {
                    slug: self.params.slug
                }, {
                    query: self.params.query
                });

            // if it is neither a swarm or network, continue rendering the swarm page
            // the page will handle a "not found" exception by itself
            } else {
                self.render();
            }
        });

        // this prevents anything from happening
        // before the meteor call is completed
        this.stop();
    }
});

/*************************************************************/
/* Swarm (admin) */
/*************************************************************/

Router.route('/:slug/settings', {
    name: 'swarm-settings-details',
    where: 'client',
    yieldRegions: {
        'modal':                            {to: 'main'},
        'modal_swarm_settings':             {to: 'modal'},
        'modal_swarm_settings_details':  {to: 'modal_swarm_settings'}
    },
    data: function() {
        return {
            slug: this.params.slug
        };
    }
});
Router.route('/:slug/tribes', {
    name: 'swarm-settings-tribes',
    where: 'client',
    yieldRegions: {
        'modal':                            {to: 'main'},
        'modal_swarm_settings':             {to: 'modal'},
        'modal_swarm_settings_tribes':  {to: 'modal_swarm_settings'}
    },
    data: function() {
        return {
            slug: this.params.slug
        };
    }
});
Router.route('/:slug/quotes', {
    name: 'swarm-settings-quotes',
    where: 'client',
    yieldRegions: {
        'modal':                            {to: 'main'},
        'modal_swarm_settings':             {to: 'modal'},
        'modal_swarm_settings_quotes':      {to: 'modal_swarm_settings'}
    },
    data: function() {
        return {
            slug: this.params.slug
        };
    }
});

/*************************************************************/
/* All other routes */
/*************************************************************/
Router.route('/(.*)', {
    where: 'client',
    yieldRegions: {
        'app':          {to: 'main'},
        'app_notfound': {to: 'app'}
    }
});

/*************************************************************/
/* Route protection */
/*************************************************************/

// Shield pages for non-users
Router.onBeforeAction(function(req, res, next) {
    if (!Meteor.userId()) {
        Intent.go({route: 'login'}, function(user) {
            if (user) next();
            else this.back();
        });
    } else {
        next();
    }
}, {
    where: 'client',
    only: [
        'create',
        'create-details',
        'create-activities',
        'create-promote',
        'register-details',
        'network-invite',
        'profile-settings',
        'profile-settings-account',
        'profile-settings-email',
        'partup-settings',
        'admin-overview',
        'admin-featured-partups',
        'admin-createtribe',
        'network-settings',
        'network-settings-uppers',
        'network-settings-requests',
        'network-settings-bulkinvite'
    ]
});

// Shield admin pages for non admins
Router.onBeforeAction(function(req, res, next) {
    var user = Meteor.user();
    if (User(user).isAdmin()) {
        next();
    } else {
        Router.pageNotFound();
    }
}, {
    where: 'client',
    only: [
        'admin-overview',
        'admin-featured-partups',
        'admin-createtribe',
    ]
});

// Reset create-partup id to reset the create partup flow
Router.onBeforeAction(function(req, res, next) {
    if (Meteor.isClient) {
        Session.set('partials.create-partup.current-partup', undefined);
    }
    next();
}, {
    where: 'client',
    except: [
        'create-details',
        'create-activities',
        'create-contribute',
        'create-promote'
    ]
});

/*************************************************************/
/* Miscellaneous */
/*************************************************************/
if (Meteor.isClient) {

    Router.onBeforeAction(function() {
        // Scroll to top
        window.scrollTo(0, 0);

        // Disable focuslayer (a white layer currently used with edit-activity in the start-partup-flow)
        Partup.client.focuslayer.disable();

        // Close any popups
        try {
            Partup.client.popup.close();
        } catch (err) {}

        // Proceed route change
        this.next();
    });

    /**
     * Router helper for ernot foundror pages
     *
     * @memberOf Router
     * @param {String} type          Type of 404 page (partup/network/default)
     *
     */
    Router.pageNotFound = function(type, data) {
        var currentRoute = this.current();
        if (type) currentRoute.state.set('type', type);
        if (data) currentRoute.state.set('data', data);
        currentRoute.render('app', {to: 'main'}); // this is so it also works for modals
        currentRoute.render('app_notfound', {to: 'app'});
    };

    // renders the yield regions of a different route
    // basically a redirect without the redirect
    // users can still use the browser "back" button
    // WARNING: this should only be used to render child routes
    // for example: /tribes/:slug > /tribes/:slug/partups not /tribes/:slug > /profile/:_id
    RouteController.prototype.renderRoute = function(routeName) {
        var self = this;
        var regions = Router.routes[routeName].options.yieldRegions;
        _.each(regions, function(item, key) {
            self.render(key, item);
        });
    };

    Router.replaceYieldTemplate = function(newTemplate, target) {
        var currentRoute = this.current();
        currentRoute.render(newTemplate, {to: target});
    };
} else {
    Router.route('/dreams/:path(.*)', {
        where: 'server',
        action: function() {
            var url = 'http://blog.partup.com/dreams/' + this.params.path;
            this.response.writeHead(301, {Location: url});
            return this.response.end();
        }
    });

    Router.route('/blogs/:path(.*)', {
        where: 'server',
        action: function() {
            var url = 'http://blog.partup.com/blogs/' + this.params.path;
            this.response.writeHead(301, {Location: url});
            return this.response.end();
        }
    });

    if (mout.object.get(Meteor, 'settings.public.aws.bucket') == 'development') {
        var fs = Npm.require('fs');
        var basedir = process.cwd().replace(/\/app\/(.*)$/, '/app') + '/uploads';

        Router.route('/uploads/:path(.*)', {
            where: 'server',
            action: function() {
                var path = '/' + this.params.path;
                var file = fs.readFileSync(basedir + path);
                var ext = path.match(/\.([^.]+)/)[1];
                if (ext === 'jpg') ext = 'jpeg';

                var headers = {
                    'Content-type': 'image/' + ext,
                    'Content-Disposition': 'attachment; filename=' + path
                };

                this.response.writeHead(200, headers);
                return this.response.end(file);
            }
        });
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/services/location.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace partup.services.location
 @memberof Partup.services
 */
Partup.services.location = {
    /**
     * Transform a location object into a display string
     *
     * @memberof Partup.services.location
     * @param {Object} location
     */
    locationToLocationInput: function(location) {
        if (!location) return;
        return location.place_id;
    },

    /**
     * Transform a location input into location object
     *
     * @memberof services.location
     * @param {String} placeId
     */
    locationInputToLocation: function(placeId) {
        var result = Partup.server.services.google.getCity(placeId);

        if (!result) return false;

        var location = {};

        location.city = result.name;
        location.lat = mout.object.get(result, 'geometry.location.lat');
        location.lng = mout.object.get(result, 'geometry.location.lng');
        location.place_id = result.place_id;

        // Initialise country in case we can't find it
        location.country = null;

        // Find the country
        var addressComponents = result.address_components || [];
        addressComponents.forEach(function(component) {
            if (mout.array.contains(component.types, 'country')) {
                location.country = component.long_name;
            }
        });

        return location;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/services/placeholder.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Placeholder helper service
 @name partup.services.placeholders
 @memberof Partup.services
 */
Partup.services.placeholders = {

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/services/tags.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var diff = function diff (array1, array2) {
    return array1.filter(function(i) { return array2.indexOf(i) < 0; });
};

/**
 @namespace Tags helper service
 @name Partup.services.tags
 @memberof Partup.services
 */
Partup.services.tags = {
    /**
     * Calculate the changes between two tag arrays
     *
     * @memberof services.tags
     * @param {String[]} oldTags
     * @param {String[]} newTags
     */
    calculateChanges: function calculateChanges(oldTags, newTags) {
        var addedTags = diff(newTags, oldTags);
        var removedTags = diff(oldTags, newTags);
        var maxLength = Math.max(addedTags.length, removedTags.length);

        var changes = [];

        for (var i = 0; i < maxLength; i++) {
            var addedTag = addedTags.shift();
            var removedTag = removedTags.shift();
            var change = {};

            // A tag is changed
            if (addedTag && removedTag) {
                change.type = 'changed';
                change.old_tag = removedTag;
                change.new_tag = addedTag;

            // A tag is added
            } else if (!removedTag) {
                change.type = 'added';
                change.new_tag = addedTag;

            // A tag is removed
            } else if (!addedTag) {
                change.type = 'removed';
                change.old_tag = removedTag;
            }

            changes.push(change);
        }

        return changes;
    },

    /**
     * Transform a comma separated string into an array of tags
     *
     * @memberof services.tags
     * @param {String} tags_input
     */
    tagInputToArray: function(tags_input) {
        if (!tags_input) return [];

        var _tags = tags_input.split(',');

        if (_tags.length === 0) return [];

        return _tags.map(function(elem) {
            return elem.trim().toLocaleLowerCase();
        }).filter(function(elem) {
            return !!elem;
        });
    },

    /**
     * Transform a comma separated string into an array of tags
     *
     * @memberof services.tags
     * @param {String} tags
     */
    tagArrayToInput: function(tags) {
        if (!tags || !tags.length) return '';
        return tags.join(', ');
    },

    /**
     * Store new tags into collection
     *
     * @memberOf services.tags
     * @param {String[]} tags
     */
    insertNewTags: function(tags) {
        if (!tags) return;
        tags.forEach(function(tag) {
            if (!Tags.findOne({_id: tag})) {
                Tags.insert({_id: tag});
            }
        });
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/services/validators.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Validators helper service
 @name partup.services.validators
 @memberof Partup.services
 */
Partup.services.validators = {
    tagsSeparatedByComma: /^\s*(\w|-|&|\.)*(\s*,?\s*(\w|-|&|\.)*)*\s*$/,

    // minimum 8 characters, at least 1 number, at least 1 capital letter
    password: /(?=^.{8,}$)(?=.*\d)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/,

    // according to RFC 5322 official standard
    email: /(?:[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])/,

    // Facebook usernames can only contain a-z A-Z 0-9 and .
    // minimum is 5 and max is infinity (not validated)
    facebookUsername: /^[a-zA-Z0-9.]{5,}$/,

    // Instagram usernames can only contain a-z A-Z . and _
    // max length is 30 characters
    instagramUsername: /^[a-zA-Z._]{1,30}$/,

    // Linkedin usernames can only contain a-z A-Z 0-9
    // min is 5 chars and max is 30 chars according to linkedin guidelines
    linkedinusername: /^[a-zA-Z0-9]{5,30}$/,

    // Twitter usernames can only contain a-z A-Z 0-9 and have a limit of 15 chars
    twitterUsername: /^[A-Za-z0-9_]{1,15}$/,

    // SimpleSchema Url wihout the http or https
    simpleSchemaUrlWithoutProtocol: /^(?:(?:https?|ftp):\/\/)?(?:\S+(?::\S*)?@)?(?:(?!10(?:\.\d{1,3}){3})(?!127(?:\.\d{1,3}){3})(?!169\.254(?:\.\d{1,3}){2})(?!192\.168(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]+-?)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]+-?)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/i,

    // facebookUrl: /^http[s]?:\/\/(www\.)?facebook\.com\/\w+(\?.*)?$/,     //old
    facebookUrl: /^http[s]?:\/\/(www\.)?facebook\.com\/[a-zA-Z0-9._-]+\/?(\?.*)?$/, //new
    instagramUrl: /^http[s]?:\/\/(www\.)?instagram\.com\/[a-zA-Z0-9._-]+\/?(\?.*)?$/,
    linkedinUrl: /^http[s]?:\/\/([a-zA-Z]+\.)?linkedin\.com\/(in\/[a-zA-Z0-9._-]+|pub\/.*|profile\/view)\/?(\?.*)?$/,
    twitterUrl: /^http[s]?:\/\/(www\.)?twitter\.com\/[a-zA-Z0-9._-]+\/?(\?.*)??$/,

    /**
     * Validate if the required tags are present in the string
     *
     * @param {String} string
     * @param {Array[]} requiredTags
     *
     * @return {Boolean} valid
     */
    containsRequiredTags: function(string, requiredTags) {
        var valid = true;

        requiredTags.forEach(function(tag) {
            var matches = string.match(new RegExp('\\[\\s*' + tag + '\\s*\\]', 'i'));

            if (!matches) valid = false;
        });

        return valid;
    },

    /**
     * Validate if the required tags are present in the string
     *
     * @param {String} string
     *
     * @return {Boolean} valid
     */
    containsNoHtml: function(string) {

        // Source: http://stackoverflow.com/a/15458987/2803759
        var containsHtmlTags = new RegExp('<[a-z][\\s\\S]*>', 'i');
        return !containsHtmlTags.test(string);
    },

    /**
     * Validate if the string contains urls
     *
     * @param {String} string
     *
     * @return {Boolean} valid
     */
    containsNoUrls: function(string) {

        // Source: https://github.com/kevva/url-regex
        var containsUrls = new RegExp(/(["'])?(?:(?:[a-z]+:)?\/\/)(?:\S+(?::\S*)?@)?(?:localhost|(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])){3}|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?\1/gi);
        return !containsUrls.test(string);
    },

    isVideoUrl: function(url) {
        // YouTube
        // http://stackoverflow.com/questions/2964678/jquery-youtube-url-validation-with-regex#10315969
        var youtubeRegex = /^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
        var youtubeValid = (url.match(youtubeRegex)) ? RegExp.$1 : false;

        // Vimeo
        var vimeoRegex = /(?:https?:\/\/)?(?:www\.)?vimeo.com\/(?:channels\/(?:\w+\/)?|groups\/([^\/]*)\/videos\/|album\/(\d+)\/video\/|)(\d+)(?:$|\/|\?)/;
        var vimeoValid = vimeoRegex.test(url);

        return (youtubeValid || vimeoValid);
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/services/website.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Partup helper service
 @name Partup.services.website
 @memberof Partup.services
 */
Partup.services.website = {
    /**
     * Transform a clean url to a full url
     *
     * @memberof services.website
     * @param {String} cleanUrl
     */
    cleanUrlToFullUrl: function(cleanUrl) {
        if (!cleanUrl) return '';

        var fullUrl = cleanUrl;
        if (cleanUrl.indexOf('http://') !== 0 && cleanUrl.indexOf('https://') !== 0) {
            fullUrl = 'http://' + cleanUrl;
        }
        return fullUrl;
    },

    /**
     * Transform a full url to a clean url
     *
     * @memberof services.website
     * @param {String} fullUrl
     */
    fullUrlToCleanUrl: function(fullUrl) {
        if (!fullUrl) return '';

        return fullUrl.replace(/^(http:\/\/|https:\/\/)/i, '');
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/activities.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @ignore
 */
var Activity = function(document) {
    _.extend(this, document);
};

/**
 * Check if the activity is open
 *
 * @memberof Activities
 * @return {Boolean}
 */
Activity.prototype.isOpen = function() {
    return Contributions.findForActivity(this).count() === 0;
};

/**
 * Check if the activity is closed
 *
 * @memberof Activities
 * @return {Boolean}
 */
Activity.prototype.isClosed = function() {
    return Contributions.findForActivity(this).count() > 0;
};

/**
 * Check if upper is already invited to the activity
 *
 * @memberof Activities
 * @param {String} upperId the user id of the user to be checked
 * @return {Boolean}
 */
Activity.prototype.isUpperInvited = function(upperId) {
    return !!Invites.findOne({activity_id: this._id, invitee_id: upperId, type: Invites.INVITE_TYPE_ACTIVITY_EXISTING_UPPER});
};

/**
 * Remove all invites for a specific user for this activity
 *
 * @memberof Activities
 * @param {String} upperId id of the user whose invites have to be removed
 */
Activity.prototype.removeAllUpperInvites = function(upperId) {
    Invites.remove({activity_id: this._id, invitee_id: upperId});
};

/**
 * Soft delete an activity
 *
 * @memberOf Activities
 */
Activity.prototype.remove = function() {
    Partups.update(this.partup_id, {$inc: {activity_count: -1}});

    Activities.update(this._id, {$set:{deleted_at: new Date}});
};

/**
 * Check whether or not an activity is removed
 *
 * @memberOf Activities
 * @return {Boolean}
 */
Activity.prototype.isRemoved = function() {
    return !!this.deleted_at;
};

/**
 * Activities are units of work that a partup consists of
 *
 * @namespace Activities
 * @memberOf Collection
 */
Activities = new Mongo.Collection('activities', {
    transform: function(document) {
        return new Activity(document);
    }
});

// Add indices
if (Meteor.isServer) {
    Activities._ensureIndex('creator_id');
    Activities._ensureIndex('partup_id');
    Activities._ensureIndex('update_id');
}

/**
 * Find one document, throw an error if it doesn't exist.
 *
 * @memberof Activities
 * @return {Activity}
 */
Activities.findOneOrFail = function(selector, options) {
    // We do not want to return activities that have been soft deleted
    selector.deleted_at = selector.deleted_at || {$exists: false};

    var activity = this.findOne(selector, options);

    if (!activity) throw new Meteor.Error(404, 'activity_could_not_be_found');

    return activity;
};


/**
 * Find activity for an update
 *
 * @memberOf Activities
 * @param {Update} update
 * @return {Mongo.Cursor|Void}
 */
Activities.findForUpdate = function(update) {
    if (!update.isActivityUpdate()) return;

    return Activities.find({_id: update.type_data.activity_id}, {limit: 1});
};

/**
 * Find activity for contribution
 *
 * @memberOf Activities
 * @param {Contribution} contribution
 * @return {Mongo.Cursor}
 */
Activities.findForContribution = function(contribution) {
    return Activities.find({_id: contribution.activity_id}, {limit: 1});
};

/**
 * Find activities for partup
 *
 * @memberOf Activities
 * @param {Contribution} contribution
 * @return {Mongo.Cursor}
 */
Activities.findForPartup = function(partup, options, parameters) {
    options = options || {};
    parameters = parameters || {};

    var selector = {
        partup_id: partup._id
    };

    if (parameters.hasOwnProperty('archived')) {
        selector.archived = !!parameters.archived;
    }

    return this.guardedFind(null, selector, options);
};

/**
 * Modified version of Collection.find that makes sure the
 * user (or guest) can only retrieve authorized entities
 *
 * @memberof Activities
 * @param {String} userId
 * @param {Object} selector
 * @param {Object} options
 * @return {Cursor}
 */
Activities.guardedFind = function(userId, selector, options) {
    var selector = selector || {};

    // We do not want to return partups that have been soft deleted
    selector.deleted_at = selector.deleted_at || {$exists: false};

    return this.find(selector, options);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/invites.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Invites can contain:
 * - Invitations to a Part-up activity
 * - Invitations to a network
 * @namespace Invites
 * @memberof Collection
 */
Invites = new Mongo.Collection('invites');

// Add indices
if (Meteor.isServer) {
    Invites._ensureIndex('type');
    Invites._ensureIndex('network_id');
    Invites._ensureIndex('inviter_id');
    Invites._ensureIndex('invitee_id');
}

/**
 * Find invites for a user
 *
 * @memberOf Invites
 * @param {User} user
 * @return {Mongo.Cursor}
 */
Invites.findForUser = function(user) {
    return Invites.find({invitee_id: user._id});
};

/**
 * Find invites for a network
 *
 * @memberOf Invites
 * @param {Network} network
 * @return {Mongo.Cursor}
 */
Invites.findForNetwork = function(network) {
    return Invites.find({network_id: network._id});
};

/**
 * @memberof Invites
 * @public
 */
Invites.INVITE_TYPE_ACTIVITY_EMAIL = 'activity_email';

/**
 * @memberof Invites
 * @public
 */
Invites.INVITE_TYPE_ACTIVITY_EXISTING_UPPER = 'activity_existing_upper';

/**
 * @memberof Invites
 * @public
 */
Invites.INVITE_TYPE_NETWORK_EMAIL = 'network_email';

/**
 * @memberof Invites
 * @public
 */
Invites.INVITE_TYPE_NETWORK_EXISTING_UPPER = 'network_existing_upper';

/**
 * @memberof Invites
 * @public
 */
Invites.INVITE_TYPE_PARTUP_EMAIL = 'partup_email';

/**
 * @memberof Invites
 * @public
 */
Invites.INVITE_TYPE_PARTUP_EXISTING_UPPER = 'partup_existing_upper';

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/contributions.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Contributions are added to Activities and indicate a users involvement in an Activity
 * @namespace Contributions
 * @memberOf Collection
 */
Contributions = new Meteor.Collection('contributions');

// Add indices
if (Meteor.isServer) {
    Contributions._ensureIndex('activity_id');
    Contributions._ensureIndex('upper_id');
    Contributions._ensureIndex('partup_id');
    Contributions._ensureIndex('update_id');
}

/**
 * Find contributions for an update
 *
 * @memberOf Contributions
 * @param {Update} update
 * @return {Mongo.Cursor|Void}
 */
Contributions.findForUpdate = function(update) {
    if (!update.isContributionUpdate()) return;

    return Contributions.find({_id: update.type_data.contribution_id}, {limit: 1});
};

/**
 * Find contributions for an activity
 *
 * @memberOf Contributions
 * @param {Activity} activity
 * @param {Object} parameters
 * @return {Mongo.Cursor}
 */
Contributions.findForActivity = function(activity, parameters) {
    parameters = parameters || {};

    var selector = {activity_id: activity._id};

    if (parameters.archived !== undefined) {
        selector.archived = parameters.archived ? true : {$ne: true};
    }

    return Contributions.find(selector);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/updates.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Partup model
 * @ignore
 */
Update = function(document) {
    _.extend(this, document);
};

/**
 * Check if given updates last comment is system message
 *
 * @return {Boolean}
 */
Update.prototype.lastCommentIsSystemMessage = function() {
    if (!this.comments) return false;
    if (this.comments.length < 1) return false;
    return !!mout.array.last(this.comments).system;
};

/**
 * Get the last comment
 *
 * @return {Object}
 */
Update.prototype.getLastComment = function() {
    if (!this.comments) return false;
    if (this.comments.length < 1) return false;
    return mout.array.last(this.comments);
};

/**
 * Check if update is related to an activity
 *
 * @return {Boolean}
 */
Update.prototype.isActivityUpdate = function() {
    return /^partups_activities/.test(this.type) || (
        this.type === 'partups_comments_added' &&
        !this.type_data.contribution_id
    );
};

/**
 * Check if update is related to a contribution
 *
 * @return {Boolean}
 */
Update.prototype.isContributionUpdate = function() {
    return /^partups_(contributions|ratings)/.test(this.type) || (
        this.type === 'partups_comments_added' &&
        this.type_data.contribution_id
    );
};

/**
 * Create the upper_data object for the current user
 *
 * @memberOf Updates
 */
Update.prototype.createUpperDataObject = function(upperId) {
    Updates.update({
        _id: this._id,
        'upper_data._id': {
            $ne: upperId
        }
    }, {
        $push: {
            upper_data: {
                _id: upperId,
                new_comments: []
            }
        }
    });
};

/**
 * Add comment to new_comment in upper_data set
 *
 * @memberOf Updates
 */
Update.prototype.addNewCommentToUpperData = function(comment, upperIds) {
    // Update existing upper data first
    var upper_data = this.upper_data || [];
    upper_data.forEach(function(upperData) {
        if (upperData._id === comment.creator._id) return;
        upperData.new_comments.push(comment._id);
    });

    // Create object for new uppers that dont have upper_data
    var currentUpperDataIds = _.map(upper_data, function(upperData) {
        return upperData._id;
    });

    var newUpperIds = _.difference(upperIds, currentUpperDataIds);
    newUpperIds.forEach(function(upperId) {
        if (upperId === comment.creator._id) return;
        upper_data.push({
            _id: upperId,
            new_comments: [comment._id]
        });
    });

    Updates.update({_id: this._id}, {$set: {upper_data: upper_data}});
};

/**
 * Check if an update is the last updated update of the partup
 *
 * @memberOf Updates
 */
Update.prototype.isLatestUpdateOfItsPartup = function() {
    var updates = Updates.find({partup_id: this.partup_id});
    var self = this;
    var isLatestUpdateOfItsPartup = true;
    updates.forEach(function(update) {
        if (update.updated_at > self.updated_at) {
            isLatestUpdateOfItsPartup = false;
        }
    });

    return isLatestUpdateOfItsPartup;
};

/**
 * Check if an given upper is involved in this update
 *
 * @memberOf Updates
 *
 * @return {[String]}
 */
Update.prototype.getInvolvedUppers = function() {
    // Start with the creator of the update
    var uppers = [this.upper_id];

    // Add contributors if update is an activity
    if (this.type_data && this.type_data.activity_id) {
        Contributions.find({activity_id: this.type_data.activity_id}, {upper_id: 1}).fetch().forEach(function(contribution) {
            uppers.push(contribution.upper_id);
        });
    }

    // Add uppers that commented on update
    if (this.comments && this.comments.length > 0) {
        this.comments.forEach(function(comment) {
            uppers.push(comment.creator._id);
        });
    }

    // Remove duplicates and return array
    return lodash.unique(uppers);
};

/**
 * @namespace Updates
 * @memberOf Collection
 */
Updates = new Mongo.Collection('updates', {
    transform: function(document) {
        return new Update(document);
    }
});

// Add indices
if (Meteor.isServer) {
    Updates._ensureIndex('type');
    Updates._ensureIndex('upper_id');
    Updates._ensureIndex('partup_id');
    Updates._ensureIndex('updated_at');
}

/**
 * Find updates for an activity
 *
 * @memberOf Updates
 * @param {Activity} activity
 * @return {Mongo.Cursor}
 */
Updates.findForActivity = function(activity) {
    return Updates.find({_id: activity.update_id}, {limit: 1});
};

/**
 * Find updates for partup
 *
 * @memberOf Updates
 * @param {Partup} partup
 * @param {Object} parameters
 * @param {Number} parameters.limit
 * @param {String} parameters.filter
 * @param {String} userId
 * @return {Mongo.Cursor}
 */
Updates.findForPartup = function(partup, parameters, userId) {
    var parameters = parameters || {};

    if (Meteor.isClient && !userId) {
        userId = Meteor.userId();
    }

    var selector = {partup_id: partup._id};
    var options = {sort: {updated_at: -1}};

    if (parameters.limit) {
        options.limit = parseInt(parameters.limit);
    }

    if (parameters.filter) {
        var filter = parameters.filter;

        if (filter === 'my-updates') {
            selector.upper_id = userId;
        } else if (filter === 'activities') {
            selector.type = {$regex: '.*activities.*'};
        } else if (filter === 'partup-changes') {
            var regex = '.*(tags|end_date|name|description|image|budget).*';
            selector.type = {$regex: regex};
        } else if (filter === 'messages') {
            selector.type = {$regex: '.*message.*'};
        } else if (filter === 'contributions') {
            selector.type = {$regex: '.*contributions.*'};
        }
    }

    return this.find(selector, options);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/notifications.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Notifications
 @name Notifications
 */
Notifications = new Mongo.Collection('notifications');

// Add indices
if (Meteor.isServer) {
    Notifications._ensureIndex('type');
    Notifications._ensureIndex('for_upper_id');
    Notifications._ensureIndex('new');
    Notifications._ensureIndex('clicked');
}

/**
 * Find the notifications for a user
 *
 * @param {User} user
 * @param {Object} selector
 * @param {Object} options
 * @return {Mongo.Cursor|Void}
 */
Notifications.findForUser = function(user, selector, options) {
    if (!user) return;

    var selector = selector || {};
    var options = options || {};

    selector.for_upper_id = user._id;
    selector.grouped = {$exists: false};
    options.limit = Math.min(options.limit, 100);
    options.sort = {created_at: -1};

    return Notifications.find(selector, options);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/partups.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @memberof Partups
 * @private
 */
var PUBLIC = 1;
/**
 * @memberof Partups
 * @private
 */
var PRIVATE = 2;
/**
 * @memberof Partups
 * @private
 */
var NETWORK_PUBLIC = 3;
/**
 * @memberof Partups
 * @private
 */
var NETWORK_INVITE = 4;
/**
 * @memberof Partups
 * @private
 */
var NETWORK_CLOSED = 5;
/**
 * @memberof Partups
 * @private
 */
var TYPE = {
    CHARITY: 'charity',
    ENTERPRISING: 'enterprising',
    COMMERCIAL: 'commercial',
    ORGANIZATION: 'organization'
};
/**
 * @memberof Partups
 * @private
 */
var PHASE = {
    BRAINSTORM: 'brainstorm',
    PLAN: 'plan',
    EXECUTE: 'execute',
    GROW: 'grow'
};

/**
 * @ignore
 */
var Partup = function(document) {
    _.extend(this, document);
};

/**
 * Check if a given user can edit this partup
 *
 * @memberof Partups
 * @param {User} user the user object
 * @return {Boolean}
 */
Partup.prototype.isEditableBy = function(user) {
    var uppers = this.uppers || [];

    return user && (uppers.indexOf(user._id) > -1 || User(user).isAdmin());
};

/**
 * Check if a given user is the creator of this partup
 *
 * @memberof Partups
 * @param {User} user the user object
 * @return {Boolean}
 */
Partup.prototype.isCreatedBy = function(user) {
    return user && this.creator_id === user._id;
};

/**
 * Check if a given user can remove this partup
 *
 * @memberof Partups
 * @param {User} user the user object
 * @return {Boolean}
 */
Partup.prototype.isRemovableBy = function(user) {
    return user && (this.creator_id === user._id || User(user).isAdmin());
};

/**
 * Check whether or not a partup is removed
 *
 * @memberOf Partups
 * @return {Boolean}
 */
Partup.prototype.isRemoved = function() {
    return !!this.deleted_at;
};

/**
 * Check if given user is a supporter of this partup
 *
 * @memberof Partups
 * @param {String} userId the id of the user that should be checked
 * @return {Boolean}
 */
Partup.prototype.hasSupporter = function(userId) {
    if (!this.supporters) return false;
    return mout.lang.isString(userId) && this.supporters.indexOf(userId) > -1;
};

/**
 * Check if given user is an upper in this partup
 *
 * @memberof Partups
 * @param {String} userId the id of the user that should be checked
 * @return {Boolean}
 */
Partup.prototype.hasUpper = function(userId) {
    if (!this.uppers) return false;
    return mout.lang.isString(userId) && this.uppers.indexOf(userId) > -1;
};

/**
 * Check if given user is on the invite list of this partup
 *
 * @memberof Partups
 * @param {String} userId the id of the user to check against
 * @return {Boolean}
 */
Partup.prototype.hasInvitedUpper = function(userId) {
    if (!this.invites) return false;
    return mout.lang.isString(userId) && this.invites.indexOf(userId) > -1;
};

/**
 * Check if given user has the right to view the partup
 *
 * @memberof Partups
 * @param {String} userId
 * @param {String} accessToken
 * @return {Boolean}
 */
Partup.prototype.isViewableByUser = function(userId, accessToken) {
    if (this.privacy_type === PUBLIC) return true;
    if (this.privacy_type === NETWORK_PUBLIC) return true;
    if (this.privacy_type === PRIVATE || this.privacy_type === NETWORK_INVITE || this.privacy_type === NETWORK_CLOSED) {
        var accessTokens = this.access_tokens || [];
        if (accessTokens.indexOf(accessToken) > -1) return true;

        var user = Meteor.users.findOne(userId);
        if (!user) return false;

        var networks = user.networks || [];
        if (networks.indexOf(this.network_id) > -1) return true;

        if (this.hasSupporter(userId)) return true;
        if (this.hasUpper(userId)) return true;
        if (this.hasInvitedUpper(userId)) return true;
    }

    return false;
};

/**
 * Check if a partup has ended
 *
 * @return {Boolean}
 */
Partup.prototype.hasEnded = function() {
    var now = new Date;
    var endDate = this.endDate;

    return now < endDate;
};

/**
 * Make the upper a supporter
 *
 * @memberof Partups
 * @param {String} upperId the user that becomes a supporter
 */
Partup.prototype.makeSupporter = function(upperId) {
    if (!this.hasUpper(upperId)) {
        Partups.update(this._id, {$addToSet: {'supporters': upperId}});
        Meteor.users.update(upperId, {$addToSet: {'supporterOf': this._id}});

        this.createUpperDataObject(upperId);
    }
};

/**
 * Promote a user from supporter to partner
 *
 * @memberof Partups
 * @param {String} upperId the user that gets promoted
 */
Partup.prototype.makeSupporterPartner = function(upperId) {
    Partups.update(this._id, {$pull: {'supporters': upperId, 'invites': upperId}, $addToSet: {'uppers': upperId}});
    Meteor.users.update(upperId, {$pull: {'supporterOf': this._id}, $addToSet: {'upperOf': this._id}});
};

/**
 * Demote a user from partner to supporter
 *
 * @memberof Partups
 * @param {String} upperId the user that gets demoted
 */
Partup.prototype.makePartnerSupporter = function(upperId) {
    Partups.update(this._id, {$pull: {'uppers': upperId}, $addToSet: {'supporters': upperId}});
    Meteor.users.update(upperId, {$pull: {'upperOf': this._id}, $addToSet: {'supporterOf': this._id}});
};

/**
 * Consume an access token to add the user as an invitee
 *
 * @memberOf Partups
 * @param {String} upperId
 * @param {String} accessToken
 */
Partup.prototype.convertAccessTokenToInvite = function(upperId, accessToken) {
    Partups.update(this._id, {$pull: {'access_tokens': accessToken}, $addToSet: {'invites': upperId}});
};

/**
 * Soft delete a partup
 *
 * @memberOf Partups
 */
Partup.prototype.remove = function() {
    var supporters = this.supporters || [];
    var uppers = this.uppers || [];

    Meteor.users.update({_id: {$in: supporters}}, {$pull: {'supporterOf': this._id}}, {multi: true});
    Meteor.users.update({_id: {$in: uppers}}, {$pull: {'upperOf': this._id}}, {multi: true});

    Partups.update(this._id, {$set:{deleted_at: new Date}});
};

/**
 * Check whether or not a partup is removed
 *
 * @memberOf Partups
 * @return {Boolean}
 */
Partup.prototype.isRemoved = function() {
    return !!this.deleted_at;
};

/**
 * Check whether or not a partup is featured
 *
 * @memberOf Partups
 * @return {Boolean}
 */
Partup.prototype.isFeatured = function() {
    return !!this.featured.active;
};

/**
 * Get all partners and supporters
 *
 * @memberOf Partups
 */
Partup.prototype.getUsers = function() {
    var uppers = this.uppers || [];
    var supporters = this.supporters || [];

    return uppers.concat(supporters);
};

/**
 * Create the upper_data object for the given upperId
 *
 * @memberOf Partups
 */
Partup.prototype.createUpperDataObject = function(upperId) {
    Partups.update({
        _id: this._id,
        'upper_data._id': {
            $ne: upperId
        }
    }, {
        $push: {
            upper_data: {
                _id: upperId,
                new_updates: []
            }
        }
    });
};

/**
 * Remove the upper_data object for the given upperId
 *
 * @memberOf Partups
 */
Partup.prototype.removeUpperDataObject = function(upperId) {
    Partups.update({
        _id: this._id,
        'upper_data._id': upperId
    }, {
        $pull: {upper_data: {_id: upperId}}
    });
};

/**
 * Update new updates for a single user
 *
 * @memberOf Partups
 */
Partup.prototype.addNewUpdateToUpperData = function(update, currentUserId) {
    // Update existing upper data first
    var upper_data = this.upper_data || [];
    upper_data.forEach(function(upperData) {
        if (upperData._id === update.upper_id) return;
        if (upperData._id === currentUserId) return;
        upperData.new_updates.push(update._id);
    });

    // Create object for new uppers that dont have upper_data
    var currentUpperDataIds = _.map(upper_data, function(upperData) {
        return upperData._id;
    });
    var newUpperIds = _.difference(this.getUsers(), currentUpperDataIds);
    newUpperIds.forEach(function(upperId) {
        if (upperId === update.upper_id) return;
        if (upperId === currentUserId) return;
        upper_data.push({
            _id: upperId,
            new_updates: [update._id]
        });
    });

    Partups.update({_id: this._id}, {$set: {upper_data: upper_data}});
};

/**
 * Increase email share count
 *
 * @memberOf Partups
 */
Partup.prototype.increaseEmailShareCount = function() {
    Partups.update({_id: this._id}, {$inc: {'shared_count.email': 1}});
};

/**
 * Check if partup is archived
 *
 * @memberOf Partups
 * @return {Boolean}
 */
Partup.prototype.isArchived = function() {
    return !!this.archived;
};

/**
 * Partups describe collaborations between several uppers
 * @namespace Partups
 */
Partups = new Mongo.Collection('partups', {
    transform: function(document) {
        return new Partup(document);
    }
});

// Add indices
if (Meteor.isServer) {
    Partups._ensureIndex({'name': 'text', 'description': 'text'}, {language_override: 'idioma'});
    Partups._ensureIndex('creator_id');
    Partups._ensureIndex('privacy_type');
    Partups._ensureIndex('slug');
    Partups._ensureIndex('progress');
    Partups._ensureIndex('tags');
    Partups._ensureIndex('deleted_at');
}

/**
 * @memberof Partups
 * @public
 */
Partups.PUBLIC = PUBLIC;
/**
 * @memberof Partups
 * @public
 */
Partups.PRIVATE = PRIVATE;
/**
 * @memberof Partups
 * @public
 */
Partups.NETWORK_PUBLIC = NETWORK_PUBLIC;
/**
 * @memberof Partups
 * @public
 */
Partups.NETWORK_INVITE = NETWORK_INVITE;
/**
 * @memberof Partups
 * @public
 */
Partups.NETWORK_CLOSED = NETWORK_CLOSED;
/**
 * @memberof Partups
 * @public
 */
Partups.TYPE = TYPE;
/**
 * @memberof Partups
 * @public
 */
Partups.PHASE = PHASE;

/**
 * ============== PARTUPS COLLECTION HELPERS ==============
 */

/**
 * Modified version of Collection.find that makes sure the
 * user (or guest) can only retrieve authorized entities
 *
 * @memberof Partups
 * @param {String} userId
 * @param {Object} selector
 * @param {Object} options
 * @param {String} accessToken
 * @return {Cursor}
 */
Partups.guardedFind = function(userId, selector, options, accessToken) {
    // We do not want to return partups that have been soft deleted
    selector.deleted_at = selector.deleted_at || {$exists: false};

    if (Meteor.isClient) return this.find(selector, options);

    var selector = selector || {};
    var options = options || {};

    var guardedCriterias = [
        // Either the partup is public or belongs to a public network
        {'privacy_type': {'$in': [Partups.PUBLIC, Partups.NETWORK_PUBLIC]}}
    ];

    // If an access token is provided, we allow access if it matches one of the partups access tokens
    if (accessToken) {
        guardedCriterias.push({'access_tokens': {'$in': [accessToken]}});
    }

    // Some extra rules that are only applicable to users that are logged in
    if (userId) {
        var user = Meteor.users.findOneOrFail(userId);
        var networks = user.networks || [];

        // The user is part of the partup uppers, which means he has access anyway
        guardedCriterias.push({'uppers': {'$in': [userId]}});

        // The user is part of the partup supporters, which means he has access anyway
        guardedCriterias.push({'supporters': {'$in': [userId]}});

        // Of course the creator of a partup always has the needed rights
        guardedCriterias.push({'creator_id': userId});

        // Everyone who is part of the network the partup is part of can view it
        guardedCriterias.push({'network_id': {'$in': networks}});

        // Check if upper is invited, so has the rights to view a partup in a closed network
        guardedCriterias.push({'invites': {'$in': [userId]}});
    }

    var finalSelector = {};

    // MongoDB only allows 1 root $or, so we have to merge the $or from the given selector
    // with the $or values that we generate with the guarded criteria above here
    if (selector.$or) {
        finalSelector = selector;
        finalSelector.$and = [{'$or': guardedCriterias}, {'$or': selector.$or}];
        delete finalSelector.$or;
    } else {
        // Guarding selector that needs to be fulfilled
        var guardingSelector = {'$or': guardedCriterias};

        // Merge the selectors, so we still use the initial selector provided by the caller
        finalSelector = {'$and': [guardingSelector, selector]};
    }

    return this.find(finalSelector, options);
};

/**
 * Modified version of Collection.find that makes
 * sure the user (or guest) can only retrieve
 * fields that are publicly available
 *
 * @memberof Partups
 * @param {Object} selector
 * @param {Object} options
 * @return {Cursor}
 */
Partups.guardedMetaFind = function(selector, options) {
    var selector = selector || {};
    var options = options || {};

    // We do not want to return partups that have been soft deleted
    selector.deleted_at = selector.deleted_at || {$exists: false};

    // Make sure that if the callee doesn't pass the fields
    // key used in the options parameter, we set it with
    // the _id fields, so we do not publish all fields
    // by default, which would be a security issue
    options.fields = {_id: 1};

    // The fields that should be available on each partup
    var unguardedFields = ['privacy_type', 'archived_at'];

    unguardedFields.forEach(function(unguardedField) {
        options.fields[unguardedField] = 1;
    });

    return this.find(selector, options);
};

/**
 * Find the partups used in the discover page
 *
 * @memberof Partups
 * @param userId
 * @param {Object} options
 * @param parameters
 * @return {Cursor}
 */
Partups.findForDiscover = function(userId, options, parameters) {
    var selector = {};

    options = options || {};
    options.limit = options.limit ? parseInt(options.limit) : undefined;
    options.skip = options.skip ? parseInt(options.skip) : 0;
    options.sort = options.sort || {};

    parameters = parameters || {};
    var sort = parameters.sort || undefined;
    var textSearch = parameters.textSearch || undefined;
    var locationId = parameters.locationId || undefined;
    var networkId = parameters.networkId || undefined;
    var language = parameters.language || undefined;

    if (sort) {
        // Sort the partups from the newest to the oldest
        if (sort === 'new') {
            options.sort['created_at'] = -1;
        }

        // Sort the partups from the most popular to the least popular
        if (sort === 'popular') {
            options.sort['popularity'] = -1;
        }
    }

    // Filter the partups on language
    if (language) {
        selector['language'] = language;
    }

    // Filter archived partups
    selector['archived_at'] = {$exists: false};

    // Filter the partups that are in a given location
    if (locationId) {
        selector['location.place_id'] = locationId;
    }

    // Filter the partups that are in a given network
    if (networkId) {
        selector['network_id'] = networkId;
    }

    // Filter the partups that match the text search
    if (textSearch) {
        Log.debug('Searching for [' + textSearch + ']');

        var textSearchSelector = {$text: {$search: textSearch}};
        var tagSelector = {tags: {$in: [textSearch]}};

        options.fields = {score: {$meta: 'textScore'}};
        options.sort['score'] = {$meta: 'textScore'};

        selector.$or = [textSearchSelector, tagSelector];
    }

    return this.guardedFind(userId, selector, options);
};

/**
 * Find the partup for an update
 *
 * @memberOf Partups
 * @param {String} userId
 * @param {Update} update
 * @return {Mongo.Cursor|Void}
 */
Partups.findForUpdate = function(userId, update) {
    if (!update.partup_id) return;
    return this.guardedFind(userId, {_id: update.partup_id}, {limit:1});
};

/**
 * Find the partups in a network
 *
 * @memberof Partups
 * @param {Network} network
 * @param {Object} parameters
 * @param {Object} options
 * @param {String} loggedInUserId
 * @return {Cursor}
 */
Partups.findForNetwork = function(network, parameters, options, loggedInUserId) {
    parameters = parameters || {};
    options = options || {};
    options.sort = options.sort || {};
    var textSearch = parameters.textSearch || undefined;

    var selector = {
        network_id: network._id
    };

    options.sort['popularity'] = -1;

    if (parameters.hasOwnProperty('archived')) {
        selector.archived_at = {$exists: parameters.archived};
    }

    // Filter the partups that match the text search
    if (textSearch) {
        Log.debug('Searching for [' + textSearch + ']');

        var tagSelector = {tags: {$in: [textSearch]}};
        var slugSelector = {slug: new RegExp('.*' + textSearch.replace(/ /g,'-') + '.*', 'i')};
        var nameSelector = {name: new RegExp('.*' + textSearch + '.*', 'i')};
        var descriptionSelector = {description: new RegExp('.*' + textSearch + '.*', 'i')};

        selector.$or = [tagSelector, slugSelector, nameSelector, descriptionSelector];
    }

    return this.guardedFind(loggedInUserId, selector, options);
};

/**
 * Find the partups that a user is upper of
 *
 * @memberof Partups
 * @param {Object} user
 * @param {Object} parameters
 * @param {Number} parameters.limit
 * @param {String} parameters.sort
 * @param {Boolean} parameters.count
 * @param {String} loggedInUserId Server side only
 * @return {Cursor}
 */
Partups.findUpperPartupsForUser = function(user, parameters, loggedInUserId) {
    parameters = parameters || {};

    var upperOf = user.upperOf || [];

    var selector = {_id: {$in: upperOf}};
    var options = {};

    if (parameters.count) {
        options.count = true;
    } else {
        options.limit = parseInt(parameters.limit);
        options.skip = parseInt(parameters.skip);
        options.sort = parameters.sort || {popularity: -1};
    }

    if (parameters.network_id) {
        selector.network_id = parameters.network_id;
    }

    selector.archived_at = {$exists: parameters.archived};

    return this.guardedFind(loggedInUserId, selector, options);
};

/**
 * Find the partups that a user supporter of
 *
 * @memberof Partups
 * @param {Object} user
 * @param {Object} parameters
 * @param {Number} parameters.limit
 * @param {String} parameters.sort
 * @param {Boolean} parameters.count
 * @param {String} loggedInUserId Server side only
 * @return {Cursor}
 */
Partups.findSupporterPartupsForUser = function(user, parameters, loggedInUserId) {
    user = user || {};
    parameters = parameters || {};

    var supporterOf = user.supporterOf || [];

    var selector = {_id: {$in: supporterOf}};
    var options = {};

    if (parameters.count) {
        options.count = true;
    } else {
        options.skip = parseInt(parameters.skip);
        options.limit = parseInt(parameters.limit);
        options.sort = parameters.sort || {popularity: -1};
    }

    if (parameters.network_id) {
        selector.network_id = parameters.network_id;
    }

    selector.archived_at = {$exists: parameters.archived};

    return this.guardedFind(loggedInUserId, selector, options);
};

Partups.findStatsForAdmin = function() {
    var partups = this.find({});
    results = {
        'total': 0,
        'open': 0,
        'private': 0,
        'networkopen': 0,
        'networkinvite': 0,
        'networkclosed': 0
    };
    partups.forEach(function(partup) {
        switch (partup.privacy_type) {
            case 1:
                results.open++;
                break;
            case 2:
                results.private++;
                break;
            case 3:
                results.networkopen++;
                break;
            case 4:
                results.networkinvite++;
                break;
            case 5:
                results.networkclosed++;
                break;

        }
        results.total++;
    });
    return results;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/images.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Images are entities stored under each object that contains one or more images
 *
 * @namespace Images
 * @memberOf Collection
 */
Images = new Meteor.Collection('cfs.images.filerecord'); // Collection name is for backwards compatibility

/**
 * Find the images for a partup
 *
 * @memberOf Images
 * @param {Partup} partup
 * @return {Mongo.Cursor}
 */
Images.findForPartup = function(partup) {
    return Images.find({_id: partup.image}, {limit: 1});
};

/**
 * Find the images for a user
 *
 * @memberOf Images
 * @param {User} user
 * @return {Mongo.Cursor}
 */
Images.findForUser = function(user) {
    return Images.find({_id: user.profile.image}, {limit: 1});
};

/**
 * Find the images for a network
 *
 * @memberOf Images
 * @param {Network} network
 * @return {Mongo.Cursor}
 */
Images.findForNetwork = function(network) {
    return Images.find({_id: {'$in': [network.background_image, network.image, network.icon, get(network, 'featured.logo')]}}, {limit: 4});
};

/**
 * Find the images for a notification
 *
 * @memberOf Images
 * @param {Notification} notification
 * @return {Mongo.Cursor}
 */
Images.findForNotification = function(notification) {
    var images = [];

    switch (notification.type) {
        case 'partups_messages_inserted': images = [get(notification, 'type_data.creator.image')]; break;
        case 'partups_activities_inserted': images = [get(notification, 'type_data.creator.image')]; break;
        case 'partups_contributions_inserted': images = [get(notification, 'type_data.creator.image')]; break;
        case 'partups_contributions_proposed': images = [get(notification, 'type_data.creator.image')]; break;
        case 'partups_networks_accepted': images = [get(notification, 'type_data.creator.image')]; break;
        case 'partups_networks_invited': images = [get(notification, 'type_data.inviter.image')]; break;
        case 'partups_networks_new_pending_upper': images = [get(notification, 'type_data.pending_upper.image')]; break;
        case 'partups_supporters_added': images = [get(notification, 'type_data.supporter.image')]; break;
        case 'partup_activities_invited': images = [get(notification, 'type_data.inviter.image')]; break;
        case 'invite_upper_to_partup': images = [get(notification, 'type_data.inviter.image')]; break;
        case 'partups_contributions_accepted': images = [get(notification, 'type_data.accepter.image')]; break;
        case 'partups_contributions_rejected': images = [get(notification, 'type_data.rejecter.image')]; break;
        case 'partups_user_mentioned': images = [get(notification, 'type_data.mentioning_upper.image')]; break;
        case 'contributions_ratings_inserted': images = [get(notification, 'type_data.rater.image')]; break;
        case 'partups_new_comment_in_involved_conversation': images = [get(notification, 'type_data.commenter.image')]; break;
        case 'partups_networks_new_upper': images = [get(notification, 'type_data.upper.image')]; break;
        case 'partups_networks_upper_left': images = [get(notification, 'type_data.upper.image')]; break;
        case 'multiple_comments_in_conversation_since_visit': images = [get(notification, 'type_data.latest_upper.image')]; break;
        case 'partups_multiple_updates_since_visit': images = [get(notification, 'type_data.latest_upper.image')]; break;
        case 'networks_multiple_new_uppers_since_visit': images = [get(notification, 'type_data.network.image')]; break;
        default: return;
    }

    return Images.find({_id: {'$in': images}});
};

/**
 * Find images for an update
 *
 * @memberOf Images
 * @param {Update} update
 * @return {Mongo.Cursor}
 */
Images.findForUpdate = function(update) {
    var images = [];

    switch (update.type) {
        case 'partups_image_changed': images = [update.type_data.old_image, update.type_data.new_image]; break;
        case 'partups_message_added': images = update.type_data.images || []; break;
        default: return;
    }

    return Images.find({_id: {'$in': images}});
};

/**
 * Find images for the comments in an update
 *
 * @memberOf Images
 * @param {Update} update
 * @return {Mongo.Cursor}
 */
Images.findForUpdateComments = function(update) {
    update = update || {};

    var imageIds = (update.comments || []).map(function(comment) {
        return comment.creator.image;
    });

    return Images.find({_id: {'$in': imageIds}});
};

Images.findForTile = function(tile) {
    return Images.find({_id: tile.image_id}, {limit: 1});
};

Images.findForSwarm = function(swarm) {
    return Images.find({_id: swarm.image}, {limit: 1});
};

Images.findForContentBlock = function(contentBlock) {
    return Images.find({_id: contentBlock.image});
};

Images.allow({
    insert: function(userId, document) {
        return !!userId;
    }
});


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/ratings.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Ratings are user chosen numerical feedback to contributions
 *
 * @namespace Ratings
 * @memberOf Collection
 */
Ratings = new Mongo.Collection('ratings');

// Add indices
if (Meteor.isServer) {
    Ratings._ensureIndex('rating');
    Ratings._ensureIndex('partup_id');
    Ratings._ensureIndex('activity_id');
    Ratings._ensureIndex('contribution_id');
    Ratings._ensureIndex('upper_id');
    Ratings._ensureIndex('rated_upper_id');
}

/**
 * Find ratings for contribution
 *
 * @memberOf Ratings
 * @param {Contributions} contribution
 * @return {Mongo.Cursor}
 */
Ratings.findForContribution = function(contribution) {
    return Ratings.find({contribution_id: contribution._id});
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/networks.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @memberOf Networks
 * @private
 */
var NETWORK_PUBLIC = 1;
/**
 * @memberOf Networks
 * @private
 */
var NETWORK_INVITE = 2;
/**
 * @memberOf Networks
 * @private
 */
var NETWORK_CLOSED = 3;

/**
 * Network model
 *
 * @memberOf Networks
 */
var Network = function(document) {
    _.extend(this, document);
};

/**
 * Check if given user is admin of this network
 *
 * @memberOf Networks
 * @param {String} userId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.isNetworkAdmin = function(userId) {
    if (!userId) return false;
    return mout.lang.isString(userId) && (this.admins.indexOf(userId) > -1);
};

/**
 * Check if given user is the super admin or admin of this network
 *
 * @memberOf Networks
 * @param {String} userId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.isAdmin = function(userId) {
    if (!userId) return false;
    var user = Meteor.users.findOne({_id: userId});
    if (!user) return false;
    return this.isNetworkAdmin(userId) || User(user).isAdmin();
};

/**
 * Check if given user is a member of this network
 *
 * @memberOf Networks
 * @param {String} userId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.hasMember = function(userId) {
    if (!userId) return false;
    var uppers = this.uppers || [];
    return mout.lang.isString(userId) && uppers.indexOf(userId) > -1;
};

/**
 * Check if given network has public access
 *
 * @memberOf Networks
 * @return {Boolean}
 */
Network.prototype.isPublic = function() {
    return this.privacy_type === NETWORK_PUBLIC;
};

/**
 * Check if given network is private and for invites only
 *
 * @memberOf Networks
 * @return {Boolean}
 */
Network.prototype.isInvitational = function() {
    return this.privacy_type === NETWORK_INVITE;
};

/**
 * Check if given network is private and closed
 *
 * @memberOf Networks
 * @return {Boolean}
 */
Network.prototype.isClosed = function() {
    return this.privacy_type === NETWORK_CLOSED;
};

/**
 * Check if given network is closed for specific user
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.isClosedForUpper = function(upperId) {
    if (this.isPublic()) return false;
    if (!upperId) return true;
    if (this.isAdmin(upperId)) return false;
    if (this.hasMember(upperId)) return false;

    return true;
};

/**
 * Check if upper is already invited to the network
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.isUpperInvited = function(upperId) {
    if (!upperId) return false;
    return !!Invites.findOne({
        network_id: this._id,
        invitee_id: upperId
    });
};

/**
 * Check if the upper-invite is pending (to be accepted by admin)
 *
 * @memberOf Networks
 * @param {String} userId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.isUpperInvitePending = function(userId) {
    if (!this.pending_uppers || !userId) return false;
    return mout.lang.isString(userId) && this.pending_uppers.indexOf(userId) > -1;
};

/**
 * Check if upper can invite other uppers
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.canUpperInvite = function(upperId) {
    if (!upperId) return false;
    return this.hasMember(upperId);
};

/**
 * Check if upper can join network
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.canUpperJoin = function(upperId) {
    if (!upperId) return false;
    if (this.isPublic()) return true;
    if (this.isUpperInvited(upperId)) return true;
    return false;
};

/**
 * Add Upper to Network
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user to be added
 */
Network.prototype.addUpper = function(upperId) {
    Networks.update(this._id, {$addToSet: {uppers: upperId}, $inc: {upper_count: 1}});
    Meteor.users.update(upperId, {$addToSet: {networks: this._id}});
    this.removeAllUpperInvites(upperId);
};

/**
 * Add upper to pending list
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user to be added
 */
Network.prototype.addPendingUpper = function(upperId) {
    // Check if user is already added as a pending upper
    if (this.isUpperPending(upperId)) {
        return false;
    }

    Networks.update(this._id, {$addToSet: {pending_uppers: upperId}});
    Meteor.users.update(upperId, {$addToSet: {pending_networks: this._id}});
};

/**
 * Check if upper is already added to the pending list
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.isUpperPending = function(upperId) {
    if (!upperId) return false;
    return !!Networks.findOne({_id: this._id, pending_uppers: {'$in': [upperId]}});
};

/**
 * Check if upper is invited by an admin
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user to be checked
 * @return {Boolean}
 */
Network.prototype.isUpperInvitedByAdmin = function(upperId) {
    if (!upperId) return false;
    var invitedByAdmin = false;
    var invites = Invites.find({type: Invites.INVITE_TYPE_NETWORK_EXISTING_UPPER, network_id: this._id, invitee_id: upperId});
    var self = this;

    // A user can be invited multiple times, so check all of them
    invites.forEach(function(invite) {
        // Set variable to true when matching the criteria
        if (self.isAdmin(invite.inviter_id)) invitedByAdmin = true;
    });

    return invitedByAdmin;
};

/**
 * Consume an access token to add the user as an invitee
 *
 * @memberOf Partups
 * @param {String} upperId
 * @param {String} accessToken
 */
Network.prototype.convertAccessTokenToInvite = function(upperId, accessToken) {
    // Find and update the current invite
    var invite = Invites.findOne({
        type: Invites.INVITE_TYPE_NETWORK_EMAIL,
        access_token: accessToken,
        network_id: this._id
    });

    if (!invite) return;

    Invites.update(invite._id, {$set: {
        type: Invites.INVITE_TYPE_NETWORK_EXISTING_UPPER,
        invitee_id: upperId,
        updated_at: new Date
    }});

    // Also remove the access token from the network and add the new invite to the network
    Networks.update(this._id, {
        $pull: {'access_tokens': accessToken},
        $addToSet: {'invites': {_id: upperId, invited_by_id: invite.inviter_id, invited_at: invite.created_at}}
    });
};

/**
 * Accept a pending upper to the network
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user that should be accepted
 */
Network.prototype.acceptPendingUpper = function(upperId) {
    Networks.update(this._id, {$pull: {pending_uppers: upperId}, $addToSet: {uppers: upperId}, $inc: {upper_count: 1}});
    Meteor.users.update(upperId, {$pull: {pending_networks: this._id}, $addToSet: {networks: this._id}});
    this.removeAllUpperInvites(upperId);
};

/**
 * Reject a pending upper
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user that should be rejected
 */
Network.prototype.rejectPendingUpper = function(upperId) {
    Networks.update(this._id, {$pull: {pending_uppers: upperId}});
    Invites.remove({
        'network_id': this._id,
        'invitee_id': upperId
    });
    Meteor.users.update(upperId, {$pull: {pending_networks: this._id}});
};

/**
 * Remove all invites for a specific user for this network
 *
 * @memberOf Invites
 * @param {String} upperId id of the user whose invites have to be removed
 */
Network.prototype.removeAllUpperInvites = function(upperId) {
    // Clear out the invites from Invites collection
    Invites.remove({network_id: this._id, invitee_id: upperId});

    // And don't forget the invites property of this network
    var invites = this.invites || [];
    var self = this;
    invites.forEach(function(invite) {
        if (invite._id === upperId) {
            Networks.update(self._id, {$pull: {invites: invite}});
        }
    });
};

/**
 * Leave network
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user that is leaving the network
 */
Network.prototype.leave = function(upperId) {
    Networks.update(this._id, {$pull: {uppers: upperId}, $inc: {upper_count: -1}});
    Meteor.users.update(upperId, {$pull: {networks: this._id}});
};

Network.prototype.displayTags = function(slug) {
    var maxTags = 5;
    var tags = [];
    var commonTags = this.common_tags || [];
    var customTags = this.tags || [];

    _.times(maxTags, function() {
        var tag = commonTags.shift();
        if (!tag) return;
        tags.push({
            tag: tag.tag,
            networkSlug: slug || ''
        });
    });

    if (tags.length === maxTags) return tags;

    _.times((maxTags - tags.length), function() {
        var tag = customTags.shift();
        if (!tag) return;
        tags.push({
            tag: tag,
            networkSlug: slug || ''
        });
    });

    return tags;
};

/**
 * Make a user an admin
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user that is being added as an admin
 */
Network.prototype.addAdmin = function(upperId) {
    Networks.update(this._id, {$push: {admins: upperId}});
};

/**
 * Remove user from admins
 *
 * @memberOf Networks
 * @param {String} upperId the user id of the user that is being removed from admins
 */
Network.prototype.removeAdmin = function(upperId) {
    Networks.update(this._id, {$pull: {admins: upperId}});
};

/**
 * Checks if a ContentBlock belongs to this network
 *
 * @memberOf Networks
 * @param {String} contentBlockId
 */
Network.prototype.hasContentBlock = function(contentBlockId) {
    var contentBlocks = this.contentblocks || [];
    return mout.lang.isString(contentBlockId) && contentBlocks.indexOf(contentBlockId) > -1;
};

/**
 Networks, also known as "Tribes" are entities that group users and partups
 @namespace Networks
 */
Networks = new Mongo.Collection('networks', {
    transform: function(document) {
        return new Network(document);
    }
});

// Add indices
if (Meteor.isServer) {
    Networks._ensureIndex('slug');
    Networks._ensureIndex('admins');
    Networks._ensureIndex('privacy_type');
}

/**
 * @memberOf Networks
 * @public
 */
Networks.NETWORK_PUBLIC = NETWORK_PUBLIC;
/**
 * @memberOf Networks
 * @public
 */
Networks.NETWORK_INVITE = NETWORK_INVITE;
/**
 * @memberOf Networks
 * @public
 */
Networks.NETWORK_CLOSED = NETWORK_CLOSED;

/**
 * Modified version of Collection.find that makes
 * sure the user (or guest) can only retrieve
 * fields that are publicly available
 *
 * @memberOf Networks
 * @param {Object} selector
 * @param {Object} options
 * @return {Cursor}
 */
Networks.guardedMetaFind = function(selector, options) {
    selector = selector || {};
    options = options || {};

    // Make sure that if the callee doesn't pass the fields
    // key used in the options parameter, we set it with
    // the _id fields, so we do not publish all fields
    // by default, which would be a security issue
    options.fields = {_id: 1};

    // The fields that should be available on each network
    var unguardedFields = ['_id', 'name', 'description', 'website', 'slug', 'icon', 'image', 'privacy_type', 'pending_uppers', 'invites', 'language', 'tags', 'location', 'stats', 'swarms', 'background_image', 'common_tags', 'most_active_partups', 'most_active_uppers', 'admins'];

    unguardedFields.forEach(function(unguardedField) {
        options.fields[unguardedField] = 1;
    });

    return this.find(selector, options);
};

/**
 * Networks collection helpers
 *
 * @memberOf Networks
 * @param {String} userId the user id of the current user
 * @param {Object} selector the requested selector
 * @param {Object} options options object to be passed to mongo find (limit etc.)
 * @return {Mongo.Cursor}
 */
Networks.guardedFind = function(userId, selector, options) {
    if (Meteor.isClient) return this.find(selector, options);

    selector = selector || {};
    options = options || {};

    // The fields that should never be exposed
    var guardedFields = ['access_tokens'];
    options.fields = options.fields || {};

    guardedFields.forEach(function(guardedField) {
        options.fields[guardedField] = 0;
    });

    var guardedCriterias = [
        // The network is open, which means everyone can access it
        {'privacy_type': {'$in': [Networks.NETWORK_PUBLIC]}},
    ];

    // Some extra rules that are only applicable to users that are logged in
    if (userId) {
        // The user is part of the network uppers, which means he has access anyway
        guardedCriterias.push({'uppers': {'$in': [userId]}});

        // Of course the admin of a network always has the needed rights
        guardedCriterias.push({'admins': {'$in': [userId]}});
    }

    // Guarding selector that needs to be fulfilled
    var guardingSelector = {'$or': guardedCriterias};

    // Merge the selectors, so we still use the initial selector provided by the caller
    var finalSelector = {'$and': [guardingSelector, selector]};

    return this.find(finalSelector, options);
};

/**
 * Find featured networks
 *
 * @memberOf Networks
 * @param {String} language
 * @return {Mongo.Cursor}
 */
Networks.findFeatured = function(language) {
    var selector = {'featured.active': true};
    if (language) {
        selector.language = language;
    }
    return Networks.find(selector);
};

/**
 * Find the network for a partup
 *
 * @memberOf Networks
 * @param {Partup} partup
 * @param {String} userId
 * @return {Mongo.Cursor}
 */
Networks.findForPartup = function(partup, userId) {
    return Networks.guardedFind(userId, {_id: partup.network_id}, {limit: 1});
};

/**
 * Find the networks for a user
 *
 * @memberOf Networks
 * @param {User} user
 * @param {String} userId
 * @return {Mongo.Cursor}
 */
Networks.findForUser = function(user, userId, options) {
    var networks = user.networks || [];
    return Networks.guardedFind(userId, {_id: {'$in': networks}}, options);
};

/**
 * Find the networks for a user
 *
 * @memberOf Networks
 * @param {String} loggedInUserId
 * @param {Object} options - mongo query options
 * @return {Mongo.Cursor}
 */
Networks.findForDiscoverFilter = function(loggedInUserId, options) {
    options = options || {};

    options.sort = options.sort || {};
    //TODO: add sort rule for loggedInUserId existance in network.uppers
    options.sort.upper_count = -1;

    return Networks.guardedFind(loggedInUserId, {}, options);
};

/**
 * Find the networks in a swarm
 *
 * @memberOf Networks
 * @param {Swarm} swarm
 * @param {String} userId
 * @return {Mongo.Cursor}
 */
Networks.findForSwarm = function(swarm, userId) {
    var networks = swarm.networks || [];
    return Networks.guardedFind(userId, {_id: {$in: networks}}, {});
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/users.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @namespace Users
 * @name Users
 */

//N.B.: Meteor.users is already defined by meteor

// Deny updating the profile object from client
Meteor.users.deny({
    update: function() {
        return true;
    }
});

//user fields to all users
var publicUserFields = {
    'profile.description': 1,
    'profile.facebook_url': 1,
    'profile.image': 1,
    'profile.instagram_url': 1,
    'profile.linkedin_url': 1,
    'profile.location': 1,
    'profile.name': 1,
    'profile.skype': 1,
    'profile.tags': 1,
    'profile.twitter_url': 1,
    'profile.website': 1,
    'profile.meurs.results': 1,
    'profile.meurs.fetched_results': 1,
    'profile.tiles': 1,
    'status.online': 1,
    'partups': 1,
    'upperOf': 1,
    'supporterOf': 1,
    'average_rating': 1,
    'networks': 1,
    'completeness': 1,
    'participation_score': 1,
    'chats': 1
};

//user fields exposed to logged in user
var privateUserFields = mout.object.merge({
    'emails': 1,
    'profile.phonenumber': 1,
    'profile.settings': 1,
    'pending_networks': 1,
    'roles': 1,
    'chats': 1
}, publicUserFields);

// Add indices
if (Meteor.isServer) {
    Meteor.users._ensureIndex('participation_score');
}

/**
 * Find a user and expose it's private fields
 *
 * @memberOf Meteor.users
 * @param {String} userId
 * @return {Mongo.Cursor}
 */
Meteor.users.findSinglePrivateProfile = function(userId) {
    return Meteor.users.find({_id: userId}, {fields: privateUserFields});
};

/**
 * Find a user and expose it's public fields
 *
 * @memberOf Meteor.users
 * @param {String} userId
 * @return {Mongo.Cursor}
 */
Meteor.users.findSinglePublicProfile = function(userId) {
    return Meteor.users.find({_id: userId}, {fields: publicUserFields});
};

/**
 * Find users and expose their public fields
 *
 * @memberOf Meteor.users
 * @param {[String]} userIds
 * @param {Object} options
 * @param {Object} parameters
 * @return {Mongo.Cursor}
 */
Meteor.users.findMultiplePublicProfiles = function(userIds, options, parameters) {
    userIds = userIds || [];
    options = options || {};
    parameters = parameters || {};
    var textSearch = parameters.textSearch || undefined;

    var selector = {_id: {$in: userIds}};
    if (parameters.onlyActive) selector.deactivatedAt = {$exists: false};

    options.fields = _.clone(publicUserFields);

    if (parameters.isAdminOfNetwork) {
        options.fields.emails = 1;
    }

    if (parameters.hackyReplaceSelectorWithChatId) {
        delete selector._id;
        selector.chats = {$in: [parameters.hackyReplaceSelectorWithChatId]};
    }

    // Filter the uppers that match the text search
    if (textSearch) {
        Log.debug('Searching for [' + textSearch + ']');

        // Remove accents that might have been added to the query
        var searchQuery = mout.string.replaceAccents(textSearch.toLowerCase());

        // Set the search criteria
        var searchCriteria = [
            {'profile.normalized_name': new RegExp('.*' + searchQuery + '.*', 'i')},
            {'profile.description': new RegExp('.*' + searchQuery + '.*', 'i')},
            {'profile.tags': new RegExp('.*' + searchQuery + '.*', 'i')},
            {'profile.location.city': new RegExp('.*' + searchQuery + '.*', 'i')}
        ];

        // Search for separate tags if multiple words are detected in searchQuery
        var multipleWordsQuery = searchQuery.split(' ');
        if (multipleWordsQuery.length > 1) {
            searchCriteria.push({'profile.tags': {$in: multipleWordsQuery}});
        }

        // Combine it in an $or selector
        selector = {$and: [selector, {$or: searchCriteria}]};
    }

    options.limit = parameters.count ? undefined : parseInt(options.limit) || undefined;
    options.sort = parameters.count ? undefined : options.sort || undefined;

    return Meteor.users.find(selector, options);
};

/**
 * Find the uppers in a network
 *
 * @memberOf Meteor.users
 * @param {Network} network
 * @param {Object} options
 * @param {Object} parameters
 * @return {Mongo.Cursor}
 */
Meteor.users.findUppersForNetwork = function(network, options, parameters) {
    var uppers = network.uppers || [];

    parameters = parameters || {};
    parameters.onlyActive = true;

    return this.findMultiplePublicProfiles(uppers, options, parameters);
};

/**
 * Find the uppers of a partup
 *
 * @memberOf Meteor.users
 * @param {Partup} partup
 * @return {Mongo.Cursor}
 */
Meteor.users.findUppersForPartup = function(partup) {
    var uppers = partup.uppers || [];
    return Meteor.users.findMultiplePublicProfiles(uppers);
};

/**
 * Find the supporters of a partup
 *
 * @memberOf Meteor.users
 * @param {Partup} partup
 * @return {Mongo.Cursor}
 */
Meteor.users.findSupportersForPartup = function(partup) {
    var supporters = partup.supporters || [];
    return Meteor.users.findMultiplePublicProfiles(supporters);
};

/**
 * Find the partners of an upper
 *
 * @memberOf Meteor.users
 * @return {Mongo.Cursor}
 */
Meteor.users.findPartnersForUpper = function(upper) {
    var upper_partups = upper.upperOf || [];
    var upper_partners = [];

    // Gather all upper IDs from the partups the user is partner of
    upper_partups.forEach(function(partupId) {
        var partup = Partups.findOne(partupId);
        var partup_uppers = partup.uppers || [];
        upper_partners.push.apply(upper_partners, partup_uppers);
    });

    // Remove duplicates and the requested user from the partner list
    var partners = lodash.chain(upper_partners)
        .unique()
        .pull(upper._id)
        .value();

    return Meteor.users.findMultiplePublicProfiles(partners);
};

/**
 * Find the user of an update
 *
 * @memberOf Meteor.users
 * @param {Update} update
 * @return {Mongo.Cursor}
 */
Meteor.users.findUserForUpdate = function(update) {
    return Meteor.users.findSinglePublicProfile(update.upper_id);
};

/**
 * Find the user of a rating
 *
 * @memberOf Meteor.users
 * @param {Ratings} rating
 * @return {Mongo.Cursor}
 */
Meteor.users.findForRating = function(rating) {
    return Meteor.users.findSinglePublicProfile(rating.upper_id);
};

/**
 * Find the user of a contribution
 *
 * @memberOf Meteor.users
 * @param {Contributions} contribution
 * @return {Mongo.Cursor}
 */
Meteor.users.findForContribution = function(contribution) {
    return Meteor.users.findSinglePublicProfile(contribution.upper_id);
};

/**
 * Safely find users that are not disabled
 *
 * @memberOf Meteor.users
 * @param {Object} selector
 * @param {Object} options
 * @return {Mongo.Cursor}
 */
Meteor.users.findActiveUsers = function(selector, options) {
    selector = selector || {};
    options = options || {};
    if (!options.fields) {
        options.fields = publicUserFields;
    }

    selector.deactivatedAt = {$exists: false};
    options.fields = publicUserFields;
    return Meteor.users.find(selector, options);
};

/**
 * Find for admin list
 *
 * @memberOf Meteor.users
 * @param {Object} selector
 * @param {Object} options
 * @return {Mongo.Cursor}
 */
Meteor.users.findForAdminList = function(selector, options) {
    selector = selector || {};

    var limit = options.limit;
    var page = options.page;

    return Meteor.users.find(selector, {
        fields:{'_id':1, 'profile.name':1, 'profile.phonenumber':1, 'registered_emails':1, 'createdAt':1, 'deactivatedAt':1},
        sort: {'createdAt': -1},
        limit: limit,
        skip: limit * page
    });
};

Meteor.users.findStatsForAdmin = function() {
    return {
        'servicecounts': {
            'password': Meteor.users.find({'services.password':{'$exists':true}}).count(),
            'linkedin': Meteor.users.find({'services.linkedin':{'$exists':true}}).count(),
            'facebook': Meteor.users.find({'services.facebook':{'$exists':true}}).count()
        },
        'counts': {
            'users': Meteor.users.find({}).count(),
            'notifications': Notifications.find({}).count(),
            'activities': Activities.find({}).count(),
            'contributions': Contributions.find({}).count(),
            'ratings': Ratings.find({}).count()
        }
    };
};

/**
 * Find by token
 *
 * @memberOf Meteor.users
 * @param {String} token
 * @return {Mongo.Cursor}
 */
Meteor.users.findByUnsubscribeEmailToken = function(token) {
    return Meteor.users.find({'profile.settings.unsubscribe_email_token': token}, {'_id': 1, 'profile.settings.email': 1}, {});
};

/**
 * User model (not a constructor, unlike all other entity models)
 * @ignore
 */
User = function(user) {
    return {

        /**
         * Get the first name of a user
         *
         * @return {String}
         */
        getFirstname: function() {
            if (!user) return;
            if (!user.profile) return;

            var name = user.profile.name || user.name;
            if (!name) return;

            if (name.match(/.*\s.*/)) {
                return name.split(' ')[0];
            } else {
                return name;
            }
        },

        isPartnerInPartup: function(partupId) {
            var upperOf = user.upperOf || [];
            return upperOf.indexOf(partupId) > -1;
        },

        /**
         * Get user's locale code
         */
        getLocale: function() {
            if (!user) return 'nl';

            var locale = mout.object.get(user, 'profile.settings.locale') || 'nl';

            if (!mout.object.has(TAPi18n.getLanguages(), locale)) {
                locale = 'nl';
            }

            return locale;
        },

        /**
         * Get users email address
         *
         * @return {String}
         */
        getEmail: function() {
            if (!user) return undefined;
            if (user.emails && user.emails.length > 0) {
                return user.emails[0].address;
            }
            if (user.registered_emails && user.registered_emails.length > 0) {
                return user.registered_emails[0].address;
            }
        },

        /**
         * Check if user is active
         *
         * @return {Boolean}
         */
        isActive: function() {
            if (!user) return false;
            if (user.deactivatedAt) {
                return false;
            } else {
                return true;
            }
        },

        /**
         * Check if user is admin
         *
         * @return {Boolean}
         */
        isAdmin: function() {
            if (!user) return false;
            if (!user.roles) return false;
            return user.roles.indexOf('admin') > -1;
        },

        /**
         * Check if user is admin of some tribe
         *
         * @return {Boolean}
         */
        isSomeNetworkAdmin: function() {
            if (!user) return false;
            return !!Networks.findOne({admins: {$in: [user._id]}});
        },

        /**
         * Check if user is admin of a swarm
         *
         * @return {Boolean}
         */
        isSwarmAdmin: function(swarmId) {
            if (!user) return false;
            return !!Swarms.findOne({_id: swarmId, admin_id: user._id});
        },

        /**
         * Get the user score
         *
         * @return {Number} participation score rounded
         */
        getReadableScore: function() {
            if (!user) return undefined;

            var score = user.participation_score ? user.participation_score : 0;

            // For design purposes, we only want to display
            // a max value of 99 and a min value of 10,
            // every number should be a natural one
            score = Math.min(99, score);
            score = Math.max(10, score);
            score = Math.round(score);

            return score;
        },
        /**
         * Check if user profile is filled enough to view the about page
         *
         * @return {Boolean}
         */
        aboutPageIsViewable: function() {
            var currentUserId = Meteor.userId();

            if (user._id === currentUserId) return true;

            if (user.profile.meurs && user.profile.meurs.results && user.profile.meurs.fetched_results) return true;

            if (user.profile.tiles && user.profile.tiles.length > 0) return true;

            return false;
        },

        /**
         * Function to calculate application icon badge number (iOS only, for now)
         *
         * @returns {Number} app icon badge number
         */
        calculateApplicationIconBadgeNumber: function() {
            return 0;
        }
    };
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/tags.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Tags
 @name Tags
 */
Tags = new Mongo.Collection('tags');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/places.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Places
 @name Places
 */
Places = new Mongo.Collection('places');

// Add indices
if (Meteor.isServer) {
    Places._ensureIndex('place_id');
    Places._ensureIndex({'created_at': 1}, {expireAfterSeconds: 604800});
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/places_autocompletes.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace PlacesAutocompletes
 @name PlacesAutocompletes
 */
PlacesAutocompletes = new Mongo.Collection('places_autocompletes');

// Add indices
if (Meteor.isServer) {
    PlacesAutocompletes._ensureIndex('query');
    PlacesAutocompletes._ensureIndex({'created_at': 1}, {expireAfterSeconds: 604800});
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/languages.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Languages
 @name Languages
 */
Languages = new Mongo.Collection('languages');

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/tiles.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @ignore
 */
var Tile = function(document) {
    _.extend(this, document);
};

/*
    supported formats are
    http://www.youtube.com/watch?v=0zM3nApSvMg&feature=feedrec_grec_index
    http://www.youtube.com/user/IngridMichaelsonVEVO#p/a/u/1/QdK8U-VIH_o
    http://www.youtube.com/v/0zM3nApSvMg?fs=1&amp;hl=en_US&amp;rel=0
    http://www.youtube.com/watch?v=0zM3nApSvMg#t=0m10s
    http://www.youtube.com/embed/0zM3nApSvMg?rel=0
    http://www.youtube.com/watch?v=0zM3nApSvMg
    http://youtu.be/0zM3nApSvMg
*/

var getYoutubeIdFromUrl = function(url) {
    var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    var match = url.match(regExp);
    if (match && match[2].length == 11) {
        return match[2];
    } else {
        return false;
    }
};
/*
    supported formats are
    http://vimeo.com/6701902
    http://vimeo.com/670190233
    http://player.vimeo.com/video/67019023
    http://player.vimeo.com/video/6701902
    http://player.vimeo.com/video/67019022?title=0&amp;byline=0&amp;portrait=0
    http://player.vimeo.com/video/6719022?title=0&amp;byline=0&amp;portrait=0
    http://vimeo.com/channels/vimeogirls/6701902
    http://vimeo.com/channels/vimeogirls/67019023
    http://vimeo.com/channels/staffpicks/67019026
    http://vimeo.com/15414122
    http://vimeo.com/channels/vimeogirls/66882931
*/

var getVimeoIdFromUrl = function(url) {
    var regExp = /(https?:\/\/)?(www\.)?(player\.)?vimeo\.com\/([a-z]*\/)*([0-9]{6,11})[?]?.*/;
    var match = url.match(regExp);
    if (match && match[5]) {
        return match[5];
    } else {
        return false;
    }
};
/**
 * Returns the embedsettings for vimeo or youtube
 *
 * @memberof Tiles
 * @return {Object} embed type and type id
 */
Tile.prototype.embedSettings = function() {
    var settings = {};
    // Vimeo settings
    if (this.video_url.indexOf('vimeo') > -1) {
        settings.type = 'vimeo';
        settings.vimeo_id = getVimeoIdFromUrl(this.video_url);
    }
    // YouTube settings
    if (this.video_url.indexOf('youtube') > -1 || this.video_url.indexOf('youtu.be') > -1) {
        settings.type = 'youtube';
        settings.youtube_id = getYoutubeIdFromUrl(this.video_url);
    }
    return settings;
};

/**
 @namespace Tiles
 @name Tiles
 */
Tiles = new Mongo.Collection('tiles', {
    transform: function(document) {
        return new Tile(document);
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/swarms.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Swarm model
 *
 * @memberOf Swarms
 */
var Swarm = function(document) {
    _.extend(this, document);
};

/**
 * Check if given user is admin of this swarm
 *
 * @memberOf Swarms
 * @param {String} userId the user id of the user to be checked
 * @return {Boolean}
 */
Swarm.prototype.isSwarmAdmin = function(userId) {
    if (!userId) return false;
    return mout.lang.isString(userId) && (userId === this.admin_id);
};

/**
 * Check if given user is the super admin or admin of this swarm
 *
 * @memberOf Swarms
 * @param {String} userId the user id of the user to be checked
 * @return {Boolean}
 */
Swarm.prototype.isAdmin = function(userId) {
    if (!userId) return false;
    var user = Meteor.users.findOne({_id: userId});
    if (!user) return false;
    return this.isSwarmAdmin(userId) || User(user).isAdmin();
};

/**
 * Add network to swarm
 *
 * @memberOf Swarms
 * @param {String} networkId the id of the network to be added to the swarm
 */
Swarm.prototype.addNetwork = function(networkId) {
    Swarms.update(this._id, {$addToSet: {networks: networkId}});
    Networks.update(networkId, {$addToSet: {swarms: this._id}});
};

/**
 * Remove network from swarm
 *
 * @memberOf Swarms
 * @param {String} networkId the id of the network that is being removed from the swarm
 */
Swarm.prototype.removeNetwork = function(networkId) {
    Swarms.update(this._id, {$pull: {networks: networkId}});
    Networks.update(networkId, {$pull: {swarms: this._id}});
};

/**
 * Increase email share count
 *
 * @memberOf Swarms
 */
Swarm.prototype.increaseEmailShareCount = function() {
    Swarms.update({_id: this._id}, {$inc: {'shared_count.email': 1}});
};

/**
 Swarms are entities that group networks (also known as tribes)
 @namespace Swarms
 */
Swarms = new Mongo.Collection('swarms', {
    transform: function(document) {
        return new Swarm(document);
    }
});

// Add indices
if (Meteor.isServer) {
    Swarms._ensureIndex('slug');
    Swarms._ensureIndex('admin_id');
}

/**
 * Modified version of Collection.find that makes
 * sure the user (or guest) can only retrieve
 * fields that are publicly available
 *
 * @memberOf Swarms
 * @param {Object} selector
 * @param {Object} options
 * @return {Cursor}
 */
Swarms.guardedMetaFind = function(selector, options) {
    selector = selector || {};
    options = options || {};

    // Make sure that if the callee doesn't pass the fields
    // key used in the options parameter, we set it with
    // the _id fields, so we do not publish all fields
    // by default, which would be a security issue
    options.fields = {_id: 1};

    // The fields that should be available on each swarm
    var unguardedFields = ['name', 'title', 'introduction', 'description', 'slug', 'image', 'networks', 'quotes'];

    unguardedFields.forEach(function(unguardedField) {
        options.fields[unguardedField] = 1;
    });

    return this.find(selector, options);
};

/**
 * Swarms collection helpers
 *
 * @memberOf Swarms
 * @param {String} userId the user id of the current user
 * @param {Object} selector the requested selector
 * @param {Object} options options object to be passed to mongo find (limit etc.)
 * @return {Mongo.Cursor}
 */
Swarms.guardedFind = function(userId, selector, options) {
    if (Meteor.isClient) return this.find(selector, options);

    selector = selector || {};
    options = options || {};

    // The fields that should never be exposed
    var guardedFields = [
        //
    ];
    options.fields = options.fields || {};

    guardedFields.forEach(function(guardedField) {
        options.fields[guardedField] = 0;
    });

    return this.find(selector, options);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/contentblock.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @ignore
 */
var ContentBlock = function(document) {
    _.extend(this, document);
};

/**
 @namespace ContentBlocks
 @name ContentBlocks
 */
ContentBlocks = new Mongo.Collection('contentblocks', {
    transform: function(document) {
        return new ContentBlock(document);
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/chats.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Chat model
 *
 * @memberOf Chats
 */
var Chat = function(document) {
    _.extend(this, document);
};

/**
 * Set a user as typing
 *
 * @memberOf Chats
 * @param {String} userId the user id of the user that started typing
 * @param {Date} typingDate the front-end date of when the user started typing
 */
Chat.prototype.startedTyping = function(userId, typingDate) {
    var typingObject = Chats.findOne({_id: this._id, 'started_typing.upper_id': userId});
    if (typingObject) {
        Chats.update({_id: this._id, 'started_typing.upper_id': userId}, {$set: {'started_typing.$.date': typingDate}});
    } else {
        Chats.update(this._id, {$push: {started_typing: {upper_id: userId, date: typingDate}}});
    }
};

/**
 * Unset a typing user
 *
 * @memberOf Chats
 * @param {String} userId the user id of the user that stopped typing
 */
Chat.prototype.stoppedTyping = function(userId) {
    Chats.update(this._id, {$pull: {started_typing: {upper_id: userId}}});
};

/**
 * Get the unread chat count
 *
 * @memberOf Chats
 * @param {String} userId
 * @return {Mongo.Cursor}
 */
Chat.prototype.getUnreadCountForUser = function(userId) {
    var user = Meteor.users.findOneOrFail(userId);
    return ChatMessages.find({chat_id: this._id, read_by: {$nin: [user._id]}}).count();
};

/**
 @namespace Chats
 */
Chats = new Mongo.Collection('chats', {
    transform: function(document) {
        return new Chat(document);
    }
});

/**
 * Find chats for a single user
 *
 * @memberOf Chats
 * @param {String} userId
 * @return {Mongo.Cursor}
 */
Chats.findForUser = function(userId, options) {
    options = options || {};
    var user = Meteor.users.findOneOrFail(userId);

    // Begin with the private chats
    var userChats = user.chats || [];

    // And now collect the tribe chats
    var networks = Networks.find({_id: {$in: user.networks || []}});
    networks.forEach(function(network) {
        if (network.chat_id) userChats.push(network.chat_id);
    });

    if (!options.sort) {
        options.sort = {updated_at: -1};
    }

    // Return the IDs ordered by most recent
    return Chats.find({_id: {$in: userChats}}, options);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/collections/chatmessages.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * ChatMessage model
 *
 * @memberOf ChatMessages
 */
var ChatMessage = function(document) {
    _.extend(this, document);
};

/**
 * Add upper to seen message list
 *
 * @memberOf ChatMessages
 * @param {String} upperId
 * @return {Boolean}
 */
ChatMessage.prototype.addToSeen = function(upperId) {
    ChatMessages.update(this._id, {$addToSet: {seen_by: upperId}});
};

/**
 * Add upper to read message list
 *
 * @memberOf ChatMessages
 * @param {String} upperId
 * @return {Boolean}
 */
ChatMessage.prototype.addToRead = function(upperId) {
    ChatMessages.update(this._id, {$addToSet: {read_by: upperId}});
};

/**
 @namespace ChatMessages
 */
ChatMessages = new Mongo.Collection('chatmessages', {
    transform: function(document) {
        return new ChatMessage(document);
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/activity.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base Activity schema
 * @name activityBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var activityBaseSchema = new SimpleSchema({
    description: {
        type: String,
        max: 250,
        optional: true
    },
    end_date: {
        type: Date,
        optional: true
    },
    name: {
        type: String,
        max: 60
    }
});

/**
 * Activity entity schema
 * @name activity
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.activity = new SimpleSchema([activityBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    creator_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    archived: {
        type: Boolean,
        defaultValue: false
    },
    update_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    partup_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    }
}]);

/**
 * Activity form schema
 * @name startActivities
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.startActivities = new SimpleSchema([activityBaseSchema, {
    //
}]);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/update.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base Update schema
 * @name updateBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var updateBaseSchema = new SimpleSchema({
    type: {
        type: String
    },
    type_data: {
        type: Object
    },
    'type_data.new_value': {
        type: String
    },
    'type_data.old_value': {
        type: String
    },
    'type_data.upper': {
        type: Object
    },
    'type_data.upper._id': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    'type_data.upper.image': {
        type: Object,
        optional: true
    },
    'type_data.upper.name': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    }
});

/**
 * Base Comment Update schema
 * @name updateCommentBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var updateCommentBaseSchema = new SimpleSchema({
    content: {
        type: String,
        custom: function() {
            var commentLength = Partup.helpers.mentions.getTrueCharacterCount(this.value);
            if (commentLength > 1000) return 'exceedsMaxCharacterLength';
        }
    },
    type: {
        type: String,
        optional: true,
        allowedValues: ['motivation', 'system']
    }
});

/**
 * Update Comment entity schema
 * @name updateComment
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.updateComment = new SimpleSchema([updateCommentBaseSchema, {
    _id: {
        type: String
    },
    creator: {
        type: Object
    },
    'creator._id': {
        type: String
    },
    'creator.name': {
        type: String
    },
    'creator.image': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    }
}]);

/**
 * Update entity schema
 * @name update
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.update = new SimpleSchema([updateBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    comments: {
        type: [Partup.schemas.entities.updateComment],
        optional: true
    },
    comments_count: {
        type: Number,
        defaultValue: 0
    },
    partup_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    },
    upper_data: {
        type: [Object],
        optional: true
    },
    'upper_data.$._id': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    'upper_data.$.new_comments': {
        type: [String],
        optional: true
    }
}]);

/**
 * Insert Update Comment form schema
 * @name updateComment
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.updateComment = new SimpleSchema([updateCommentBaseSchema]);

/**
 * New message Form
 * @name newMessage
 * @memberof Partup.schemas.forms
 */

/**
 * Based on dropboxFile object response, but this is also the preferred
 * object file for every other services e.g. GoogleDrive
 * https://www.dropbox.com/developers/chooser
 * @type {SimpleSchema}
 */

var DocumentSchema = new SimpleSchema({
    _id: {
        type: String
    },
    mimeType: {
        type: String,
        optional: true
    },
    name: {
        type: String,
        optional: true
    },
    link: {
        type: String,
        optional: true
    },
    bytes: {
        type: Number,
        optional: true
    },
    icon: {
        type: String,
        optional: true
    },
    thumbnailLink: {
        type: String,
        optional: true
    },
    is_dir: {
        type: Boolean,
        optional: true
    },
    isDir: {
        type: Boolean,
        optional: true
    }
});


Partup.schemas.forms.newMessage = new SimpleSchema({
    text: {
        type: String,
        max: 10000
    },
    images: {
        type: [String],
        optional: true
    },
    documents: {
        type: [DocumentSchema],
        optional: true
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/contribution.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base Contribution schema
 * @name contributionBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var contributionBaseSchema = new SimpleSchema({
    currency: {
        type: String,
        optional: true,
        allowedValues: [
            'EUR',
            'USD',
            'GBP'
        ],
        autoform: {
            options: [
                {label: 'EUR', value: 'EUR'},
                {label: 'USD', value: 'USD'},
                {label: 'GBP', value: 'GBP'}
            ]
        }
    },
    hours: {
        type: Number,
        min: 0,
        optional: true
    },
    rate: {
        type: Number,
        min: 0,
        optional: true
    },
    motivation: {
        type: Partup.schemas.forms.updateComment,
        optional: true
    }
});

/**
 * Contribution entity schema
 * @name contribution
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.contribution = new SimpleSchema([contributionBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    activity_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    archived: {
        type: Boolean,
        defaultValue: false
    },
    created_at: {
        type: Date,
        defaultValue: Date.now()
    },
    partup_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    update_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    updated_at: {
        type: Date,
        defaultValue: Date.now()
    },
    upper_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    verified: {
        type: Boolean,
        defaultValue: false
    }
}]);

/**
 * Contribution Form
 * @name contribute
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.contribution = new SimpleSchema([contributionBaseSchema, {
    //
}]);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/forgotPassword.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Forgot password Form
 * @name forgotPassword
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.forgotPassword = new SimpleSchema({
    email: {
        type: String,
        max: 255,
        regEx: SimpleSchema.RegEx.Email
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/login.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Login Form
 * @name login
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.login = new SimpleSchema({
    email: {
        type: String,
        max: 255,
        regEx: SimpleSchema.RegEx.Email
    },
    password: {
        type: String,
        max: 255
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/network.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var tagsConfiguration = {
    tagClass: 'pu-tag pu-tag-disableglobalclick',
    maxTags: 5
};
/**
 * Base Network schema
 * @name networkBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var networkBaseSchema = new SimpleSchema({
    background_image: {
        type: String,
        optional: true
    },
    description: {
        type: String,
        max: 350,
        optional: true
    },
    icon: {
        type: String,
        optional: true
    },
    image: {
        type: String,
        optional: true
    },
    name: {
        type: String,
        max: 150
    },
    website: {
        type: String,
        max: 255,
        optional: true,
        regEx: Partup.services.validators.simpleSchemaUrlWithoutProtocol
    }
});

/**
 * Network entity schema
 * @name network
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.network = new SimpleSchema([networkBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    admins: {
        type: [String],
        regEx: SimpleSchema.RegEx.Id
    },
    chat_id: {
        type: String,
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    common_tags: {
        type: Object,
        optional: true
    },
    contentblocks: {
        type: [String],
        regEx: SimpleSchema.RegEx.Id
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    invites: {
        type: [Object],
        optional: true
    },
    location: {
        type: Object,
        optional: true
    },
    partups: {
        type: [String],
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    pending_uppers: {
        type: [Object],
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    'pending_uppers._id': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    'pending_uppers.invited_at': {
        type: Date,
        defaultValue: new Date()
    },
    'pending_uppers.invited_by_id': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    stats: {
        type: Object
    },
    'stats.activity_count': {
        type: Number,
        min: 0
    },
    'stats.partner_count': {
        type: Number,
        min: 0
    },
    'stats.partup_count': {
        type: Number,
        min: 0
    },
    'stats.supporter_count': {
        type: Number,
        min: 0
    },
    'stats.upper_count': {
        type: Number,
        min: 0
    },
    swarms: {
        type: [String],
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    tags: {
        type: [String],
        minCount: 1
    },
    'tags.$': {
        max: 30
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    },
    uppers: {
        type: [String],
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    }
}]);

/**
 * network form schema
 * @name network
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.network = new SimpleSchema([networkBaseSchema, {
    location_input: {
        type: String,
        max: 255
    },
    tags_input: {
        type: String,
        regEx: Partup.services.validators.tagsSeparatedByComma,
        custom: function() {
            var max = false;
            lodash.each(this.value.split(','), function(tag) {
                if (tag.length > 30) max = true;
            });

            if (max) return 'individualMaxString';
        },
        autoform: {
            type: 'tags',
            afFieldInput: tagsConfiguration
        }
    }
}]);

/**
 * network create form schema
 * @name networkCreate
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.networkCreate = new SimpleSchema([networkBaseSchema, {
    privacy_type: {
        type: Number,
        min: 1,
        max: 3
    }
}]);

/**
 * network create form schema
 * @name networkEdit
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.networkEdit = new SimpleSchema({
    admins: {
        type: [String],
        regEx: SimpleSchema.RegEx.Id
    }
});

/**
 * Feature network form schema
 * @name featureNetwork
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.featureNetwork = new SimpleSchema({
    active: {
        type: Boolean
    },
    comment: {
        type: String
    },
    author_id: {
        type: String
    },
    job_title: {
        type: String
    },
    language: {
        type: String,
        allowedValues: ['en', 'nl'],
        autoform: {
            options: [
                {label: 'English', value: 'en'},
                {label: 'Dutch', value: 'nl'},
            ]
        }
    },
    logo: {
        type: String
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/partup.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var tagsConfiguration = {
    tagClass: 'pu-tag pu-tag-disableglobalclick',
    maxTags: 5
};
/**
 * Base Partup schema
 * @name partupBaseSchema
 * @memberOf Partup.schemas
 * @private
 */
var partupBaseSchema = new SimpleSchema({
    description: {
        type: String,
        min: 10,
        max: 250
    },
    currency: {
        type: String,
        optional: true,
        allowedValues: [
            'EUR',
            'USD',
            'GBP'
        ],
        autoform: {
            options: [
                {label: 'EUR', value: 'EUR'},
                {label: 'USD', value: 'USD'},
                {label: 'GBP', value: 'GBP'}
            ]
        }
    },
    phase: {
        type: String,
        allowedValues: [
            Partups.PHASE.BRAINSTORM,
            Partups.PHASE.PLAN,
            Partups.PHASE.EXECUTE,
            Partups.PHASE.GROW
        ]
    },
    type: {
        type: String,
        allowedValues: [
            Partups.TYPE.CHARITY,
            Partups.TYPE.ENTERPRISING,
            Partups.TYPE.COMMERCIAL,
            Partups.TYPE.ORGANIZATION
        ]
    },
    type_commercial_budget: {
        type: Number,
        min: 0,
        optional: true,
        custom: function() {
            var required = this.field('type').value === Partups.TYPE.COMMERCIAL;
            if (required && !this.isSet) {
                return 'required';
            }
        }
    },
    type_organization_budget: {
        type: Number,
        min: 0,
        optional: true,
        custom: function() {
            var required = this.field('type').value === Partups.TYPE.ORGANIZATION;
            if (required && !this.isSet) {
                return 'required';
            }
        }
    },
    end_date: {
        type: Date,
        min: function() {
            var timezone = new Date().getTimezoneOffset() / 60;
            return new Date(new Date().setHours(-timezone, 0, 0, 0));
        }
    },
    partup_name: {
        type: String,
        max: 60
    },
    image: {
        type: String
    },
    network_id: {
        type: String,
        optional: true,
        regEx: SimpleSchema.RegEx.Id,
        custom: function() {
            if (this.field('privacy_type_input').value === 'network' && !this.isSet) {
                return 'required';
            }
        }
    }
});

/**
 * Partup entity schema
 * @name partup
 * @memberOf Partup.schemas.entities
 */
Partup.schemas.entities.partup = new SimpleSchema([partupBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    activity_count: {
        type: Number,
        defaultValue: 0
    },
    archived_at: {
        type: Date,
        optional: true
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    creator_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    featured: {
        type: Object,
        optional: true
    },
    'featured.active': {
        type: Boolean
    },
    'featured.by_upper': {
        type: Object
    },
    'featured.by_upper._id': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    'featured.by_upper.job_title': {
        type: String,
        optional: true
    },
    'featured.comment': {
        type: String
    },
    invites: {
        type: [String],
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    language: {
        type: String,
        min: 2,
        max: 5
    },
    location: {
        type: Object,
        optional: true
    },
    'location.city': {
        type: String
    },
    'location.country': {
        type: String
    },
    privacy_type: {
        type: Number,
        min: 1,
        max: 5
    },
    shared_count: {
        type: Object
    },
    'shared_count.facebook': {
        type: Number,
        min: 0
    },
    'shared_count.twitter': {
        type: Number,
        min: 0
    },
    'shared_count.linkedin': {
        type: Number,
        min: 0
    },
    'shared_count.email': {
        type: Number,
        min: 0
    },
    start_date: {
        type: Date
    },
    status: {
        type: String
    },
    supporters: {
        type: [String],
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    tags: {
        type: [String],
        minCount: 1
    },
    'tags.$': {
        max: 30
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    },
    uppers: {
        type: [String],
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    upper_data: {
        type: [Object],
        optional: true
    },
    'upper_data.$._id': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    'upper_data.$.new_updates': {
        type: [String],
        optional: true
    }
}]);

/**
 * start partup form schema
 * @name partupUpdate
 * @memberOf Partup.schemas.forms
 */
Partup.schemas.forms.partupUpdate = new SimpleSchema([partupBaseSchema, {
    focuspoint_x_input: {
        type: Number,
        min: 0,
        max: 1,
        decimal: true,
        optional: true
    },
    focuspoint_y_input: {
        type: Number,
        min: 0,
        max: 1,
        decimal: true,
        optional: true
    },
    location_input: {
        type: String,
        max: 255
    },
    tags_input: {
        type: String,
        regEx: Partup.services.validators.tagsSeparatedByComma,
        custom: function() {
            var max = false;
            lodash.each(this.value.split(','), function(tag) {
                if (tag.length > 30) max = true;
            });

            if (max) return 'individualMaxString';
        },
        autoform: {
            type: 'tags',
            afFieldInput: tagsConfiguration
        }
    }
}]);

/**
 * start partup create form schema
 * @name partupCreate
 * @memberOf Partup.schemas.forms
 */
Partup.schemas.forms.partupCreate = new SimpleSchema([Partup.schemas.forms.partupUpdate, {
    privacy_type_input: {
        type: String,
        allowedValues: [
            'public',
            'private',
            'network'
        ]
    }
}]);

/**
 * Feature partup form schema
 * @name featurePartup
 * @memberOf Partup.schemas.forms
 */
Partup.schemas.forms.featurePartup = new SimpleSchema({
    active: {
        type: Boolean
    },
    comment: {
        type: String
    },
    author_id: {
        type: String
    },
    job_title: {
        type: String
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/register.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var tagsConfiguration = {
    tagClass: 'pu-tag pu-tag-disableglobalclick',
    maxTags: 5
};
/**
 * Register Form Required
 * @name registerRequired
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.registerRequired = new SimpleSchema({
    confirmPassword: {
        type: String,
        custom: function() {
            if (this.value !== this.field('password').value) {
                return 'passwordMismatch';
            }
        }
    },
    email: {
        type: String,
        max: 255,
        regEx: Partup.services.validators.email
    },
    name: {
        type: String,
        max: 255
    },
    password: {
        type: String,
        max: 255,
        regEx: Partup.services.validators.password
    },
    networks: {
        type: [String],
        regEx: SimpleSchema.RegEx.Id,
        optional: true
    }
});

/**
 * Register Form Optional
 * @name registerOptional
 * @memberof Partup.schemas.forms
 */
var profileBaseSchema = new SimpleSchema({
    description: {
        type: String,
        max: 650,
        optional: true
    },
    image: {
        type: String,
        max: 255,
        optional: true
    },
    facebook_url: {
        type: String,
        max: 2000,
        optional: true,
        regEx: Partup.services.validators.facebookUrl
    },
    instagram_url: {
        type: String,
        max: 2000,
        optional: true,
        regEx: Partup.services.validators.instagramUrl
    },
    linkedin_url: {
        type: String,
        max: 2000,
        optional: true,
        regEx: Partup.services.validators.linkedinUrl
    },
    twitter_url: {
        type: String,
        max: 2000,
        optional: true,
        regEx: Partup.services.validators.twitterUrl
    },
    location_input: {
        type: String,
        max: 255,
        optional: true
    },
    phonenumber: {
        type: String,
        max: 255,
        optional: true
    },
    skype: {
        type: String,
        max: 255,
        optional: true
    },
    tags_input: {
        type: String,
        max: 255,
        optional: true,
        regEx: Partup.services.validators.tagsSeparatedByComma,
        autoform: {
            type: 'tags',
            afFieldInput: tagsConfiguration
        }
    },
    website: {
        type: String,
        max: 255,
        optional: true,
        regEx: Partup.services.validators.simpleSchemaUrlWithoutProtocol
    }
});

/**
 * Register Form Optional
 * @name profileSettings
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.profileSettings = new SimpleSchema([profileBaseSchema, {
    name: {
        type: String
    }
}]);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/resetPassword.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Register Form Required
 * @name registerRequired
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.resetPassword = new SimpleSchema({
    password: {
        type: String,
        max: 255,
        regEx: Partup.services.validators.password
    },
    confirmPassword: {
        type: String,
        custom: function() {
            if (this.value !== this.field('password').value) {
                return 'passwordMismatch';
            }
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/settings.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Register Form Required
 * @name registerRequired
 * @memberof Partup.schemas.forms
 */
Partup.schemas.entities.settings = new SimpleSchema({
    'locale': {
        type: String,
        min: 2,
        max: 2,
        optional:true
    },
    'email': {
        type: Object,
        optional: true
    },
    'email.dailydigest': {
        type: Boolean,
        optional: true
    },
    'email.upper_mentioned_in_partup': {
        type: Boolean,
        optional: true
    },
    'email.invite_upper_to_partup_activity': {
        type: Boolean,
        optional: true
    },
    'email.invite_upper_to_network': {
        type: Boolean,
        optional: true
    },
    'email.partup_created_in_network': {
        type: Boolean,
        optional: true
    },
    'email.partups_networks_new_pending_upper': {
        type: Boolean,
        optional: true
    },
    'email.partups_networks_accepted': {
        type: Boolean,
        optional: true
    },
    'email.invite_upper_to_partup': {
        type: Boolean,
        optional: true
    },
    'email.partups_new_comment_in_involved_conversation': {
        type: Boolean,
        optional: true
    },
    'email.partups_networks_new_upper': {
        type: Boolean,
        optional: true
    },
    'email.partups_networks_upper_left': {
        type: Boolean,
        optional: true
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/tag.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base Tag schema
 * @name tagBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var tagBaseSchema = new SimpleSchema({
    _id: {
        type: String,
        max: 50
    }
});

/**
 * Tag entity schema
 * @name tag
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.tag = new SimpleSchema([tagBaseSchema, {
    count: {
        type: Number,
        min: 0
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    }
}]);

/**
 * tag form schema
 * @name tag
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.tag = new SimpleSchema([tagBaseSchema, {
    //
}]);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/inviteUpper.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * New message Form
 * @name inviteUpper
 * @memberOf Partup.schemas.forms
 */
Partup.schemas.forms.inviteUpper = new SimpleSchema({
    invitees: {
        type: [Object],
        minCount: 1,
        maxCount: 10
    },
    'invitees.$.name': {
        type: String
    },
    'invitees.$.email': {
        type: String,
        max: 255,
        regEx: Partup.services.validators.email
    },
    message: {
        type: String,
        max: 2500,
        custom: function() {
            if (!Partup.services.validators.containsNoHtml(this.value)) {
                return 'shouldNotContainHtml';
            }

            if (!Partup.services.validators.containsRequiredTags(this.value, ['url', 'name'])) {
                return 'missingRequiredTags';
            }

            if (!Partup.services.validators.containsNoUrls(this.value)) {
                return 'shouldNotContainUrls';
            }
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/rating.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base Rating schema
 * @name ratingBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var ratingBaseSchema = new SimpleSchema({
    feedback: {
        type: String,
        optional: true
    },
    rating: {
        type: Number,
        decimal: true,
        optional: true
    }
});

/**
 * Rating entity schema
 * @name rating
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.rating = new SimpleSchema([ratingBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    activity_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    contribution_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    partup_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    },
    upper_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    }
}]);

/**
 * Rating Form
 * @name rating
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.rating = new SimpleSchema([ratingBaseSchema, {
    //
}]);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/networkBulkinvite.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Network bulk-invite form schema
 * @name network-bulk-invite
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.networkBulkinvite = new SimpleSchema({
    message: {
        type: String,
        max: 2500,
        custom: function() {
            if (!Partup.services.validators.containsNoHtml(this.value)) {
                return 'shouldNotContainHtml';
            }

            if (!Partup.services.validators.containsRequiredTags(this.value, ['url', 'name'])) {
                return 'missingRequiredTags';
            }

            if (!Partup.services.validators.containsNoUrls(this.value)) {
                return 'shouldNotContainUrls';
            }
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/language.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base Language schema
 * @name languageBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var languageBaseSchema = new SimpleSchema({
    _id: {
        type: String,
        min: 2,
        max: 10
    },
    native_name: {
        type: String,
        min: 0
    }
});

/**
 * Language entity schema
 * @name language
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.language = new SimpleSchema([languageBaseSchema, {
    //
}]);

/**
 * Language form schema
 * @name language
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.language = new SimpleSchema([languageBaseSchema, {
    //
}]);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/tile.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Tile form schema
 * @name tile
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.tile = new SimpleSchema({
    image_id: {
        type: String,
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    description: {
        type: String,
        max: 650,
        optional: true
    },
    type: {
        type: String,
        allowedValues: ['image', 'video']
    },
    video_url: {
        type: String,
        optional: true,
        custom: function() {
            if (this.value && !Partup.services.validators.isVideoUrl(this.value)) {
                return 'invalidVideoUrl';
            }
        }
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/swarm.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base Swarm schema
 * @name swarmBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var swarmBaseSchema = new SimpleSchema({
    title: {
        type: String,
        max: 75,
        optional: true
    },
    introduction: {
        type: String,
        max: 260,
        optional: true
    },
    description: {
        type: String,
        max: 700,
        optional: true
    },
    image: {
        type: String,
        optional: true
    }
});

/**
 * Swarm entity schema
 * @name swarmEntity
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.swarm = new SimpleSchema([swarmBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    admin_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    name: {
        type: String,
        max: 50
    },
    networks: {
        type: [String],
        regEx: SimpleSchema.RegEx.Id
    },
    quotes: {
        type: [Object],
        regEx: SimpleSchema.RegEx.Id
    },
    'quotes._id': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    'quotes.upper_id': {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    'quotes.content': {
        type: String,
        max: 500
    },
    refreshed_at: {
        type: Date,
        defaultValue: new Date()
    },
    shared_count: {
        type: Object
    },
    'shared_count.facebook': {
        type: Number,
        min: 0
    },
    'shared_count.twitter': {
        type: Number,
        min: 0
    },
    'shared_count.linkedin': {
        type: Number,
        min: 0
    },
    'shared_count.email': {
        type: Number,
        min: 0
    },
    stats: {
        type: Object
    },
    'stats.activity_count': {
        type: Number,
        min: 0
    },
    'stats.network_count': {
        type: Number,
        min: 0
    },
    'stats.partner_count': {
        type: Number,
        min: 0
    },
    'stats.partup_count': {
        type: Number,
        min: 0
    },
    'stats.supporter_count': {
        type: Number,
        min: 0
    },
    'stats.upper_count': {
        type: Number,
        min: 0
    },
    slug: {
        type: String
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    }
}]);

/**
 * Swarm create form schema
 * @name swarmCreate
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.swarmCreate = new SimpleSchema({
    name: {
        type: String,
        max: 50
    }
});

/**
 * Swarm update form schema
 * @name swarmUpdate
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.swarmUpdate = new SimpleSchema([swarmBaseSchema, {
    //
}]);

/**
 * Swarm edit form schema
 * @name swarmEditAdmin
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.swarmEditAdmin = new SimpleSchema({
    admin_id: {
        type: String
    }
});

/**
 * Swarm add quote schema
 * @name swarmQuote
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.swarmQuote = new SimpleSchema({
    author_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    content: {
        type: String,
        min: 15,
        max: 180
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/contentblock.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * ContentBlock form schema
 * @name contentBlock
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.contentBlock = new SimpleSchema({
    title: {
        type: String,
        optional: true
    },
    text: {
        type: String,
        max: 999,
        optional: true
    },
    image: {
        type: String,
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    type: {
        type: String,
        allowedValues: ['intro', 'paragraph']
    }
});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/chat.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base Chat schema
 * @name chatBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var chatBaseSchema = new SimpleSchema({
    //
});

/**
 * Chat entity schema
 * @name chat
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.chat = new SimpleSchema([chatBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    creator_id: {
        type: String,
        optional: true,
        regEx: SimpleSchema.RegEx.Id
    },
    started_typing: {
        type: [String],
        regEx: SimpleSchema.RegEx.Id
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    }
}]);

/**
 * Chat form schema
 * @name chat
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.chat = new SimpleSchema([chatBaseSchema, {
    //
}]);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/schemas/chatmessage.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Base ChatMessage schema
 * @name chatMessageBaseSchema
 * @memberof Partup.schemas
 * @private
 */
var chatMessageBaseSchema = new SimpleSchema({
    chat_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    content: {
        type: String,
        min: 1,
        max: 1000
    }
});

/**
 * ChatMessage entity schema
 * @name chatMessage
 * @memberof Partup.schemas.entities
 */
Partup.schemas.entities.chatMessage = new SimpleSchema([chatMessageBaseSchema, {
    _id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    created_at: {
        type: Date,
        defaultValue: new Date()
    },
    creator_id: {
        type: String,
        regEx: SimpleSchema.RegEx.Id
    },
    read_by: {
        type: [String],
        regEx: SimpleSchema.RegEx.Id
    },
    seen_by: {
        type: [String],
        regEx: SimpleSchema.RegEx.Id
    },
    updated_at: {
        type: Date,
        defaultValue: new Date()
    }
}]);

/**
 * ChatMessage form schema
 * @name chatMessage
 * @memberof Partup.schemas.forms
 */
Partup.schemas.forms.chatMessage = new SimpleSchema([chatMessageBaseSchema, {
    //
}]);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/transformers/activity.js                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Activity transformer service
 @name partup.transformers.activity
 @memberof Partup.transformers
 */
Partup.transformers.activity = {
    /**
     * Transform form to activity
     *
     * @memberof Partup.transformers.activity
     * @param {mixed[]} fields
     * @param {string} upperId
     * @param {string} partupId
     */
    'fromForm': function(fields, upperId, partupId) {
        return {
            name: fields.name,
            description: fields.description,
            end_date: fields.end_date,
            created_at: new Date(),
            updated_at: new Date(),
            creator_id: upperId,
            partup_id: partupId,
            archived: false
        };
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/transformers/partup.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Partup transformer service
 * @name partup.transformers.partup
 * @memberOf Partup.transformers
 */
Partup.transformers.partup = {
    /**
     * Transform partup to start partup form
     *
     * @memberOf Partup.transformers.partup
     * @param {Object} partup
     */
    'toFormStartPartup': function(partup) {
        // Find image for focuspoint
        var image = Images.findOne({_id: partup.image});

        var fields = {
            partup_name: partup.name,
            _id: partup._id,
            description: partup.description,
            type: partup.type,
            type_commercial_budget: partup.type_commercial_budget,
            type_organization_budget: partup.type_organization_budget,
            currency: partup.currency,
            end_date: partup.end_date,
            location_input: Partup.services.location.locationToLocationInput(partup.location),
            name: partup.name,
            tags_input: Partup.services.tags.tagArrayToInput(partup.tags),
            focuspoint_x_input: image ? (mout.object.get(image, 'focuspoint.x') || 0) : 0,
            focuspoint_y_input: image ? (mout.object.get(image, 'focuspoint.y') || 0) : 0,
            phase: partup.phase
        };

        // Determine privacy type
        if (partup.privacy_type === Partups.PUBLIC) {
            fields.privacy_type_input = 'public';
        } else if (partup.privacy_type === Partups.PRIVATE) {
            fields.privacy_type_input = 'private';
        } else if (partup.privacy_type === Partups.NETWORK_PUBLIC ||
            partup.privacy_type === Partups.NETWORK_INVITE ||
            partup.privacy_type === Partups.NETWORK_CLOSED) {
            fields.privacy_type_input = partup.network_id;
        }

        return fields;
    },

    /**
     * Transform startpartup form to partup
     *
     * @memberOf Partup.transformers.partup
     * @param {mixed[]} fields
     */
    'fromFormStartPartup': function(fields) {
        var partup = {
            // form fields
            name: fields.partup_name,
            description: fields.description,
            type: fields.type,
            type_commercial_budget: fields.type_commercial_budget,
            type_organization_budget: fields.type_organization_budget,
            currency: fields.currency,
            end_date: fields.end_date,
            image: fields.image,
            tags: Partup.services.tags.tagInputToArray(fields.tags_input),
            language: Partup.server.services.google.detectLanguage(fields.description),
            phase: fields.phase
        };

        var newLocation = Partup.services.location.locationInputToLocation(fields.location_input);
        if (newLocation) partup.location = newLocation;

        // Determine privacy type
        if (fields.privacy_type_input === 'public') {
            partup.privacy_type = Partups.PUBLIC;
        } else if (fields.privacy_type_input === 'private') {
            partup.privacy_type = Partups.PRIVATE;
        } else if (fields.privacy_type_input === 'network') {
            var network = Networks.findOneOrFail(fields.network_id);
            partup.network_id = network._id;
            switch (network.privacy_type) {
                case Networks.NETWORK_PUBLIC:
                    partup.privacy_type = Partups.NETWORK_PUBLIC;
                    break;
                case Networks.NETWORK_INVITE:
                    partup.privacy_type = Partups.NETWORK_INVITE;
                    break;
                case Networks.NETWORK_CLOSED:
                    partup.privacy_type = Partups.NETWORK_CLOSED;
                    break;
            }
        }

        // Save focuspoint
        Partup.server.services.images.storeFocuspoint(partup.image, fields.focuspoint_x_input || 0, fields.focuspoint_y_input || 0);

        return partup;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/transformers/user.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Profile transformer service
 @name partup.transformers.profile
 @memberof Partup.transformers
 */
Partup.transformers.profile = {
    /**
     * Transform user profile to profile settings form
     *
     * @memberof Partup.transformers.partup
     * @param {object} user
     */
    'toFormProfileSettings': function(user) {
        return {
            '_id': user.profile._id,
            'image': user.profile.image,
            'description': user.profile.description,
            'facebook_url': user.profile.facebook_url,
            'twitter_url': user.profile.twitter_url,
            'instagram_url': user.profile.instagram_url,
            'linkedin_url': user.profile.linkedin_url,
            'website': user.profile.website,
            'phonenumber': user.profile.phonenumber,
            'skype': user.profile.skype,
            'tags_input': Partup.services.tags.tagArrayToInput(user.profile.tags),
            'location_input': Partup.services.location.locationToLocationInput(user.profile.location),
            'name': user.profile.name
        };
    },

    /**
     * Transform profile settings form to user fields
     *
     * @memberof Partup.transformers.user
     * @param {mixed[]} fields
     */
    'fromFormProfileSettings': function(fields) {
        var newFields = {
            profile: {
                'image': fields.image,
                'description': fields.description,
                'tags': Partup.services.tags.tagInputToArray(fields.tags_input),
                'facebook_url': fields.facebook_url,
                'twitter_url': fields.twitter_url,
                'instagram_url': fields.instagram_url,
                'linkedin_url': fields.linkedin_url,
                'phonenumber': fields.phonenumber,
                'website': Partup.services.website.cleanUrlToFullUrl(fields.website),
                'skype': fields.skype,
                'name': fields.name
            }
        };

        var newLocation = Partup.services.location.locationInputToLocation(fields.location_input);
        if (newLocation) newFields.profile.location = newLocation;

        return newFields;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/transformers/update.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Update transformer service
 @name partup.transformers.update
 @memberof Partup.transformers
 */
Partup.transformers.update = {
    /**
     * Transform form to new message
     *
     * @memberof Partup.transformers.update
     * @param {mixed[]} fields
     * @param {object} upper
     * @param {string} partupId
     */
    'fromFormNewMessage': function(fields, upper, partupId) {
        return {
            partup_id: partupId,
            type_data: {
                new_value: fields.text,
                images: fields.images,
                documents: fields.documents
            },
            comments_count: 0,
            upper_id: upper._id,
            created_at: new Date(),
            updated_at: new Date()
        };
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/transformers/contributions.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Contribution transformer service
 @name partup.transformers.contribution
 @memberof Partup.transformers
 */
 var hasValue = function(value) {
    return (typeof value == 'number');
};

Partup.transformers.contribution = {
    /**
     * Transform contribution to form
     *
     * @memberof Partup.transformers.contribution
     * @param {object} contribution
     */
    'toFormContribution': function(contribution) {
        return contribution ? contribution : undefined;
    },

    /**
     * Transform form to contribution fields
     *
     * @memberof Partup.transformers.contribution
     * @param {mixed[]} fields
     */
    'fromFormContribution': function(fields) {
        var hours = hasValue(fields.hours) ? fields.hours : null;
        var rate = hasValue(fields.rate) ? fields.rate : null;
        return {
            hours: hours,
            rate: rate,
            currency: fields.currency,
            motivation: fields.motivation || null
        };
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/transformers/network.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Network transformer service
 @name partup.transformers.network
 @memberof Partup.transformers
 */
Partup.transformers.network = {
    /**
     * Transform network to start network form
     *
     * @memberof Partup.transformers.network
     * @param {object} network
     */
    'toFormNetwork': function(network) {
        return {
            _id: network._id,
            privacy_type: network.privacy_type,
            description: network.description,
            location_input: Partup.services.location.locationToLocationInput(network.location),
            name: network.name,
            tags_input: Partup.services.tags.tagArrayToInput(network.tags),
            website: network.website,
            background_image: network.background_image,
            image: network.image,
            icon: network.icon
        };
    },

    /**
     * Transform network to admin network form
     *
     * @memberof Partup.transformers.network
     * @param {object} network
     */
    'toFormNetworkAdmin': function(network) {
        return {
            admins: Partup.services.tags.tagArrayToInput(network.admins)
        };
    },

    /**
     * Transform network form to network
     *
     * @memberof Partup.transformers.network
     * @param {mixed[]} fields
     */
    'fromFormNetwork': function(fields) {
        var network = {
            name: fields.name,
            description: fields.description,
            website: fields.website,
            tags: Partup.services.tags.tagInputToArray(fields.tags_input),
            language: Partup.server.services.google.detectLanguage(fields.description),
            background_image: fields.background_image,
            image: fields.image,
            icon: fields.icon
        };

        var newLocation = Partup.services.location.locationInputToLocation(fields.location_input);
        if (newLocation) network.location = newLocation;

        return network;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/transformers/swarm.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace Swarm transformer service
 @name partup.transformers.swarm
 @memberof Partup.transformers
 */
Partup.transformers.swarm = {
    /**
     * Transform swarm object to swarm form data
     *
     * @memberof Partup.transformers.swarm
     * @param {object} swarm
     */
    'toFormSwarm': function(swarm) {
        return {
            _id: swarm._id,
            title: swarm.title,
            introduction: swarm.introduction,
            description: swarm.description,
            image: swarm.image
        };
    },

    /**
     * Transform swarm form to swarm object
     *
     * @memberof Partup.transformers.swarm
     * @param {mixed[]} fields
     */
    'fromFormSwarm': function(fields) {
        fields.title = sanitizeHtml(fields.title);
        fields.introduction = sanitizeHtml(fields.introduction);
        fields.description = sanitizeHtml(fields.description);

        return fields;
    },

    /**
     * Transform swarm object to swarm form data
     *
     * @memberof Partup.transformers.swarm
     * @param {object} quote
     */
    'toFormQuote': function(quote) {
        return {
            author_id: quote.author._id,
            content: quote.content
        };
    },
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/transformers/contentblock.js                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @namespace ContentBlock transformer service
 @name partup.transformers.contentBlock
 @memberof Partup.transformers
 */
Partup.transformers.contentBlock = {
    /**
     * Transform contentBlock object to contentBlock form data
     *
     * @memberof Partup.transformers.contentBlock
     * @param {object} contentBlock
     */
    'toFormContentBlock': function(contentBlock) {
        return {
            _id: contentBlock._id,
            title: contentBlock.title,
            text: contentBlock.text,
            image: contentBlock.image
        };
    },

    /**
     * Transform contentBlock form to contentBlock object
     *
     * @memberof Partup.transformers.contentBlock
     * @param {mixed[]} fields
     */
    'fromFormContentBlock': function(fields) {
        var data = {
            type: fields.type
        };

        if (fields.title) data.title = sanitizeHtml(fields.title);
        if (fields.text) data.text = sanitizeHtml(fields.text);

        if (fields.image) data.image = fields.image;

        return data;
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/helpers/parselocale.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @name partup.helpers.parseLocale
 @memberof Partup.helpers
 */
Partup.helpers.parseLocale = function(locale, fallbackLocale) {
    fallbackLocale = fallbackLocale || 'en';
    locale = (typeof locale === 'string' || locale instanceof String) ? locale : fallbackLocale;
    var localeMatch = locale.match(/^([a-z]{2})[-_][A-Z]{2}$/);
    return localeMatch ? localeMatch[1] : fallbackLocale;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/helpers/mentions.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * @namespace Helpers
 * @name Partup.helpers.mentions
 * @memberOf Partup.helpers
 */
Partup.helpers.mentions = {};

/**
 * Extract mentions from a message
 *
 * @namespace Helpers
 * @name Partup.helpers.mentions.extract
 * @memberOf Partup.helpers.mentions
 *
 * @param {String} message
 *
 * @return {Array}
 */
Partup.helpers.mentions.extract = function(message) {
    var mentions = [];
    // extracts user (single) mentions
    extractUsers(message).forEach(function(mention) {
        var existingMention = lodash.find(mentions, {_id: mention._id});
        if (!existingMention) mentions.push(mention);
    });

    // extracts partners (group) mention
    extractPartners(message).forEach(function(mention) {
        var existingMention = lodash.find(mentions, {name: 'Partners'});
        if (!existingMention) mentions.push(mention);
    });

    // extracts supporters (group) mention
    extractSupporters(message).forEach(function(mention) {
        var existingMention = lodash.find(mentions, {name: 'Supporters'});
        if (!existingMention) mentions.push(mention);
    });
    return mentions;
};


/**
 * Replace mentions in a message with hyperlinks
 *
 * @namespace Helpers
 * @name Partup.helpers.mentions.decode
 * @memberOf Partup.helpers.mentions
 *
 * @param {String} message
 *
 * @return {String}
 */
Partup.helpers.mentions.decode = function(message) {
    return message.replace(/\[Supporters:(?:([^\]]+))?\]/g, function(m, users) {
        // decode supporter mentions
        var name = 'Supporters';
        return '<a data-hovercontainer="HoverContainer_upperList" data-hovercontainer-context="' + users + '" class="pu-mention-group">' + name + '</a>';
    }).replace(/\[Partners:(?:([^\]]+))?\]/g, function(m, users) {
        // decode upper mentions
        var name = 'Partners';
        return '<a data-hovercontainer="HoverContainer_upperList" data-hovercontainer-context="' + users + '" class="pu-mention-group">' + name + '</a>';
    }).replace(/\[user:([^\]|]+)(?:\|([^\]]+))?\]/g, function(m, id, name) {
        // decode invividual mentions
        return '<a href="' + Router.path('profile', {_id: id}) + '" data-hovercontainer="HoverContainer_upper" data-hovercontainer-context="' + id + '" class="pu-mention-user">' + name + '</a>';
    });
};

/**
 * Replace mentions in a message with hyperlinks
 *
 * @namespace Helpers
 * @name Partup.helpers.mentions.decodeForInput
 * @memberOf Partup.helpers.mentions
 *
 * @param {String} message
 *
 * @return {String}
 */
Partup.helpers.mentions.decodeForInput = function(message) {
    if (!message && !message.length) return '';
    return message.replace(/\[Supporters:(?:([^\]]+))?\]/g, function(m, users) {
        // decode supporter mentions
        var name = 'Supporters';
        return '@' + name;
    }).replace(/\[Partners:(?:([^\]]+))?\]/g, function(m, users) {
        // decode upper mentions
        var name = 'Partners';
        return '@' + name;
    }).replace(/\[user:([^\]|]+)(?:\|([^\]]+))?\]/g, function(m, id, name) {
        // decode invividual mentions
        return '@' + name;
    });
};

/**
 * Encode user-selected mentions into the message
 *
 * @namespace Helpers
 * @name Partup.helpers.mentions.encode
 * @memberOf Partup.helpers.mentions
 *
 * @param {String} message
 * @param {Array} mentions
 *
 * @return {String}
 */
Partup.helpers.mentions.encode = function(message, mentions) {
    mentions.forEach(function(mention, index) {
        // determine part of message to be encoded
        var find = '@' + mention.name;
        var encodedMention;
        // check if the mention is a group mention (partners/supporters) or single mention (user)
        if (mention.group) {
            var group = mention.name;
            // first part of encoded mention string -> [partners:
            encodedMention = '[' + group + ':';

            if (mention[group].length) {
                // second part of encoded mention string -> [partners:<user_id>,<user_id>,
                mention[group].forEach(function(user, index) {
                    encodedMention = encodedMention + user + ',';
                });
                // removes the last comma -> [partners:<user_id>,<user_id>
                encodedMention = encodedMention.substring(0, encodedMention.length - 1);
            } else {
                // second part of encoded mention string when there are no users -> [partners:!empty!
                // encodedMention = encodedMention + '!empty!';
            }

            // final part of encoded mention -> [partners:<user_id>,<user_id>]
            encodedMention = encodedMention + ']';

        } else {
            // encodes single mention -> [user:<user_id>:<user_name>]
            encodedMention = '[user:' + mention._id + '|' + mention.name + ']';
        }
        // finally replace mention with encoded mention
        message = replaceAll(message, find, encodedMention);
    });
    return message;
};
var replaceAll = function(str, find, replace) {
    return str.replace(new RegExp(find, 'g'), replace);
};
/**
 * Get the true character count of a message without the encoded mess of mentions
 *
 * @namespace Helpers
 * @name Partup.helpers.mentions.getTrueCharacterCount
 * @memberOf Partup.helpers.mentions
 *
 * @param {String} message
 *
 * @return {Number}
 */
Partup.helpers.mentions.getTrueCharacterCount = function(message) {
    // set base count
    var count = message.length;
    // find all user mentions
    var userMentionsArray = userMentions(message);

    if (userMentionsArray) {
        // subtract mention count from endoced message
        userMentionsArray.forEach(function(item) {
            count = count + mentionedUserName(item).length;
        });
        count = count - combinedCount(userMentionsArray);
    }
    // find all partner mentions
    var partnerMentionsArray = partnerMentions(message);
    if (partnerMentionsArray) {
        // subtract mention count from endoced message
        partnerMentionsArray.forEach(function(item) {
            count = count + 'Partners'.length;
        });
        count = count - combinedCount(partnerMentionsArray);
    }
    // find all supporter mentions
    var supporterMentionsArray = supporterMentions(message);
    if (supporterMentionsArray) {
        // subtract mention count from endoced message
        supporterMentionsArray.forEach(function(item) {
            count = count + 'Supporters'.length;
        });
        count = count - combinedCount(supporterMentionsArray);
    }
    return count;
};

Partup.helpers.mentions.exceedsLimit = function(message) {
    var mentions = Partup.helpers.mentions.extract(message);
    var users = lodash.filter(mentions, {type: 'single'});
    if (users.length > 100) return 'tooManyUserMentions';
    var partners = lodash.find(mentions, {name: 'Partners'});
    if (partners && partners.users && partners.users.length > 100) return 'tooManyPartnerMentions';
    var supporters = lodash.find(mentions, {name: 'Supporters'});
    if (supporters && supporters.users && supporters.users.length > 100) return 'tooManySupporterMentions';
    return false;
};

// mention helpers

var mentionedUserName = function(mention) {
    return mention.match(/\[user:([^\]|]+)(?:\|([^\]]+))?\]/)[2];
};
var combinedCount = function(array) {
    var count = 0;
    array.forEach(function(mention) {
        count = count + mention.length;
    });
    return count;
};

var extractUsers = function(message) {
    var mentions = [];

    var matches = userMentions(message);
    if (!matches) return mentions;

    var match;
    for (var i = 0; i < matches.length; i++) {
        match = matches[i].match(/\[user:([^\]|]+)(?:\|([^\]]+))?\]/);
        mentions.push({
            _id: match[1],
            type: 'single',
            name: match[2]
        });
    }

    return lodash.uniq(mentions);
};
var userMentions = function(message) {
    return message.match(/\[user:[^\]|]+(?:\|[^\]]+)?\]/g);
};

var extractPartners = function(message) {
    var mentions = [];

    var matches = partnerMentions(message);
    if (!matches) return mentions;

    matches.forEach(function(match, index) {
        var singlematch = match.match(/\[Partners:(?:([^\]]+))?\]/);
        var users = singlematch[1] ? singlematch[1].split(',') : [];
        mentions.push({
            type: 'group',
            users: lodash.uniq(users),
            name: 'Partners'
        });
    });

    return mentions;
};
var partnerMentions = function(message) {
    return message.match(/\[Partners:(?:([^\]]+))?\]/g);
};

var extractSupporters = function(message) {
    var mentions = [];

    var matches = supporterMentions(message);
    if (!matches) return mentions;

    matches.forEach(function(match, index) {
        var singlematch = match.match(/\[Supporters:(?:([^\]]+))?\]/);
        var users = singlematch[1] ? singlematch[1].split(',') : [];
        mentions.push({
            type: 'group',
            users: lodash.uniq(users),
            name: 'Supporters'
        });
    });

    return mentions;
};
var supporterMentions = function(message) {
    return message.match(/\[Supporters:(?:([^\]]+))?\]/g);
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/helpers/normalize.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @name partup.helpers.normalize
 @memberof Partup.helpers
 * based on https://github.com/andrepadez/normalizer
 */
Partup.helpers.normalize = function(origString, keepCase){
    var newString = origString;
    
    for(var char in charMap){
        var rex = new RegExp('[' + charMap[char].toString() + ']', 'g');
        try{
            origString = origString.replace(rex, char);
        } catch(e) {
            console.log('error', origString);
        }
    }
    return keepCase? origString : origString.toLowerCase();
};

var charMap = {
    'a': ['á','Á','à','À','ã','Ã','â','Â','ä','Ä','å','Å','ā','Ā','ą','Ą'],
    'e': ['é','É','è','È','ê','Ê','ë','Ë','ē','Ē','ė','Ė','ę','Ę'],
    'i': ['î','Î','í','Í','ì','Ì','ï','Ï','ī','Ī','į','Į'],
    'l': ['ł', 'Ł'],
    'o': ['ô','Ô','ò','Ò','ø','Ø','ō','Ō','ó','Ó','õ','Õ','ö','Ö'],
    'u': ['û','Û','ú','Ú','ù','Ù','ü','Ü','ū','Ū'],
    'c': ['ç','Ç','č','Č','ć','Ć'],
    's': ['ś','Ś','š','Š'],
    'z': ['ź','Ź','ż','Ż']
};

var normalizeFilter = function(origFilter, model, wholeString, keepCase){
    var schema = model.schema? model.schema.tree.normalized : model;
    var newFilter = {};
    var finalFilter = {};

    var getFilterResult = function(string){
        return wholeString? 
            normalize(string, keepCase) : 
                new RegExp(normalize(string, keepCase), 'i');
    };

    var recurse = function(filter, path, schema){
        for(var key in filter){
            var filterResult;
            if(key in schema){
                var normalized = getPathString(key, path);
                if(typeof filter[key] === 'string'){
                    filterResult = getFilterResult(filter[key]);
                    newFilter[getPathString(key, path) + key] = filterResult;
                } else{
                    path.push(key);
                    recurse(filter[key], path, schema[key]);
                }

            } else {
                newFilter[key] = typeof filter[key] === 'string'? filterResult : filter[key];
            }
        }
        return newFilter;
    };
    finalFilter = recurse(origFilter, [], schema);
    return finalFilter; 
};

var normalizeSort = function(origSort, model){
    var schema = model.schema? model.schema.tree.normalized : model;
    var newSort = {};
    var finalSort = {};

    var recurse = function(sort, path, schema){
        for(var key in sort){
            if(key in schema && !(key in newSort)){
                if(typeof sort[key] !== 'object'){
                    newSort[getPathString(key, path) + key] = sort[key];
                } else{
                    path.push(key);
                    recurse(sort[key], path, schema[key]);
                }

            } else {
                newSort[key] = sort[key];
            }
        }
        return newSort;
    };
    finalSort = recurse(origSort, [], schema);
    return finalSort;
};

var normalizeSearchFields = function(doc, model, keepCase){
    var schema = model.schema? model.schema.tree.normalized : model;
    var recurse = function(doc, normalized, schema){
        var newDoc = {};
        for(var key in doc){
            if(key in schema){
                if(typeof doc[key] === 'object'){
                    var normal = newDoc[key] = {};
                    newDoc[key] = recurse(doc[key], normal , schema[key]);
                } else {
                    newDoc[key] = typeof doc[key] === 'string'? normalize(doc[key], keepCase) : doc[key];
                }
            }
        }
        return newDoc;
    };

    var finalDoc = {normalized: {}};
    for(var key in doc){
        finalDoc[key] = doc[key];
    }
    finalDoc.normalized = recurse(doc, finalDoc.normalized, schema);
    return finalDoc;
};


var getPathString = function(key, path){
    var pathString = 'normalized';
    if(path.length > 0){
        pathString += '.' +  path.join('.');
    }
    pathString += '.';
    return pathString;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/helpers/interpolateEmailMessage.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @name partup.helpers.interpolateEmailMessage
 @memberof Partup.helpers
 */
Partup.helpers.interpolateEmailMessage = function(message, interpolations) {
    var m = message;

    mout.object.forOwn(interpolations, function(value, key) {
        var regex = new RegExp('\\[\\s*' + key + '\\s*\\]', 'i');
        m = m.replace(regex, value);
    });

    return m;
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/helpers/url.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 @name partup.helpers.url
 @memberof Partup.helpers
 */
Partup.helpers.url = {
    stripWWW: function(url) {
        return url.replace(/^www\./gi, '');
    },
    stripHTTP: function(url) {
        return url.replace(/^.*?:\/\//gi, '');
    },
    capitalizeFirstLetter: function(string) {
        if (!string) return '';
        return string.charAt(0).toUpperCase() + string.slice(1);
    },
    getCleanUrl: function(url) {
        return this.capitalizeFirstLetter(this.stripWWW(this.stripHTTP(url)));
    },
    addHTTP: function(url) {
        if (!/^((http|https|ftp):\/\/)/.test(url)) {
            url = 'http://' + url;
        }
        return url;
    },
    getImageUrl: function(image, store) {
        store = store || '1200x520';

        // staging acceptance production aws image url
        return ['https://s3-',
            mout.object.get(Meteor, 'settings.public.aws.region'),
            '.amazonaws.com/',
            mout.object.get(Meteor, 'settings.public.aws.bucket'),
            '/',
            store,
            '/',
            image.copies[store].key
        ].join('');
    }
};

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/helpers/fileUploader.js                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Partup.helpers.imageExtensions = ['.gif', '.jpg', '.jpeg', '.png', '.GIF', '.JPG', '.JPEG', '.PNG'];
Partup.helpers.docExtensions = ['.doc', '.docx', '.rtf', '.pages', '.txt', '.DOC', '.DOCX', '.RTF', '.PAGES', '.TXT'];
Partup.helpers.pdfExtensions = ['.pdf', '.PDF'];
Partup.helpers.presentationExtensions = ['.pps', '.ppsx', '.ppt', '.pptx', '.PPS', '.PPSX', '.PPT', '.PPTX'];
Partup.helpers.fallbackFileExtensions = ['.ai', '.bmp', '.eps', '.psd', '.tiff', '.tif', '.svg', '.key', '.keynote', '.AI', '.BMP', '.EPS', '.PSD', '.TIFF', '.TIF', '.SVG', '.KEY', '.KEYNOTE'];
Partup.helpers.spreadSheetExtensions = ['.xls', '.xlsx', '.numbers', '.csv', '.XLS', '.XLSX', '.NUMBERS', '.CSV'];

Partup.helpers.allowedExtensions = {
    images: Partup.helpers.imageExtensions,
    docs: _.flatten([
        Partup.helpers.pdfExtensions,
        Partup.helpers.docExtensions,
        Partup.helpers.presentationExtensions,
        Partup.helpers.fallbackFileExtensions,
        Partup.helpers.spreadSheetExtensions
    ])
};

Partup.helpers.getAllExtensions = function () {
    return _.chain(Partup.helpers.allowedExtensions).keys().map(function (type) {
        return Partup.helpers.allowedExtensions[type];
    }).flatten().value();
};

function matchExtension(fileName) {
    return fileName.match(/\.([0-9a-z]+)(?=[?#])|(\.)(?:[\w]+)$/);
}
Partup.helpers.getExtensionFromFileName = function (fileName) {
    var match = matchExtension(fileName);
    if (match) {
        return match[0];
    }
    // if file.name does not have .[ext] return a default doc
    return _.first(Partup.helpers.fallbackFileExtensions);
};

Partup.helpers.fileNameIsDoc = function (fileName) {
    return _.include(Partup.helpers.allowedExtensions.docs,
        Partup.helpers.getExtensionFromFileName(fileName)
    );
};

Partup.helpers.fileNameIsImage = function (fileName) {
    return _.include(Partup.helpers.allowedExtensions.images,
        Partup.helpers.getExtensionFromFileName(fileName)
    );
};

Partup.helpers.getSvgIcon = function (file) {
    var svgFileName = 'file.svg';

    // if there's extension in the file name
    if (matchExtension(file.name)) {
        var extension = Partup.helpers.getExtensionFromFileName(file.name);

        if (_.include(Partup.helpers.fallbackFileExtensions, extension)) {
            svgFileName = 'file.svg';
        }
        else if (_.include(Partup.helpers.presentationExtensions, extension)) {
            svgFileName = 'ppt.svg';
        }
        else if (_.include(Partup.helpers.docExtensions, extension)) {
            svgFileName = 'doc.svg';
        }
        else if (_.include(Partup.helpers.pdfExtensions, extension)) {
            svgFileName = 'pdf.svg';
        }
        else if (_.include(Partup.helpers.spreadSheetExtensions, extension)) {
            svgFileName = 'xls.svg';
        }
        // otherwise fallback to file.svg
        return svgFileName
    } else {
        // if there's no extension in the file name,
        // for example google sheet, google docs or google slide
        // check the mimeType
        if (file.mimeType) {
            if (file.mimeType.indexOf('presentation') > -1) {
                return 'ppt.svg';
            }
            else if (file.mimeType.indexOf('document') > -1) {
                return 'doc.svg';
            }
            else if (file.mimeType.indexOf('spreadsheet') > -1) {
                return 'xls.svg';
            }
            // otherwise fallback to file.svg
            return svgFileName;
        } else {
            // otherwise fallback to file.svg
            return svgFileName;
        }
    }

};

// from http://scratch99.com/web-development/javascript/convert-bytes-to-mb-kb/
Partup.helpers.bytesToSize = function (bytes) {
    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes == 0) return '&nbsp;';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    if (i == 0) return bytes + ' ' + sizes[i];
    return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
};

Partup.helpers.partupUploadPhoto = function (template, mappedFile) {
    template.uploadingPhotos.set(true);
    return new Promise(function (resolve, reject) {
        Partup.client.uploader.uploadImageByUrl(mappedFile.link, function (error, image) {
            if (error) {
                return reject(error);
            }
            mappedFile._id = image._id;
            resolve(mappedFile);
        });
    });
};

Partup.helpers.partupUploadDoc = function (template, mappedFile) {
    template.uploadingDocuments.set(true);
    return new Promise(function (resolve, reject) {
        resolve(mappedFile);
    });
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/helpers/dropboxRenderer.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var DropboxRenderer = function () {

    return {
        createPreviewLinkFromDirectLink: createPreviewLinkFromDirectLink
    };

    function getFileIdFromDirectLink(fileUrl) {

        var matchViewPath = fileUrl.match(/view\/(\w+)/);
        var matchSPath = fileUrl.match(/s\/(\w+)/);

        if(matchViewPath) {
            return matchViewPath[1];
        }
        else if(matchSPath) {
            return matchSPath[1];
        }

        // return un-existing id for fallback
        return new Meteor.Collection.ObjectID()._str;
    }

    function createPreviewLinkFromDirectLink(directLinkUrl, fileName) {
        var fileId = getFileIdFromDirectLink(directLinkUrl);
        return 'https://www.dropbox.com/s/' + fileId + '/' + fileName + '?dl=0';
    }

};

Partup.helpers.DropboxRenderer = DropboxRenderer;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/helpers/googleDriveRenderer.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var GoogleDriveRenderer = function () {

    return {
        createPreviewLinkFromDirectLink: createPreviewLinkFromDirectLink
    };

    function createPreviewLinkFromDirectLink(directLinkUrl) {
        return directLinkUrl;
    }

};

Partup.helpers.GoogleDriveRenderer = GoogleDriveRenderer;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/startup/default_profile_pictures.js                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Insert the default profile pictures into the database
 */
Meteor.startup(function() {

    if (! AWS.config.accessKeyId || ! AWS.config.secretAccessKey || ! AWS.config.region) {
        return console.log('Default profile pictures could not be loaded because the amazon s3 configuration has not been set, please check your environment variables.'.red);
    }

    for (var i = 1; i <= 15; i++) {
        var exists = !!Images.findOne({'meta.default_profile_picture': true, 'meta.default_profile_picture_index': i});

        if (!exists) {
            var filename = 'Profielfoto' + i + '.png';
            var body = new Buffer(Assets.getBinary('private/default_profile_pictures/' + filename));
            var meta = {default_profile_picture: true, default_profile_picture_index: i};

            Partup.server.services.images.upload(filename, body, 'image/png', {meta: meta});
        }
    }

});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/partup_lib/startup/default_partup_pictures.js                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**
 * Insert the default profile pictures into the database
 */
Meteor.startup(function() {

    if (! AWS.config.accessKeyId || ! AWS.config.secretAccessKey || ! AWS.config.region) {
        return console.log('Default partup pictures could not be loaded because the amazon s3 configuration has not been set, please check your environment variables.'.red);
    }

    for (var i = 1; i <= 12; i++) {
        var exists = !!Images.findOne({'meta.default_partup_picture': true, 'meta.default_partup_picture_index': i});

        if (!exists) {
            var filename = 'Partupfoto' + i + '.png';
            var body = new Buffer(Assets.getBinary('private/default_partup_pictures/' + filename));
            var meta = {default_partup_picture: true, default_partup_picture_index: i};

            Partup.server.services.images.upload(filename, body, 'image/png', {meta: meta});
        }
    }

});

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['partup:lib'] = {}, {
  Version: Version,
  Partup: Partup,
  Activities: Activities,
  Invites: Invites,
  Contributions: Contributions,
  Images: Images,
  Temp: Temp,
  Networks: Networks,
  Notifications: Notifications,
  Partups: Partups,
  Ratings: Ratings,
  Tags: Tags,
  Updates: Updates,
  Update: Update,
  User: User,
  Places: Places,
  PlacesAutocompletes: PlacesAutocompletes,
  Uploads: Uploads,
  Languages: Languages,
  Tiles: Tiles,
  Swarms: Swarms,
  ContentBlocks: ContentBlocks,
  Chats: Chats,
  ChatMessages: ChatMessages,
  get: get,
  set: set
});

})();

//# sourceMappingURL=partup_lib.js.map
